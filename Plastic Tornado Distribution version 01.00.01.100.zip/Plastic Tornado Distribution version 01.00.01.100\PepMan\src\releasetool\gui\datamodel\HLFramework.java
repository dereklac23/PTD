package releasetool.gui.datamodel;

public interface HLFramework {
    public static enum Type {MANUAL, PAGE, ELEMENT};
    public Type type= Type.MANUAL;
	public abstract void HLAction(Type _type);
	
}

package emailsender.gui;
import emailsender.html.*;
import emailsender.gui.GroupModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTree;

import emailsender.KCMException;
import emailsender.KCMObject;
import emailsender.PathUtil;
import emailsender.gui.Entry.EntryType;
import emailsender.html.HTMLOutput;
import emailsender.html.TEXTOutput;

public class ExpansionFrame extends JFrame {
	public enum TYPE {HTML, TEXT};
	public TYPE type = TYPE.HTML;
	int WIDTH=1500, HEIGHT=1500;
    private ExpansionTree expansionTree=null;
    private Entry root=null;
    private JTable jTable=null;
    private HTMLOutput htmlOutput=null;
    private TEXTOutput textOutput=null;
    public EntryAdapter entryAdapter=null;
    public GroupModel groupModel=null;
	public ExpansionFrame(TYPE _type) {
		super();
	    groupModel = new GroupModel();	
		type = _type;
		JPanel panelInner = new JPanel();
		JPanel panelTree = new JPanel();
		JPanel mainPane =(JPanel) getContentPane();
		mainPane.setSize(new Dimension(WIDTH*2, HEIGHT*10));
		root=  new Entry( "Email Root", groupModel);		
		if (type == TYPE.HTML) {
		htmlOutput = new HTMLOutput(groupModel);
		} else if (type == TYPE.TEXT) {
			textOutput= new TEXTOutput(groupModel);	
		}
		
		
		expansionTree= new ExpansionTree(root);
		
		JScrollPane treeScrollPane = new JScrollPane(
				expansionTree,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	
		
		JScrollPane scrollPane = new JScrollPane(
                panelInner,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		treeScrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(20, HEIGHT*10));
		
		scrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(	20, HEIGHT*10));
		
		
		
		expansionTree.setVisibleRowCount(200);
		
		entryAdapter= null;
		
		if (type == TYPE.HTML) {
		entryAdapter =new EntryAdapter(htmlOutput, scrollPane);
		htmlOutput.setPreferredSize(new Dimension(WIDTH+WIDTH, HEIGHT*10));
		htmlOutput.attachHeader();
		htmlOutput.attachP("root");
		htmlOutput.attachEnder();
		htmlOutput.printPage();
		htmlOutput.setBackground(Color.pink);
		} else if (type== TYPE.TEXT) {
		entryAdapter =new EntryAdapter(textOutput);
		textOutput.setPreferredSize(new Dimension(WIDTH+WIDTH, HEIGHT));
		textOutput.setText("Text output");
		}
		
		expansionTree.addTreeSelectionListener(entryAdapter);
		expansionTree.addTreeExpansionListener(entryAdapter);
		
		//panelTree.setLayout(new FlowLayout());
		//panelTree.add(expansionTree);
				
		panelInner.setLayout(new BorderLayout());		
		panelInner.setPreferredSize(new Dimension(WIDTH*2, HEIGHT*20));		
		panelInner.add(BorderLayout.WEST, treeScrollPane);		
		if (htmlOutput !=null) {
		panelInner.add(BorderLayout.CENTER, htmlOutput);
		} else if (textOutput!=null) {
			panelInner.add(BorderLayout.CENTER, textOutput);
		}
		mainPane.add(scrollPane);
		super.pack();
		
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
	}
	public PathUtil pathUtil=null, pathUtilSave=null, pathUtilSystem;
	public void setPathUtil(PathUtil _pUtil, PathUtil _pUtilSave, PathUtil _pUtilSystem) throws KCMException {
		synchronized (root) {
			pathUtil = _pUtil;
			pathUtilSave = _pUtil;
			pathUtilSystem= _pUtilSystem;
			groupModel.setPathUtil(pathUtilSystem);
		}
	}
	private int indexEmailGroup=0, indexGroupBatch=0;
	private Entry entryBatchIteratePointer=null;
	private Iterator entryBatchIterator=null;
	
	
	public void reset() {		
		indexEmailGroup =0;
		entryBatchIterator=null;
		entryBatchIteratePointer=null;
		entryTagIterator=null;
		
	}
	public String provisionHeader() {
		if (entryBatchIteratePointer!=null) {
			return "Group:"+indexEmailGroup+"/"+root.children.size()+":"+ entryBatchIteratePointer.index;
		} else {
			return "Group:"+indexEmailGroup+"/"+root.children.size();
		}

	}
	public String extract(KCMObject _kcm, boolean _verbose) throws KCMException {
		StringBuffer sb = new StringBuffer(1028);
		if (_kcm== null) {
			throw new KCMException("Cannot extract handle lines from empty kcmObject");
		}
		sb.append(" Batch:"+(_kcm.directoryObject.version-200));
		
		for (int i=0; i < _kcm.entryList.size(); i++) {
			Entry en = _kcm.entryList.get(i);
			sb.append("\n"+en.line);
		}		
		
		return sb.toString();
	 
		
	}
	public String extract(ArrayList<Entry> _entryList, boolean _verbose) throws KCMException {
		StringBuffer sb = new StringBuffer(1028);

		if (_entryList==null) {
			throw new KCMException("Entry list for tags is null.");
		} 
		for (int i=0; i < _entryList.size(); i++) {
			Entry e = _entryList.get(i);
			sb.append(e.line);
			
		}
				
	    return sb.toString();
	}
public Entry iterateFilter() throws KCMException {
		
		Entry eItem = null;
		if (indexEmailGroup < 0) {
			throw new KCMException("Group Email is -1. Try resetting it to zero.");
		}
		do {
			eItem=iterate();
			
		}
		while (eItem !=null && !groupModel.bSendStatus(indexEmailGroup,  eItem.index));
		
		
		return eItem;
	
		
	}
	public Entry iterate() throws KCMException {
		Entry tagEntry =null;
		if (hasNext()) {
		  	tagEntry=(Entry)entryTagIterator.next();
		  	return tagEntry.batch;
		}
	  return null;
	}
	
	public boolean hasEmailBatchNext() throws KCMException {		
		Entry emailBatch=null;
		if (entryBatchIterator==null) {
			emailBatch = root.children.get(indexEmailGroup);	
			entryBatchIterator = emailBatch.children.iterator();
			return entryBatchIterator.hasNext();
			
			
		} else if (indexEmailGroup < root.children.size() &&
				entryBatchIterator !=null &&
				entryBatchIterator.hasNext()) {			
			
		  return true;	
		} else if (indexEmailGroup < root.children.size() &&
				entryBatchIterator != null &&
			  !entryBatchIterator.hasNext()) {				
			
			return false;
		} else {
			return false;
		}
		
		
		
	}
    private Iterator entryTagIterator=null;
	public boolean hasNext() throws KCMException {
	 Entry emailBatch=null;
	  if (hasEmailBatchNext() && entryTagIterator==null) {
		  emailBatch = root.children.get(indexEmailGroup);
		  entryTagIterator = emailBatch.children.iterator();
		  return entryTagIterator.hasNext();
	  } else if (hasEmailBatchNext() && entryTagIterator.hasNext()) {
		
		  return true;
		  
	  } else  if (hasEmailBatchNext() && !entryTagIterator.hasNext()) {
		  indexEmailGroup++;
		  if (indexEmailGroup == root.children.size()) {
			  return false;
		  }
		  emailBatch = root.children.get(indexEmailGroup);
		  entryTagIterator = emailBatch.children.iterator();
		  return entryTagIterator.hasNext();
		 
		  
		  
	  } else {
		  return false;
	  }
	}
		
	/*
	StringBuffer sb = new StringBuffer();
	if (htmlOutput!=null) {
	//sb.append(htmlOutput.extractModuloHeaderTag(HTMLOutput.TAG.TABLE));
	//sb.append(htmlOutput.extractBodyGroup(entry));
	} else if (textOutput!=null) {
		sb.append(textOutput.extractBody(entryBatch, false));

	}
	*/

	public void populateTree() throws KCMException {
		if (root.children !=null) {
		root.children.clear();
		} else {
			root.children = new ArrayList<Entry>();			
		}		
		if (pathUtil==null) {
			return;
		} else if (pathUtil.allFilesSync ==null) {
			root.children.add(new Entry( "pathUtil", groupModel));
			return;
		}
		ListIterator li=pathUtil.allFilesSync.listIterator();
		String nameString=null;		
		Batch batchPointer=null;		
		groupModel.resetIndex();
		int runningCount = groupModel.getIndex();		
		while (li.hasNext()) {		
			KCMObject kcmO = (KCMObject)li.next();
			String prefix = kcmO.directoryObject.getPrefix();						
			//batchPointer = new Batch(kcmO, runningCount);
			if (prefix.equals("BASIC")) {			
				  Entry nodeEntry= groupModel.allocateEntry(EntryType.BASIC, kcmO, runningCount);
				  			      
			      groupModel.addEntry(nodeEntry);		
			} else if (prefix.equals("CORE")) {		
				  Entry nodeEntry= groupModel.allocateEntry(EntryType.BASIC, kcmO, runningCount);
			  	  				  
				  groupModel.addEntry(nodeEntry);		
			} else if (prefix.equals("HEADER")) {				
				Entry nodeEntry = new Entry(Entry.EntryType.FACEBOOK_LINK, kcmO);				 
				entryAdapter.entryFacebook= nodeEntry;
				groupModel.addEntry(nodeEntry);
			}	
			runningCount++;
           
			
			
		}	
		 System.out.println("size of email lsit:"+ groupModel.listEmail.size());
			for (int i=0; i < groupModel.listEmail.size() ; i++) {
				EmailBatch eb = groupModel.listEmail.get(i);
				System.out.println("adding email group:"+i);
			    root.children.add(new Entry( eb));				
			}
		
		expansionTree.model.fireTreeStructureChanged(root);
		
		
	}
	public String getFacebookLink () {
		if (entryAdapter.entryFacebook!=null && entryAdapter.entryFacebook.bufferBody !=null &&
				entryAdapter.entryFacebook.bufferBody!=null) {
			return entryAdapter.entryFacebook.bufferBody.toString();
		}
		return null;
	}
	
}

package emailsender.html;

import java.awt.Color;

import javax.swing.JEditorPane;

import emailsender.KCMException;
import emailsender.PathUtil;
import emailsender.gui.Entry;
import emailsender.gui.GroupModel;

public class HTMLOutput extends JEditorPane {
  private String HEADER="<html>", ENDER="</HTML>";
  public enum TAG {NULL,P, UL, UI, TABLE, LI, RAW};
  private HElement pElement=null;
  private StringBuffer pBuffer=new StringBuffer();
  private GroupModel groupModel=null;
  private PathUtil pathUtil=null;
  public String description=null;
  public HTMLOutput() {
	  
  }
  public HTMLOutput(String _desc) {
	  description = _desc;
  }
  public HTMLOutput(GroupModel _groupModel) {
	  super();
	  setContentType("text/html");
	  pElement = new HElement(TAG.P);
	  groupModel = _groupModel;	  
  }
  public void setPathUtil(PathUtil _pathUtil) {
	  synchronized (pBuffer) {
		  pathUtil = _pathUtil;
//		  groupModel.setPathUtil(pathUtil);
	  }
  }
  
  public void printPage(String body) {
	  attachHeader();
	  attachP(body);
	  attachEnder();
	  printPage();
  }
  public void printPage() {
	  super.setText(pBuffer.toString());
  }
  public String getPageBuffer() {
	  return pBuffer.toString();
  }
  public void attachP(String _bodyText) {
	  pBuffer.append("<p>");
	  pBuffer.append(_bodyText);
	  pBuffer.append("</p>");
	  
  }
  public void attachRaw(String _rawText) {
	  pBuffer.append(_rawText);
  }
  public void attachHeader() {
	  pBuffer.setLength(0);
	  pBuffer.append(HEADER);
  }
  
  public void attachEnder() {
	  pBuffer.append(ENDER);
	  
  }
  private int  getGroup(int _index) {
	  if (_index < 200) {
		  return 1;
	  } else if (_index < 300) {
		  return 2;
	  } else if (_index < 400) {
		  return 3;
	  } else {
		  return 4;
	  }
 
  }
  public void attachHeaderGroup() {
	  attachP("Email Sender Batch:");
	  //attachP(groupModel.getModuloSendText());
  }

  public void attachBodyGroup(Entry _entry) throws KCMException {
	  int runningIndex = _entry.index;
	  attachP("Modulo info:");	  
	  if (_entry.children ==null) {
		  throw new KCMException("Error: Empty batch entries. Group needs an array of batch entries.");
	  }
	  attachP("Group number:"+ runningIndex +" to " +(runningIndex+_entry.children.size()));
	  for (int i=0; i < _entry.children.size(); i++) {
		  Entry en = _entry.children.get(i);
		  attachP(en.toString());
	  }
	  

  }

  public static String getTD(int _value) {
	  return "<td>"+ String.valueOf(_value)+ "</td>";
  }
  public static String getTD(int _value, int _col) {
	  return "<td colspan='"+_col+   "'>"
	  		+  String.valueOf(_value)+ "</td>";
  }
  public static String getTD(Color c,String _body, int _col) {
	  return "<td colpan='"+_col+"' bgcolor='"+ Integer.toHexString(c.getRGB())+"'>"+ _body + "</td>";
  }
  public static String getTD(String _body) {
	  return "<td >"+ _body + "</td>";
  }

  public String extractBodyGroup(Entry _entry) {
	  StringBuffer sb = new StringBuffer(1028);
	  int runningIndex = _entry.index;
	  sb.append("<table>");
	  sb.append("<tr><td>Tag</td>");	  
	  sb.append("<td>Group number</td>");	  
	  sb.append("<td>Modulo key</td>");
	  sb.append("<td> Send status</td>");
	  sb.append("</tr>");
	  
	  int groupModulo = groupModel.getGroup(runningIndex);
	  
	  for (int i=0; i < _entry.children.size(); i++) {
		  Entry en = _entry.children.get(i);
		 sb.append("<tr>");
		 sb.append(getTD(en.toString()));
		 sb.append(getTD(groupModulo));
		  sb.append("<td>"+ groupModel.getMaskKey(groupModulo, runningIndex+i)+"</td>");
		  sb.append("<td>"+ groupModel.getSendStatus(groupModulo, runningIndex+i)+"</td>");
		  sb.append("</tr>");
	  }
	  
	  sb.append("</table>");
	  return sb.toString();
  }
  public String extractModuloHeaderTag(HTMLOutput.TAG _tag) throws KCMException {
	  return groupModel.getModuloXmlSummary(_tag);
  }
  public void attachModuloHeaderTag(HTMLOutput.TAG _tag) throws KCMException {
	  
	  attachP(groupModel.getModuloXmlSummary(_tag));
  }
  public void attachModuloTag(int _runningIndex) {
	  attachP("Modulo info:");
	  
	  attachP("Group number:["+ getGroup(_runningIndex)+"]   ["+groupModel.getModulo(_runningIndex)+"]");
	  attachP("Tag index:"+_runningIndex);
  }
  public class HElement {
	  private TAG tag = TAG.NULL;
	  public HElement(TAG _t) {
		  tag = _t;
	  }
	  
  }
  public void createStructure() {
	  
  }
  
}

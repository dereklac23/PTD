package emailsender.html;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Stack;

import emailsender.html.StructureGeneral.token;
import emailsender.konagui.KCMException;

public class StructureTable extends StructureGeneral  {
    
    StringBuffer stringBuffer  = new StringBuffer();
    Color bgColor=null;
    String bgColorString=null;
    public StructureTable() {
     tokenList[token.HEAD.ordinal()] = "<tr>";
     tokenList[token.TAIL.ordinal()] = "</tr>";
     
    }
  
    
	

	
	public StructureGeneral  pull() {
		StructureGeneral sg = generalList.peek();
		if (sg!=null) {
			return generalList.pop();
		} else {
			return null;
		}
		
	}
	
	  private String getHeadToken(Color _bgColor) {
	    	if (_bgColor !=null) {
	    	return "<tr bgcolor='"+_bgColor+"'>";
	    	} else {
	    		return "<tr>";
	    	}
	    }
	    private String getHeadToken() {
	    	
	    	if (bgColorString !=null && bgColor==null){
	    		return "<tr bgcolor='"+bgColorString+"'>";
	    	}else if (bgColor !=null && bgColorString==null){
	    		return "<tr bgcolor='#"+Integer.toHexString(bgColor.getRGB())+"'>";
	    		
	     } else {
	    	
	    		return tokenList[token.HEAD.ordinal()];
	    }
	    }
	    public void attachColor(String _bgC) {
	    	bgColorString = _bgC;
	    }
	    private String getTailToken() {
	    	return tokenList[token.TAIL.ordinal()];
	    }
	public String snapShot() throws KCMException  {
		StringBuffer sb = new StringBuffer();
		
		for (int i=0;i < generalList.size(); i++) {
			StructureGeneral sg = generalList.get(i);
			sb.append(getHeadToken());			
			String result = sg.snapShot();
			//System.out.println("\n\n"+result);
			sb.append(sg.snapShot());
			sb.append(getTailToken());

			
		}
		

		return sb.append(stringBuffer.toString()).toString();
		
	}
	
	
	public String snapShotTableHead() throws KCMException  {
		StringBuffer sb = new StringBuffer();
		sb.append("<table>");
		sb.append(tokenList[token.HEAD.ordinal()]);
		
		for (int i=0;i < generalList.size(); i++) {
			StructureGeneral sg = generalList.get(i);
			String result = sg.snapShot();
			//System.out.println(result);
			sb.append(sg.snapShot());
		}
		sb.append(tokenList[token.TAIL.ordinal()]);
		sb.append("</table>");
		return sb.append(stringBuffer.toString()).toString();
		
	}

	public void push(StructureGeneral _sg) throws KCMException  {	
		generalList.push(_sg);		
		 
	}
  


	
	
	

	
}

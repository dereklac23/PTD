package releasetool.gui;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import releasetool.BookInfoUnit;
import releasetool.BookUtil;
import releasetool.FileEntry;
import releasetool.LocalContainer;
import releasetool.LocalInfoUtil;
import releasetool.gui.datamodel.*;



public class PropertiesPage  extends JPanel {
	private static int WIDTH=600, HEIGHT=150;	
	public SettingPageModel tableModelSettings=null;
	public BookPageModel tableModelBook=null;
	public JTable jTable;
	
	public ArrayList<LocalInfoUtil> pathList = new ArrayList<LocalInfoUtil>();
	public List<LocalInfoUtil> pathCollection=  Collections.synchronizedList(new ArrayList(pathList));
	
	public ArrayList<FileEntry> bookList = new ArrayList<FileEntry>();
	public List<FileEntry> 
    bookCollection=  Collections.synchronizedList(new ArrayList(bookList));
	
	public ArrayList<FileEntry> chapterList = new ArrayList<FileEntry>();
	public List<FileEntry> 
    chapterCollection=  Collections.synchronizedList(new ArrayList(bookList));
	
	public ArrayList<FileEntry> pageList = new ArrayList<FileEntry>();
	public List<FileEntry> 
    pageCollection=  Collections.synchronizedList(new ArrayList(bookList));
	
	
	
	
	public int indexPathList=0;
    public enum TYPE {SETTINGS, GTML};
    public TYPE type=TYPE.SETTINGS;
    public PropertiesPage(TYPE _t) {
        type = _t;
        if (_t == TYPE.SETTINGS) {
             tableModelSettings=new SettingPageModel(pathCollection);
        jTable  = new JTable(tableModelSettings);
        } else if (_t == TYPE.GTML){
        	 tableModelBook= new BookPageModel(bookCollection, chapterCollection, pageCollection);
        	 
        jTable  = new JTable(tableModelBook);
        }
    	
		JScrollPane scrollPane = new JScrollPane(
                jTable,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.getHorizontalScrollBar().setPreferredSize(new Dimension(	WIDTH+1600, 15));
		add(scrollPane);
		scrollPane.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		jTable.setPreferredScrollableViewportSize(new Dimension(WIDTH, HEIGHT));
		

	    super.setPreferredSize(new Dimension(WIDTH, HEIGHT+50));
    }
    
    public void setLocalInfo(int _index) {
    	indexPathList = _index;
    }
    public void addLocalInfoUtil(LocalInfoUtil _lfo) {
    	pathCollection.add(_lfo);
    	
    }
    	
    }

	

	


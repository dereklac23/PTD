package multiplatform;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;

import konagui.HTMLOutput;
import konagui.KonaTabbedPane;
import konagui.MenuHtml;
import konagui.MenuText;
import konagui.TEXTOutput;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;



public class MultiPlatform extends JFrame {
  /**
	 * 
	 */
  private static final long serialVersionUID = 1L;
  private static MultiPlatform multiP=null;
  private int WIDTH=600, HEIGHT=600, OFFSET=20;

  private JPanel mainPanel=null;
  private KonaTabbedPane tabbedPanel=null;
  
  public MultiPlatform() {
	  super("MultiPlatform");
	  JPanel panel = (JPanel) this.getContentPane();
	  panel.setLayout(new BorderLayout());
	  panel.add(BorderLayout.CENTER,mainPanel =  getCenterPanel());	  
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      mainPanel.setPreferredSize(new Dimension(WIDTH, HEIGHT));
      this.setSize(new Dimension(WIDTH, HEIGHT));
      this.setVisible(true);
  }

  private JPanel getCenterPanel() {
	  MenuText mt = new MenuText(new TEXTOutput());
	  
	  JPanel panel=new JPanel();
	  tabbedPanel = new KonaTabbedPane(WIDTH, HEIGHT);
	  tabbedPanel.allocate("html",  KeyEvent.VK_1, new MenuHtml(new HTMLOutput(), "Html"));
	  tabbedPanel.allocate("text",  KeyEvent.VK_2, mt);
	  tabbedPanel.freeze(panel);
	  return panel;
	  
  }
  public static void main(String args[]) {
	
	    SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
  }
	private static void createAndShowGUI() {
		multiP= new MultiPlatform();
      
    }
}


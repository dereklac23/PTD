package konagui;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JFileChooser;


public class ClickRename extends HCustomListener {

	public ClickRename(HTMLOutput _hOutput, String _action) {
		super(_hOutput, _action);
		// TODO Auto-generated constructor stub
	}

	JFileChooser chooser = new JFileChooser();
    File defaultDir=null;

// I don't want this to be hard-coded:
      //String filePath = "/Users/Bill/Desktop/hello.txt";
	

	public void execute() {
	    int returnValue = chooser.showSaveDialog(null) ;
	    if( returnValue == JFileChooser.APPROVE_OPTION ) {
	    	/*
	    	 *   File listFile [] =binFile.listFiles(new FileFilterSh());
	    	 *   int returnVal = fc.showSaveDialog(FileChooserDemo.this);
	    	 */
	    chooser.addChoosableFileFilter(new HFileFilter());
	    File file = chooser.getSelectedFile() ;
	    
	    try {
	    PrintWriter pw = new PrintWriter(  file);
	    //System.out.println("saved:"+ htmlOutput.getPageBuffer());
//	    pw.write(htmlOutput.getPageBuffer());
	    pw.close();
	    } catch (IOException ioe) {
	    	System.err.println("\nCannot write to file.");
	    }
	    
	    
	    
	    
	    
	    }
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printLink() {
		// TODO Auto-generated method stub
		
//		htmlOutput.attachRaw("<a href='rename'>Save</a>");
		
	}


	
}

package konagui;

import java.awt.Color;

import javax.swing.JEditorPane;




public class HTMLOutput extends JEditorPane {
  private String HEADER="<html>", ENDER="</HTML>";
  public enum TAG {NULL,P, UL, UI, TABLE, LI, RAW};
  private HElement pElement=null;
  private StringBuffer pBuffer=new StringBuffer();
  private GroupModel groupModel=null;
  private PathUtil pathUtil=null;
  public String description=null;
  public HTMLOutput() {
	  super.setBackground(Color.pink);
  }
  public HTMLOutput(String _desc) {
	  description = _desc;
  }
  public HTMLOutput(GroupModel _groupModel) {
	  super();
	  setContentType("text/html");
	  pElement = new HElement(TAG.P);
	  groupModel = _groupModel;	  
  }
  public void setPathUtil(PathUtil _pathUtil) {
	  synchronized (pBuffer) {
		  pathUtil = _pathUtil;

	  }
  }
  
  public void printPage(String body) {
	  attachHeader();
	  attachP(body);
	  attachEnder();
	  printPage();
  }
  public void printPage() {
	  super.setText(pBuffer.toString());
  }
  public String getPageBuffer() {
	  return pBuffer.toString();
  }
  public void attachP(String _bodyText) {
	  pBuffer.append("<p>");
	  pBuffer.append(_bodyText);
	  pBuffer.append("</p>");
	  
  }
  public void attachRaw(String _rawText) {
	  pBuffer.append(_rawText);
  }
  public void attachHeader() {
	  pBuffer.setLength(0);
	  pBuffer.append(HEADER);
  }
  
  public void attachEnder() {
	  pBuffer.append(ENDER);
	  
  }
  private int  getGroup(int _index) {
	  if (_index < 200) {
		  return 1;
	  } else if (_index < 300) {
		  return 2;
	  } else if (_index < 400) {
		  return 3;
	  } else {
		  return 4;
	  }
 
  }
  public void attachHeaderGroup() {
	  attachP("Email Sender Batch:");
	  //attachP(groupModel.getModuloSendText());
  }


  public static String getTD(int _value) {
	  return "<td>"+ String.valueOf(_value)+ "</td>";
  }
  public static String getTD(int _value, int _col) {
	  return "<td colspan='"+_col+   "'>"
	  		+  String.valueOf(_value)+ "</td>";
  }
  public static String getTD(Color c,String _body, int _col) {
	  return "<td colpan='"+_col+"' bgcolor='"+ Integer.toHexString(c.getRGB())+"'>"+ _body + "</td>";
  }
  public static String getTD(String _body) {
	  return "<td >"+ _body + "</td>";
  }

  public void attachModuloTag(int _runningIndex) {
	  attachP("Modulo info:");
	  
//	  attachP("Group number:["+ getGroup(_runningIndex)+"]   ["+groupModel.getModulo(_runningIndex)+"]");
	  attachP("Tag index:"+_runningIndex);
  }
  public class HElement {
	  private TAG tag = TAG.NULL;
	  public HElement(TAG _t) {
		  tag = _t;
	  }
	  
  }
  public void createStructure() {
	  
  }
  
}

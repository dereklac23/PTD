/**
 * 
 */
/**
 * 
 */
module PTCommons {
	requires java.desktop;
	exports konagui;
	
	
}
package mpdatamodel;
import ptgui.*;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import ptgui.ExpansionFrameGtml;
import ptgui.PropertiesPage;

public class BookListener implements ListSelectionListener {
	  private PropertiesPage propertiesPage=null;
	  private ExpansionFrameGtml expansionFrame=null;
	  private JTable jTable=null;
        public BookListener(PropertiesPage _propertiesPage, ExpansionFrameGtml _expansion ) {
        	jTable = _propertiesPage.jTable;
        	ListSelectionModel cellSelectionModel = jTable.getSelectionModel();
            cellSelectionModel.addListSelectionListener(this);
            jTable.setCellSelectionEnabled(true);


    	    cellSelectionModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        	
        }
     
	@Override
	public void valueChanged(ListSelectionEvent e) {
		  
		  String selectedData = null;

	        int[] selectedRow = jTable.getSelectedRows();
	        int[] selectedColumns = jTable.getSelectedColumns();
	          selectedData = (String) jTable.getValueAt(selectedRow[0], 0);
	            System.out.println("\nselected data"+ selectedData+":"+selectedRow[0]);
	  
		
	}

    
}

	

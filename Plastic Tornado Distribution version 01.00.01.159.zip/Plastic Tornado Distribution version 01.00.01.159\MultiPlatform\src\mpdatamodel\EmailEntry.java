package mpdatamodel;

public class EmailEntry {
 public String firstName = null, lastName =null;
 public String header[] = {"First Name", "Last Name"};
 public static int length=0;
 
 public EmailEntry (String _firName, String _lName) {
   firstName = _firName;
   lastName = _lName;
   length  = header.length;
}
}
 

package mpdatamodel;


import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

public class EmailSenderModel extends AbstractTableModel {
    private String[] columnNames = {
    		
    		"Email",
    		"First Name", 
    		"Last Name",
    		"Creation date",
    		"Category",
    		"Title",
    		"Tagline",    		
    		"Volume", 
    		"Series",
    		};
   private ArrayList<EmailEntry> emailCollection=null;
   public EmailSenderModel(ArrayList<EmailEntry> _email) {	   
	   emailCollection = _email;
   }
   public EmailSenderModel() {
	   emailCollection = new ArrayList<EmailEntry>();
   }
    public int getColumnCount() {
    	return EmailEntry.length; 

    }
 
    public int getRowCount() {
      return emailCollection.size();

    }

    public String getColumnName(int col) {
    	return "col";
        
        
    }
    

public Object getValueAt(int row, int col) {
    	
    	
     	return " ";
}


   
    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {	    
        return (col ==2);	        
    }

    public void setValueAt(Object value, int row, int column) {	        
        fireTableCellUpdated(row, column);
    }
}




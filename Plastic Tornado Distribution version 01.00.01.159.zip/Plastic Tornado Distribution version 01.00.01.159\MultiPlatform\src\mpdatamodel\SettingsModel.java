package mpdatamodel;


import java.io.File;
import java.net.URI;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.table.AbstractTableModel;

public class SettingsModel extends AbstractTableModel {
	public Path path=null;
	public URI uri=null;
	public enum TYPE {PATH, URI};
	public TYPE type = TYPE.PATH;
	private JPanel panel=null;
	
    private String[] columnNames = {    		
    		"Name",
    		"Path", 
    		"Active",
    		};
   private ArrayList<SettingsEntry> settingsCollection=null;
   public SettingsModel(ArrayList<SettingsEntry> _settings) {	   
	   settingsCollection = _settings;
   }
   public SettingsModel(JPanel _p) {
	   settingsCollection = new ArrayList<SettingsEntry>();	   
	   settingsCollection.add(new SettingsEntry("Working directory"));
	   settingsCollection.add(new SettingsEntry("Sandbox"));
	   settingsCollection.add(new SettingsEntry("URI"));
	   panel = _p;
	   path = FileSystems.getDefault().getPath(".");
	   
   }
   
   public void set(Path _pt) {
	   path = _pt;
   }
   
   public void setPath() {
	  
         JFileChooser fileChooser =new JFileChooser();
		 int returnVal = fileChooser.showOpenDialog(panel);

         if (returnVal == JFileChooser.APPROVE_OPTION) {
             File file = fileChooser.getSelectedFile();
             //fso.executeState(FileLevelService.FILE, FileStateType.CREATE,globalContainer);
             FileSystem fs =FileSystems.getDefault();
             fs.getPath(file.toString());
             		 
         }
             
             
             
            
	   
   }
    public int getColumnCount() {
    	return SettingsEntry.length; 

    }
 
    public int getRowCount() {
      return settingsCollection.size();

    }

    public String getColumnName(int col) {
    	return columnNames[col];
        
        
    }
    

public Object getValueAt(int row, int col) {
    	SettingsEntry se = settingsCollection.get(row);
    	String val = se.get(col);
    	
     	return se.get(col);
}


   
    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {	    
        return (col ==2);	        
    }

    public void setValueAt(Object value, int row, int column) {	        
        fireTableCellUpdated(row, column);
    }
}




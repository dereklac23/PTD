/**
 * 
 */
/**
 * 
 */
module PTCommons {
	requires java.desktop;
	exports ptgui;
	
	
}
package ptgui;
import ptdatamodel.*;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import pttools.BookInfoUnit;
import pttools.ChapterInfoUnit;
import ptdatamodel.Entry;
import ptdatamodel.FileEntry;
import pttools.GeneralUnit;
import pttools.LocalContainer;
import pttools.LocalInfoUtil;
import pttools.PageInfoUnit;
import ptgui.PepMan;
import ptgui.CustomTreeRenderer;
import ptdatamodel.EntryModel;
//import ptgui.ExpansionGtmlListener;
import ptdatamodel.ExpansionGtmlListener;

public class ExpansionFrameGtml extends JFrame {
    JPanel panelFrame=null;
    JTextArea taOutput=null;
    int pathUtilIndex= 0;
   
    private CenterPanel centerPanel=null;
    //private SouthPanel southPanel =null;
	public  enum SP_TYPE {REFRESH, ANNOTATE, FLATLINE};
	public SP_TYPE typeSP=SP_TYPE.REFRESH;
    public EntryTree eTree = null;
	public  Entry mRoot=null;
	EntryModel model; 
	private final static int WIDTH_WEST=150;
    public enum TYPE {SETTINGS,BOOK};
    public TYPE type= TYPE.SETTINGS;
    private ExpansionFrameGtml frameGtml=null;
    private JTextField jtDirectory = new JTextField(35);
	private JButton btnSet= new JButton("Set");
	public PropertiesPage propertiesPage=null;
	public ExpansionFrameGtml(String _title, LocalContainer _lc) {
		super(_title);
		frameGtml = this;
		setLayout(new BorderLayout());
		panelFrame= (JPanel) super.getContentPane();
		add(BorderLayout.CENTER,centerPanel = new CenterPanel());	
		super.setPreferredSize(new Dimension(PepMan.WIDTH+ WIDTH_WEST*2, PepMan.HEIGHT/2));				
		super.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		
		pack();		
	
		
	}
	
	private String getNullHandler(String _nullCase, Entry _e) {
		if (_e ==null) {
			return _nullCase;
		} else if (_e.getName()==null) {
			return _nullCase;
		} else return _e.getName(); 		
	}
	private LocalInfoUtil liuPointer=null;
	public void setLIUPointer(LocalInfoUtil _liu) {
		liuPointer = _liu;
		EntryModel eModel= (EntryModel)eTree.getModel();
		Entry entryRoot =(Entry)eTree.getModel().getRoot();
	 	entryRoot.children.removeAllElements();	 	
	 	entryRoot.children.add(new Entry(Entry.EntryType.STRING, "name"));
	 	eModel.fireTreeStructureChanged(entryRoot);
	 	
	}
	
	  ArrayList<FileEntry> allBooks = new ArrayList<FileEntry>();
      List<FileEntry> allBooksSync = Collections.synchronizedList(new ArrayList(allBooks));
      
      ArrayList<FileEntry> allPages= new ArrayList<FileEntry>();
      List<FileEntry> allPagesSync = Collections.synchronizedList(new ArrayList(allPages));
      
      ArrayList<FileEntry> allChapters= new ArrayList<FileEntry>();
      List<FileEntry> allChaptersSync = Collections.synchronizedList(new ArrayList(allChapters));
    
    private Entry entryExternal, entryInternal =null;
    public  void populateTree(List<FileEntry>_itemsSync, Entry _root) {
    	entryExternal = null;
    	entryInternal =null;
	 	for (int i=0; i < _itemsSync.size();i++) {
        FileEntry fileEntry= _itemsSync.get(i);
	 		if (fileEntry.type.equals(FileEntry.PAGE)) {
	 			Entry entryPage = new Entry(fileEntry);
	 			_root.children.add( entryPage);
	 		} else if (fileEntry.type.equals(FileEntry.BOOK_INTERNAL)) {
	 			
	 			//Entry entryBook = 
	 			entryInternal =new 
	 					Entry(fileEntry.maxIteration);
	 	       //_root.children.add(entryExternal);
	 		 	}
 		     else if (fileEntry.type.equals(FileEntry.BOOK_EXTERNAL)) {
 		    	 
 			entryExternal= new Entry(Entry.EntryType.BOOK, fileEntry);	
 	       _root.children.add(entryExternal);
 		 	} 
	 		else if (fileEntry.type.equals(FileEntry.CHAPTER)) {
	 		 	Entry entryChapter =new Entry(Entry.EntryType.CHAPTER, fileEntry); 	
	 		   _root.children.add(entryChapter);
		
    }
    }

	 	if (entryExternal !=null && entryInternal!=null) {
//	 		System.out.println("\nadding internal with max id"+ entryInternal.fileEntry.maxIteration);
	 		entryExternal.children.add(entryInternal);
	 		//entryInternal.children.add(entryExternal);
	 	}
    }
    
	public void updatePointer(PropertiesPage _propertiesPage, File _root) {
		synchronized (allBooksSync) {
			  EntryModel eModel= (EntryModel)eTree.getModel();
			  Entry root=(Entry)eModel.getRoot();
			populateTree(_propertiesPage.bookCollection,root);
			populateTree(_propertiesPage.chapterCollection,root);
			populateTree(_propertiesPage.pageCollection,root);
			
			eModel.fireTreeStructureChanged(root);	
		}

	}
	
	private class CenterPanel extends JPanel  implements ActionListener, HyperlinkListener{		 
		private JPanel westPanel =null;
		private JButton buttonList[]  = new JButton[SP_TYPE.values().length];
		HTMLOutput htmlOutput=null;
		CenterPanel() {
			super();
			setLayout(new BorderLayout());
			add(BorderLayout.EAST, htmlOutput = new HTMLOutput());
			add(BorderLayout.CENTER, eTree= new EntryTree(htmlOutput,getEntryTree()));
			eTree.setPreferredSize(new Dimension(WIDTH_WEST, PepMan.HEIGHT));
			htmlOutput.setPreferredSize(new Dimension(PepMan.WIDTH - WIDTH_WEST, PepMan.HEIGHT));
			htmlOutput.setBackground(new Color(246, 239, 239));
					
			add(BorderLayout.WEST, westPanel = new JPanel());
			westPanel.setPreferredSize(new Dimension(WIDTH_WEST, PepMan.HEIGHT));
			westPanel.setAlignmentX(JPanel.LEFT_ALIGNMENT);
			westPanel.add(buttonList[SP_TYPE.REFRESH.ordinal()]= new
			                         JButton("Refresh"));
			westPanel.add(buttonList[SP_TYPE.ANNOTATE.ordinal()]= new
                    JButton("Annotate"));
			westPanel.add(buttonList[SP_TYPE.FLATLINE.ordinal()]= new
                    JButton("Flat"
                    		+ ""
                    		+ "line"));
			westPanel.setPreferredSize(new Dimension(WIDTH_WEST,PepMan.HEIGHT));
			for (int i=0; i < buttonList.length-1; i++) {
				buttonList[i].setSize(new Dimension(100,50));
				buttonList[i].addActionListener(new ExpansionGtmlListener(frameGtml,i));
				
			}			
	        eTree.setPreferredSize(new Dimension(100, PepMan.HEIGHT/2));
	        add(eTree);
	        
	        htmlOutput.setEditable(false);
	        htmlOutput.addHyperlinkListener(this);
			
		}
		
	

		public Entry getEntryTree() {
			mRoot = new Entry(Entry.EntryType.STRING,"Entry-->");
			Entry kids[] = new Entry[2];
			Entry  eRoot=new Entry(Entry.EntryType.STRING,"Content:");
			Entry fRoot = new Entry(Entry.EntryType.STRING,"Folder");
			
			kids[0]= eRoot;
			kids[1]= fRoot;
			
			Entry.linkFamily(mRoot, kids);
			pathUtilIndex=0;
			
			return eRoot;
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			TreeModel tModel = eTree.getModel();
			Entry entryRoot =(Entry)eTree.getModel().getRoot();
		
			
		}



		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			// TODO Auto-generated method stub
			System.out.println("\n expansion frame hyer link activated");
		}
		
	}
	
	private class SouthPanel extends JPanel implements ActionListener  {
		JFrame parent=null;
		SouthPanel(JFrame _parent) {
			super();
			parent = _parent;
			setLayout(new FlowLayout());
			add(new JLabel("Directory:"));
			add(jtDirectory);
			add(btnSet);
			btnSet.addActionListener(this);
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			if (liuPointer ==null) {
				return;
			}
			synchronized (liuPointer) {
			File selectedFile=null;
			 JFileChooser chooser = new JFileChooser();
			 chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		        chooser.setCurrentDirectory(new File("."));
		        chooser.setMultiSelectionEnabled(true);
		        int option = chooser.showOpenDialog(this);
		        if (option == JFileChooser.APPROVE_OPTION) { 
		        	selectedFile = chooser.getSelectedFile();
		        }
		        if (selectedFile !=null) {
		       
		        liuPointer.setAttributeFile(selectedFile);
		        parent.setVisible(false);
		        EntryModel eModel= (EntryModel)eTree.getModel();
		        eModel.fireTreeStructureChanged(mRoot);
		        if (type == TYPE.SETTINGS) {
		        	propertiesPage.tableModelSettings.fireTableDataChanged();
		        } else if (type == TYPE.BOOK) {
		            propertiesPage.tableModelBook.fireTableDataChanged();
		        }
		        }
		        //propertiesPage.fir
			};
		   propertiesPage.tableModelBook.fireTableDataChanged();	
		}
		
	}
	
public class EntryTree extends JTree {
    
    private HTMLOutput htmlOutput=null;
    public EntryTree( HTMLOutput _hOutput,Entry _entryNode) {
    	
        super(model=new EntryModel(_entryNode));
        
        getSelectionModel().setSelectionMode(
                TreeSelectionModel.SINGLE_TREE_SELECTION);
        
        Icon personIcon = null;
        setCellRenderer(new CustomTreeRenderer(_hOutput));
    }
     
    
    /**
     * Get the selected item in the tree, and call showAncestor with this
     * item on the model.
     */
    public void showAncestor(boolean b) {
        Object newRoot = null;
        TreePath path = getSelectionModel().getSelectionPath();
        if (path != null) {
            newRoot = path.getLastPathComponent();
        }
       ((EntryModel)getModel()).showAncestor(b, newRoot);
    }

   }




}
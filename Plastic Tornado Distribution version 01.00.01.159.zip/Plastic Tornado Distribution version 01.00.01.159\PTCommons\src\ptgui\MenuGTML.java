package ptgui;
import pttools.*;
import ptdatamodel.*;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import pttools.BookInfoUnit;
import pttools.BookUtil;
import pttools.ChapterInfoUnit;
import ptdatamodel.FileEntry;
import pttools.GeneralUnit;
import pttools.KCMException;
import pttools.ListFilesRecurse;
import pttools.LocalInfoUtil;
import pttools.PageInfoUnit;
//import pttools.PepMan;

import ptdatamodel.BookListener;
import ptdatamodel.HCustomListener;
import ptsets.GeneralSets;

public class MenuGTML extends JPanel implements  ActionListener{
	private ArrayList<ButtonSelection> btnList = new ArrayList<ButtonSelection>();
	public HTMLOutput editorMain=null;
	private JComboBox<ButtonSelection> comboPointer=null;
	private JButton btnBook = null;
	  public ExpansionFrameGtml popupGtml=null;
	  public PropertiesPage propertiesPage=null;
	  public List<LocalInfoUtil> pathCollection=  null;
	  public BookListener bookListener =null;

	
	public MenuGTML(PanelStruct panelS, JComboBox<ButtonSelection> _comboPointer, ArrayList<ButtonSelection> btnPackageList) {
		btnList = btnPackageList;
		btnBook = new JButton("Open Book Rendering Dialog");
		comboPointer  = _comboPointer;
		setLayout(new BorderLayout());
		add(BorderLayout.NORTH, propertiesPage = new PropertiesPage(PropertiesPage.TYPE.GTML));
		
		
		editorMain= new HTMLOutput();
		JScrollPane scrollPane = new JScrollPane(
                editorMain,
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.getHorizontalScrollBar().setPreferredSize(new Dimension(	WIDTH+1600, 15));		
		add(BorderLayout.CENTER, scrollPane);
		//scrollPane.add(editorMain);
		
		add(BorderLayout.SOUTH, btnBook);
		btnBook.addActionListener(this);		
		editorMain.setContentType("text/html");		
		//editorMain.addHyperlinkListener(new HCustomListener());
		editorMain.setPreferredSize(new Dimension(PepMan.WIDTH-PepMan.OFFSET,PepMan.HEIGHT/2-PepMan.OFFSET));
		editorMain.attachHeader();
		
		editorMain.attachP("Welcome to the GTML page! Create once, and run everywhere!");
		editorMain.attachP("Create your books, chapters, and pages using GTML.");
		editorMain.attachP("Let your imagination roll starting at 'gtml' directory as a bundled jar files and or local sandboxed files." );
		
		editorMain.attachEnder();
		editorMain.printPage(); 
			
		bookListener = new BookListener(propertiesPage, popupGtml);
		}
		//editorHtml.removeh
	
	
	private String getTag(String _tag, String _value) {
		StringBuffer sb = new StringBuffer();
		sb.append("<p>");
		sb.append("<" + _tag + ">");
		sb.append("<"+_value+">");
		sb.append("</p>");
		
		return sb.toString();
		
	}
	private String getTagRaw(String _tag, String _value) {
		StringBuffer sb = new StringBuffer();
		
		sb.append("<" + _tag + ">");
		sb.append("<"+_value+">");
		
		
		return sb.toString();
		
	}
	private String getPathString(Path _p) {
		
		StringBuffer sb = new StringBuffer(1028);
        
		editorMain.attachRaw("<td >"+_p.toString()+"</td>");
		
		return sb.toString();
		
	}
	BookUtil bookUtil = null;
	
	public FileEntry processEntry(File _root, Path _p) {
		bookUtil = new BookUtil();
		StringBuffer sb = new StringBuffer(1028);		
		Path pathEntry=_p.getFileName();
		FileEntry fEntry=null;
		String matcherEntry =null;
		try {
		fEntry = new FileEntry( _p);
		matcherEntry = fEntry.getString();
		} catch (KCMException ioe) {
			System.err.print("\nInternal regex error");
		}

		if (matcherEntry ==null) {
			
			//editorMain.attachTagTRHead(HTMLOutput.COLOR_GRAY) ;
			//editorMain.attachTagTD(COLOR_TEAL, 20, "Internal regular expression code error:"+pathEntry.toString()+":"+ fEntry.ordinalPointer);
			//editorMain.attachTagTRTail();
					
		}else if (fEntry.type==null) {
			//editorMain.attachTagTRHead(COLOR_GRAY);
			//editorMain.attachTagTD(COLOR_TEAL, 20, "Internal regular expression code error"+pathEntry.toString()+":"+ fEntry.ordinalPointer);			
			//editorMain.attachTagTRTail();
		} else if (fEntry.type.equals(FileEntry.BOOK_EXTERNAL)){
			HashMap<String,BookInfoUnit> mapList=null;			
			
			try {
			
			mapList=bookUtil.processBookXml(_root,  _p);
			fEntry.setBookAttributes( mapList);
			//editorMain.attachTagTRHead(COLOR_GRAY);
			//editorMain.attachTagTD(COLOR_VIOLET1,  COLOR_VIOLET2,5,5,  "Tag type:",fEntry.getTagSplit(0));
			//editorMain.attachTagTD(COLOR_VIOLET1,  COLOR_VIOLET2, 5,5,  "Unique identifier:",fEntry.getTagSplit(1));
			
			
			//editorMain.addPageSet(new GeneralSets());
			//editorMain.attachTagTD(COLOR_VIOLET1,  COLOR_VIOLET2, 5,5,  "Iteration number:",fEntry.getTagSplit(2));			
			//editorMain.attachTagTRTail();
			//fEntry.printMap();
			
			
			} catch (KCMException ioe) {
				
			}
		}  else if (fEntry.type.equals(FileEntry.CHAPTER)){
			try {
				ArrayList<ChapterInfoUnit> pList=null;
				pList=bookUtil.processChapterXml(_root,  _p);
				fEntry.setChapterAttributes( pList);
				//editorMain.attachTagTD(COLOR_VIOLET1,  COLOR_VIOLET2,5,5,  "Tag type:",fEntry.getTagSplit(0));
				//editorMain.attachTagTD(COLOR_VIOLET1,  COLOR_VIOLET2, 5,5,  "Unique identifier:",fEntry.getTagSplit(1));
				//editorMain.attachTagTD(COLOR_VIOLET1,  COLOR_VIOLET2, 5,5,  "Iteration number:",fEntry.getTagSplit(2));

				
				} catch (KCMException ioe) {
					
				}
			editorMain.attachRaw(getTagTRHead(COLOR_GRAY) + 
					getTagTD(COLOR_TEAL, 20,matcherEntry) + 
					getTagTRTail());
			
		}else if (fEntry.type.equals(FileEntry.PAGE)){
			try {
              
			PageInfoUnit piu  = new PageInfoUnit(_p);
			fEntry.piu= piu;
			} catch (KCMException kcm) {
				System.err.println("\nError: file not found:"+_p.toString());
			}
			
			editorMain.attachRaw(
					getTagTRHead(COLOR_GRAY) +
					getTagTD(COLOR_TEAL, 25,"Page:"+ matcherEntry) +
					getTagTRTail());
			
		}

			
			
	
	return fEntry;		
	
	}
	private final static String COLOR_TEAL = "0xAAE0BDBD", COLOR_GRAY = "#add8e6", COLOR_VIOLET1 ="B284BE", COLOR_VIOLET2 = "B2A4FB";

	private String getTagTRTail() {
		return "</tr>";
				
	}
	private String getTagTD(String _color,int _colSpan, String _body) {
		StringBuffer sb  = new StringBuffer(1048);
		
		sb.append("<td bgcolor='"+
		  _color+
		  "' colspan='"+
		  _colSpan+
		  "' >"+
		  _body+
		  "</td>");		

		return sb.toString();
	}
	private String getTagTRHead(String _color) {
		StringBuffer sb  = new StringBuffer(1048);
		sb.append("<tr bgcolor='"+_color+"'>");		
		return sb.toString();
	}

	public void processEntries(File _root,ArrayList<Path> _pl) {
		FileEntry  fEntry=null;
		editorMain.attachP("Entry:");

		editorMain.attachRaw("<table bgcolor='0xFFAAFAFA'>");
		StringBuffer sb = new StringBuffer(1024);
		for (int i=0; i < _pl.size(); i++) {
			fEntry=processEntry(_root,_pl.get(i));
			if (fEntry !=null && fEntry.type !=null &&  
					(fEntry.type.equals(FileEntry.BOOK_EXTERNAL) ||
					 fEntry.type.equals(FileEntry.BOOK_INTERNAL))) {
			propertiesPage.bookCollection.add(fEntry);
			} else if (fEntry !=null && fEntry.type !=null && fEntry.type.equals(FileEntry.CHAPTER)) {				
			propertiesPage.chapterCollection.add(fEntry);	
			} else if (fEntry !=null && fEntry.type != null && fEntry.type.equals(FileEntry.PAGE)) {
			propertiesPage.pageCollection.add(fEntry);				
			}
		}
	    editorMain.attachRaw("</table>");
		
	}
	
	
		
		
		
	
		
	
		
	public void resetCombo() {
		comboPointer.removeAllItems();
		btnList.forEach(btnS->comboPointer.addItem(btnS));
	}
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		propertiesPage.tableModelBook.fireTableDataChanged();
		popupGtml.setVisible(true);
	}

	public ExpansionFrameGtml allocate(ExpansionFrameGtml _control) {
		// TODO Auto-generated method stub
		popupGtml = _control;
		popupGtml.propertiesPage = propertiesPage;
		return _control;
	}
	



private final static String headerGTML = "gtml";

	 
public void updatePointer(File _gtmlDir,ArrayList<Path> _pathList) throws KCMException  {
		editorMain.attachHeader();
		if (_pathList.size()==0) {
			editorMain.attachP("There are no entries under 'gtml' directory. Please copy templates in $PTD/doc directory");
		}
		editorMain.attachP("Main entries:"+  _pathList.size());
		synchronized (popupGtml) {
			
			propertiesPage.bookCollection.clear();
			propertiesPage.chapterCollection.clear();
			propertiesPage.pageCollection.clear();
		/* processing each individual pointer */
		
		processEntries(_gtmlDir,_pathList);    
		
		popupGtml.updatePointer(propertiesPage, _gtmlDir);
		}

		propertiesPage.tableModelBook.fireTableDataChanged();
		editorMain.attachEnder();
		editorMain.printPage();
}


	public ExpansionFrameSettings allocate(ExpansionFrameSettings _control) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

	/*
	public void renderEntry(ChapterInfoUnit _cu) {
		if (_cu==null) {
			return;
		}
		StringBuffer sb = new StringBuffer();
		if (_cu.root!=null) {
		sb.append(getTag("root",_cu.root.getParent()));
		}
	
		if (_cu.header !=null) {
		sb.append(getTag("header",_cu.header));
		}
		if (_cu.body!=null) {
			sb.append(getTag("body",_cu.body));
			}
		
		editorMain.attachRaw(sb.toString());
		
	}
	*/
/*
	public void renderEntry(PageInfoUnit _pu) {
		if (_pu==null) {
			return;
		}
		StringBuffer sb = new StringBuffer();
		if (_pu.root!=null) {
		sb.append(getTag("root",_pu.root.getParent()));
		}
	
		if (_pu.header !=null) {
		sb.append(getTag("header",_pu.header));
		}
		if (_pu.body!=null) {
			sb.append(getTag("body",_pu.body));
			}
		
		editorMain.attachRaw(sb.toString());
		
	}

	public void renderEntry(BookInfoUnit _bu) {
		if (_bu==null) {
			return;
		}
		StringBuffer sb = new StringBuffer();
		if (_bu.root!=null) {
		sb.append(getTag("root",_bu.root.getParent()));
		}
	
		if (_bu.header !=null) {
		sb.append(getTag("header",_bu.header));
		}
		if (_bu.body!=null) {
			sb.append(getTag("body",_bu.body));
			}
		
		editorMain.attachRaw(sb.toString());
		
	}
	*/
}

	




package emailsender;
import emailsender.konagui.*;
import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;

import emailsender.konagui.KCMException;

public class DirectoryObject {
		public int version;
		private String prefix=null;
		public File root=null;
		public Matcher matcher =null;
		   
		public File fileDirectoryTarget=null;
		public DirectoryObject () {
			
		}
		public DirectoryObject(File _targetF) {
			fileDirectoryTarget=_targetF;
		}
		public boolean isHeader() {
			if (prefix ==null) {
				return false;
			} else if (prefix.equals("CORE")) {
				return true;
			}else if (prefix.equals("HEADER")) {
				return true;
			}
			else if (prefix.equals("BASIC")) {
				return true;
			}
			return false;
		}
		
		public DirectoryObject (String _prefix,Matcher matcher)  throws KCMException {
			if (matcher ==null) {
				throw new KCMException("\nRegex did not get any matches because matcher is zero");
			}
			System.out.println("\n direcotyr objhect for:"+ _prefix);
			prefix = matcher.group(0);
			try {
			version = Integer.parseInt(matcher.group(1));
			} catch (NumberFormatException ne) {
				
			}
			
		}
		public String getVersionString() {
			return String.valueOf(version);
		}
		public String getPrefix() {
			return prefix;
		}

		public boolean isTagFile() {
			return prefix !=null && prefix.endsWith(".txt");
		}
		public String getKeyTag() {
			return prefix +":"+version;
		}
		public boolean bCoreType() {
			return prefix.equals("CORE");
		}
		public DirectoryObject (File _root,String _prefix,Matcher matcher)  throws KCMException {	
			
			if (matcher ==null) {
				throw new KCMException("\nRegex did not get any matches for:"+_prefix);				
			}	
			if (_root==null) {
				throw new KCMException("File root is null.");
			}

			prefix = matcher.group(0);
				try {
				version= Integer.parseInt(matcher.group(1));
				} catch (NumberFormatException nfe ) {
					throw new KCMException("Cannot extract batch number with matcher:"+matcher.group()+":" + 
				matcher.groupCount() + ":<"+prefix+">");
							
				}
			
			prefix = prefix.splitWithDelimiters("\\.",  0)[0];
			root =_root;
		}
						
		
}
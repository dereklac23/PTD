package emailsender;
import emailsender.konagui.*;

import emailsender.gui.*;
import emailsender.html.TEXTOutput;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;





public class SenderGui {

	private static SenderGui senderGui=null;
	private  enum PANEL_TYPE {  HTML,TEXT, CUBE_CONTROL, PVM, HELP};
	JFrame frame=null;
	public  SenderGui() {		
		    frame = new JFrame("Sender Tool");
	        JPanel panel = (JPanel) frame.getContentPane();
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(600, 700);
	        
	        // Add a label to the frame
	        JLabel label = new JLabel("Sender Tool!", JLabel.CENTER);
	        panel.setLayout(new BorderLayout());
	        panel.add(BorderLayout.NORTH, getNorthPanel());
	        panel.add(BorderLayout.CENTER, getCenterPanel());
	        panel.add(BorderLayout.SOUTH, getSouthPanel());
	        frame.setVisible(true);
	}
    private	int countCommand=0;
	private void doPrintMenu() {
		
		System.out.println("\n1) Load up Annotation SenderGui.xml\nE) Exit\nOptions: [1,E]\n["+countCommand+
				"]>:");
		countCommand++;
	}
	private PathUtil pathUtil=null, pathUtilSystem, pathUtilSave=null;
	
	private void doLoadAnnotation() throws KCMException {
		
		pathUtilSystem= new PathUtil(new File("bin/EmailSender.xml"));
		System.out.println("\nDone loadng annotation");
	}
	private SenderGui(String _command) {
		if (!_command.equals("-commandline")) return;
		

		try {
		BufferedReader bReader= new BufferedReader(new InputStreamReader(System.in));
		doPrintMenu();
		String line=bReader.readLine();
		while (line !=null) {
			
			if (line.equals("1")) {
				doLoadAnnotation();
			} else if (line.equals("E") || line.equals("e")) {
				System.out.println("\nExited SenderGui");
				return;
			}
			doPrintMenu();
			line = bReader.readLine();
		}
		} catch (IOException ioe ) {
			System.err.println("\nError in  reading input");
		} catch (KCMException kce) {
			System.err.println("KCM error"+ kce.toString());
		}
		
		
	}
	public static void main(String args[] ) {
		if (args.length==1 ) {
		  	senderGui= new SenderGui(args[0]);
		} else {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
		}
	}
	private static void createAndShowGUI() {
		senderGui= new SenderGui();
      
    }

    private JTable jTable=null;
	private JPanel getNorthPanel() {
		
		
		JPanel panel = new JPanel();
                 		
	
		JButton btnAction =new JButton("Provision directory");
		   btnAction.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	try {
	               	performProvision();
	            	}catch (KCMException kcm) {
	            		System.err.println("\nKCMException :"+kcm.toString());
	            	}
	            	jEditor.printPage("Done performing provision size");
	            	
	            }
	        });
		panel.add(btnAction);
		
		JButton btnReset =new JButton("Reset");
	       btnReset.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	           
	            	expansionFrameHtml.reset();
	            	expansionFrameText.reset();
	           
	            	jEditor.printPage("Resetting");
	            	
	            }
	        });
	       
			JButton btnIterate =new JButton("Iterate");
		       btnIterate.addActionListener(new ActionListener() {
		            @Override
		            public void actionPerformed(ActionEvent e) {		            	
		            	int counter=0;
		            	try {
		            	StringBuffer sb = new StringBuffer(1028);
		            	String text=null;
		            	int selectedIndex= kTabPanel.tabbedPanel.getSelectedIndex();
		            	if (selectedIndex== kTabPanel.getTabbedIndexHtml()) {
		            	sb.append(expansionFrameHtml.provisionHeader());	
		            	sb.append(expansionFrameHtml.iterate());
		            	text = sb.toString();
		            	kTabPanel.htmlOutput.editorHtml.printPage(text);
		            	pathUtilSystem.copyToClipboard(text);
		            	} else if (selectedIndex == kTabPanel.getTabbedIndexText()) {
		            		
		            		sb.append(expansionFrameText.provisionHeader()); 
		            		Entry entry=null;
		            		if (pathUtilSystem.bIterateFilter ) {
		            		entry=expansionFrameText.iterateFilter();
		            		
		            		} else {
		            		
		            			entry=expansionFrameText.iterate();
		            		}
		            			counter++;
		            			if (entry!=null) {
		            			sb.append(expansionFrameText.extract(entry.kcmObject,false));
		            			} else {
		            				sb.append("End");
		            			}
		            			
		            			
		            		
			            	
			            	String fbLink = expansionFrameText.getFacebookLink();
			            	if (fbLink!=null) {
			            	sb.append("\n\n"+expansionFrameText.getFacebookLink());
			            	}
			            	text = sb.toString();
			            	
			            	kTabPanel.textOutput.editor.setText(text);
			            	kTabPanel.validate();
			            	
			            	pathUtilSystem.copyToClipboard(text);
			            	
		            	}
		            	
		            	
		            	
		            	
		            	} catch (KCMException kcm) {
		            		System.err.println("\nError in kcm:"+kcm.toString());
		            	}
		            	
		            
		            	
		            }
		        });


		panel.add(btnAction);
		panel.add(btnReset);
		panel.add(btnIterate);
		//panel.add(jbGroup);
		ComboRenderer cr = new ComboRenderer();
		//jbGroup.setRenderer(cr);
		return panel;
	}
	
	private JButton btnExpansionHtml=null, btnExpansionText=null;
	public final static int WIDTH=500, HEIGHT=500;
	private ExpansionFrame expansionFrameHtml=null, expansionFrameText=null;
	private JPanel getSouthPanel() {
    	expansionFrameHtml = new ExpansionFrame(ExpansionFrame.TYPE.HTML);
    	expansionFrameHtml.setPreferredSize(new Dimension(WIDTH+WIDTH/2, HEIGHT));
    	expansionFrameHtml.pack();    	
    	

    	expansionFrameText = new ExpansionFrame(ExpansionFrame.TYPE.TEXT);
    	expansionFrameText.setPreferredSize(new Dimension(WIDTH+WIDTH/2, HEIGHT));
    	expansionFrameText.pack();    	
    	

		JPanel panel = new JPanel();
		panel.add(btnExpansionHtml=new JButton(("Open Expansion Frame Html")));
		btnExpansionHtml.addActionListener(  new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               expansionFrameHtml.setVisible(true);      
                      	
            	
            }
        });
		panel.add(btnExpansionText=new JButton(("Open Expansion Frame Text")));
		btnExpansionText.addActionListener(  new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               expansionFrameText.setVisible(true);      
                      	
            	
            }
        });

		return panel;
		
	}
	private HTMLOutput jEditor=null;
	private PanelStruct panelArray [] = new PanelStruct[PANEL_TYPE.values().length];
	private MenuHtml menuHtml =null; 
	private MenuText menuText=null;
	private JTextArea jTextArea=null;
	private JTabbedPane tabbedPane=null;
	private  KonaTabbedPane kTabPanel=null;
	private JPanel getCenterPanel() {
		JPanel panel = new JPanel();
		tabbedPane = new JTabbedPane();		
		jEditor=new HTMLOutput();
		jTextArea = new JTextArea();
		kTabPanel = new KonaTabbedPane( WIDTH, HEIGHT);
		
		
		kTabPanel.allocate("Settings",KeyEvent.VK_1, new MenuHtml(new HTMLOutput(), "Settings version 1.0.00.100"));
		kTabPanel.allocate("JTree Html", KeyEvent.VK_3, new MenuHtml(new HTMLOutput(), "HTML"));
		kTabPanel.allocate("Twitter Text", KeyEvent.VK_2, new MenuText(new JTextArea()));
		

		
		
	    kTabPanel.freeze(panel);	

		
		return panel;
	}
	private String targetDirString="data", targetDirBin="bin/data/x";
	
	
	private void performProvision() throws KCMException {	
		
		
		if (pathUtil !=null || pathUtilSystem!=null) {
			jEditor.printPage("\nNo need to create a new path util");
		}

		File fileTarget = new File(targetDirString);
		pathUtil = new PathUtil(new File(targetDirBin), jEditor);		
		pathUtilSystem= new PathUtil(new File("bin/data/x/EmailSender.xml"), jEditor);
		jEditor.setPathUtil(pathUtilSystem);
		expansionFrameHtml.setPathUtil(pathUtil, pathUtilSave, pathUtilSystem);
		
		expansionFrameHtml.populateTree();		
		expansionFrameText.setPathUtil(pathUtil, pathUtilSave, pathUtilSystem);		
		expansionFrameText.populateTree();

		
				
		frame.revalidate();
		
		}
}
	
	



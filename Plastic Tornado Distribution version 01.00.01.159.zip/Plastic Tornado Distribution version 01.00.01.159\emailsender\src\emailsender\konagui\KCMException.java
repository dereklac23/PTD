package emailsender.konagui;

public class KCMException extends Exception {
    public String description=null;
	public KCMException(String des) {
		description = des;
	}
	public String toString() {
		return description;
	}
	
}

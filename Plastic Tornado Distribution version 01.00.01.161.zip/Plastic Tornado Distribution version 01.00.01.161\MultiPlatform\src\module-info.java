/**
 * 
 */
/**
 * 
 */
module MultiPlatform {
	requires java.desktop;
	requires transitive PTCommons;
	//requires konagui;
	
	//requires konagui;
//	requires konagui;
//	reques emailsender;
}
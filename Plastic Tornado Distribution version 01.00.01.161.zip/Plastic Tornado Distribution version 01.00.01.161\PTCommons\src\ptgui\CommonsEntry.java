package ptgui;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;



import javax.swing.JPanel;
import javax.swing.SwingUtilities;



public class CommonsEntry extends JFrame {
  /**
	 * 
	 */
  private static final long serialVersionUID = 1L;
  private static CommonsEntry commonsEntry=null;
  private int WIDTH=600, HEIGHT=600;

  private JPanel mainPanel=null;
  private KonaTabbedPane tabbedPanel=null;
  
  public CommonsEntry() {
	  super();
	  JPanel panel = (JPanel) this.getContentPane();
	  panel.setLayout(new BorderLayout());
	  panel.add(BorderLayout.CENTER,mainPanel =  getCenterPanel());	  
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      mainPanel.setPreferredSize(new Dimension(WIDTH, HEIGHT));
      this.setSize(new Dimension(WIDTH, HEIGHT));
      this.setVisible(true);
  }
  private JPanel getCenterPanel() {
	  
	  JPanel panel=new JPanel();
	  tabbedPanel = new KonaTabbedPane(WIDTH, HEIGHT);
	  tabbedPanel.allocate("html",  KeyEvent.VK_1, new MenuHtml(new HTMLOutput(), "Html"));
	  tabbedPanel.allocate("text",  KeyEvent.VK_2, new MenuText(new TEXTOutput()));
	  tabbedPanel.freeze(panel);
	  return panel;
	  
  }
  public static void main(String args[]) {
	
	    SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
  }
	private static void createAndShowGUI() {
		commonsEntry= new CommonsEntry();
      
    }
}


package ptgui;
//import releasetool.SeafloorExec.ATTR;
import ptgui.*;
import ptgui.ButtonSelection.BSTypeDistribution;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import ptdatamodel.ComboRenderer;
import pttools.KCMException;
import pttools.LocalContainer;
import pttools.LocalInfoUtil;
//import pttools.PathExec;





public class PepMan implements ChangeListener {
	

	private static PepMan pepMan =null;
	public  enum PANEL_TYPE {  SETTINGS,PACKAGING,  GTML, CLASSPATH_JAR, CLASSPATH_SANDBOX};
	public enum EntryType { STAGING, TARGET, CLASSPATH, DISTRIBUTE}
	private String targetDirString="c:\\users\\derek\\eclipse-workspace\\dist\\lib";
	LocalInfoUtil pathSettings=null;
    LocalInfoUtil pathGtml =null;
    LocalInfoUtil pathPackage=null;
    LocalInfoUtil classpathJar=null, classpathSandbox=null, classpathWorking=null;
	private HTMLOutput htmlOutput=null;
	public static final int WIDTH=700,HEIGHT=800, OFFSET=150;
	
	JComboBox<ButtonSelection> jCombo[];
	JComboBox<ButtonSelection> comboPointer=null;
	private PanelStruct panelArray [] = new PanelStruct[PANEL_TYPE.values().length];

	public ButtonSelection selectPointer= null;
	JPanel framePanel=null;
	private JFrame globalFrame=null;
	public  PepMan() {
		
		    globalFrame= new JFrame("PepMan");
		    framePanel = (JPanel) globalFrame.getContentPane();
	        globalFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        globalFrame.setSize(PepMan.WIDTH, PepMan.HEIGHT);
	        // Add a label to the frame
	        JLabel label = new JLabel("Release Tool!", JLabel.CENTER);
	        framePanel.setLayout(new BorderLayout());
	        
      
	        jCombo = new JComboBox[PANEL_TYPE.values().length];
	        jCombo[PANEL_TYPE.SETTINGS.ordinal()] = new JComboBox <ButtonSelection>();	        
	        jCombo[PANEL_TYPE.PACKAGING.ordinal()] = new JComboBox<ButtonSelection> ();
	        jCombo[PANEL_TYPE.GTML.ordinal()] = new JComboBox <ButtonSelection>();
	        
	        ArrayList<ButtonSelection> listSetting= new ArrayList<ButtonSelection>();
	        listSetting.add(new ButtonSelection(ButtonSelection.BSTypeSettings.CONFIGURE,"Configure the selected node"));
	        
	        listSetting.forEach(btnSetting->jCombo[PANEL_TYPE.SETTINGS.ordinal()].addItem(btnSetting));
	        
	        
	        
	        ArrayList<ButtonSelection> listDistribution= new ArrayList<ButtonSelection>();
	        listDistribution.add(new ButtonSelection(BSTypeDistribution.COPY_KCM,"Copy files from Stagging to Plastic Tornado Distribution."));
	        listDistribution.add(new ButtonSelection(BSTypeDistribution.COPY_TOMCAT,"Copy files to tomcat."));
	        listDistribution.forEach(btnDistribution->jCombo[PANEL_TYPE.PACKAGING .ordinal()].addItem(btnDistribution));
	     
	        
	        ArrayList<ButtonSelection> listGTML2 = new ArrayList<ButtonSelection>();	        
	        listGTML2.add(new ButtonSelection(BSTypeDistribution.LOAD_GTML, ButtonSelection.BSTypeSettings.CLASSPATH,"Load 'gtml' at working directory"));
	        listGTML2.add(new ButtonSelection(BSTypeDistribution.LOAD_GTML, ButtonSelection.BSTypeSettings.SANDBOX,"Load GTML at sandboxed directory"));
	        listGTML2.add(new ButtonSelection(BSTypeDistribution.LOAD_GTML, ButtonSelection.BSTypeSettings.BUNDLED_JAR,"Load GTML in a bundled jar file"));
	        listGTML2.forEach(btnHelp->jCombo[PANEL_TYPE.GTML.ordinal()].addItem(btnHelp));
	     
	        
	        framePanel.add(BorderLayout.NORTH, getNorthPanel());
	      
	        
		        
	        globalFrame.setLocationRelativeTo(null);
	        globalFrame.setVisible(true);    
	        
	        performProvision();
	        
	        
	        

	}
	private LocalContainer localContainer= null;
	//PathExec pathExec=null;
	
	
	
	
	public static void main(String args[] ) {
		if (args.length ==1 && args[0].equals("-commandline")) {
			File  rootDev= new File("D:\\dev");
		
		} else {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
		}
		
	}
	
	
	private static void createAndShowGUI() {
        // Create the frame
		pepMan = new PepMan();      
    }
	
    private JPanel controlPanel =null;
    private JButton btnGo =null;
	private JPanel getNorthPanel() {
  		controlPanel= new JPanel();
  		controlPanel.setLayout(new FlowLayout());		   
		   btnGo=new JButton("Go");
	       btnGo.addActionListener(new ActionListener() {
	            @Override
	            
	            //selectPointer is done at the ComboRenderer
	            public void actionPerformed(ActionEvent e) {
	            	try {
	            	if (selectPointer==null) {
	            		 
	            	} else if (selectPointer.typeDistribution == ButtonSelection.BSTypeDistribution.COPY_KCM) {
	            		performCopy();
	            	} else if (selectPointer.typeDistribution == ButtonSelection.BSTypeDistribution.COPY_TOMCAT) {
	            		performCopyWar2Tomcat();
	            	} else if (selectPointer.typeDistribution == ButtonSelection.BSTypeDistribution.LOAD_GTML) {
	            		performLoadGtml(selectPointer.typeSettings);          		
	            		
	            	} else if (selectPointer.typeSettings== ButtonSelection.BSTypeSettings.CONFIGURE) {
	            		performConfigureSetting(selectPointer.typeSettings);
	            	}
	            	
	            	}catch  (KCMException kcp) {
	            		System.err.println("\nError:"+kcp);
	            	} catch (IOException ioe) {
	            		System.out.println("\nIOE"+ ioe.toString());
	            	}
	            	
	            }
	        });
        synchronized (globalFrame) {
		controlPanel.add(comboPointer=jCombo[PANEL_TYPE.SETTINGS.ordinal()]);
        }
		controlPanel.add(btnGo);
		
		return controlPanel;
	}
	
	
	
	
	private MenuPackage menuPackage = null;
	private MenuSettings menuSettings=null;
	
	private MenuGTML menuGtml= null;
	//private MenuHelp menuHelp=null;
	
	private JTabbedPane tabbedPane=null;
	private void performCopy() throws IOException {		
		pathPackage.performCopy();
	}
	
  
	private void performCopyWar2Tomcat () throws KCMException {
		File fileTarget = new File(targetDirString);
		
	}
	
	
	private class MyModel extends DefaultComboBoxModel {
		
	}
	public class MyActionListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}
	@Override
	public void stateChanged(ChangeEvent e) {
		int index = tabbedPane.getSelectedIndex();
		synchronized (globalFrame) {			
		comboPointer=jCombo[index];
		controlPanel.removeAll();
		controlPanel.add(comboPointer);
		controlPanel.add(btnGo);
		}
		
		controlPanel.repaint();
		globalFrame.pack();
		tabbedPane.revalidate();
		JRootPane panelRoot=tabbedPane.getRootPane();
		panelRoot.revalidate();
		
		
	
		
	}
	
	private void performLoadGtml(ButtonSelection.BSTypeSettings _typeSettings) throws KCMException {
		if (_typeSettings == ButtonSelection.BSTypeSettings.CLASSPATH) {
        //pathExec.doExecute(ButtonSelection.BSTypeDistribution.LOAD_GTML, classpathJar);
		} else if (_typeSettings == ButtonSelection.BSTypeSettings.SANDBOX) {
		//pathExec.doExecute(ButtonSelection.BSTypeDistribution.LOAD_GTML, classpathSandbox);
			
		}
   }

	
	private void performConfigureSetting(ButtonSelection.BSTypeSettings _typeSetting) {		
		 if (_typeSetting == ButtonSelection.BSTypeSettings.CONFIGURE) {			 
			// pathExec.doExecute(SeafloorExec.ATTR.ENODE_ENTRY, classpathJar);
		 }
	}
	private void performProvision() {
		
		pathSettings =												
				new LocalInfoUtil(
				EntryType.STAGING,
				
				"Staging",							
				menuSettings);	
		
		pathPackage = new LocalInfoUtil(
				EntryType.TARGET,
				"Packaging",
				new File("D:\\dev"),
				menuPackage);  
		
    	pathGtml =
				new LocalInfoUtil(
				EntryType.DISTRIBUTE,
				"Distribute",
				menuGtml);	
		
		classpathJar =
				new LocalInfoUtil(
				EntryType.CLASSPATH,
				"Bundled jar path",
				new File("bin"), 
				menuGtml);
		
		classpathSandbox =
				new LocalInfoUtil(
				EntryType.CLASSPATH,
				"Local sandbox path", 
				menuGtml);
			
		classpathWorking=
				new LocalInfoUtil(
				EntryType.CLASSPATH,
				"Local working directory", 
				menuGtml);

				
				

		LocalInfoUtil pathSet[] = new LocalInfoUtil[5];
		pathSet[PANEL_TYPE.SETTINGS.ordinal()]= pathSettings;		
		pathSet[PANEL_TYPE.PACKAGING.ordinal()]= pathPackage;
		pathSet[PANEL_TYPE.GTML.ordinal()]= pathGtml;
		pathSet[PANEL_TYPE.CLASSPATH_JAR.ordinal()] = classpathJar;
		pathSet[PANEL_TYPE.CLASSPATH_SANDBOX.ordinal()] = classpathSandbox ;
		
		

		
		//localContainer.menuSettings =menuSettings;
		localContainer = new LocalContainer(pathSet, menuSettings, menuGtml);		
		localContainer.comboPointerGTML=jCombo[PANEL_TYPE.GTML.ordinal()];
		
		
		//localContainer.mainFrame = globalFrame;
		
		//pathExec = new PathExec(localContainer);
		
		
			
			
		
		menuSettings.propertiesPage.addLocalInfoUtil(pathSettings); //0
		menuSettings.propertiesPage.addLocalInfoUtil(pathPackage); ///1
		menuSettings.propertiesPage.addLocalInfoUtil(pathGtml); //2
		menuSettings.propertiesPage.addLocalInfoUtil(classpathJar); //3
		menuSettings.propertiesPage.addLocalInfoUtil(classpathSandbox); //4
		menuSettings.propertiesPage.addLocalInfoUtil(classpathWorking); //5
		
		

 	  
		
		
		File fileTarget = new File(targetDirString);
		
	}
	
	

}



package emailsender.gui;

import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import emailsender.konagui.HTMLOutput;


public class EntryTreeTemp extends JTree {
    
    private HTMLOutput htmlOutput=null;
    public EntryModel model=null;
    public EntryTreeTemp( HTMLOutput _hOutput,Entry _entryNode) {
    	
//    	 super(model=new EntryModel(_entryNode));
    	super.setModel(new EntryModel(_entryNode));
        
        getSelectionModel().setSelectionMode(
                TreeSelectionModel.SINGLE_TREE_SELECTION);
        
        Icon personIcon = null;
        setCellRenderer(new CustomTreeRenderer2());
    }
     
    
    /**
     * Get the selected item in the tree, and call showAncestor with this
     * item on the model.
     */
    public void showAncestor(boolean b) {
        Object newRoot = null;
        TreePath path = getSelectionModel().getSelectionPath();
        if (path != null) {
            newRoot = path.getLastPathComponent();
        }
       ((EntryModel)getModel()).showAncestor(b, newRoot);
    }

   }


package emailsender.html;

import java.util.Stack;

import emailsender.konagui.KCMException;

public abstract class StructureGeneral {
  public Stack<StructureGeneral> generalList= new Stack<StructureGeneral>();

  public String tokenList [] = new String[token.values().length];
  public abstract  void push(StructureGeneral _sg) throws KCMException ;
  public abstract StructureGeneral pull()  throws KCMException ;
  public abstract String snapShot() throws KCMException ;
  public enum token {HEAD, TAIL, SUBHEAD, SUBTAIL, PHEAD, PTAIL};
}
   
package emailsender.html;

import java.awt.Color;
import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.Stack;

import emailsender.html.StructureTD.TYPE;
import emailsender.konagui.KCMException;

public class StructureTR extends StructureGeneral  {
    StringBuffer stringBuffer = new StringBuffer();
    Color bgColor=null;
    String debug="Debug", bgColorString=null;
	public enum TYPE {INT, STRING,BOOLEAN, NULL}
	public TYPE type = TYPE.NULL;
	
    
    public StructureTR() {
     tokenList[token.HEAD.ordinal()] = "<tr>";
     tokenList[token.TAIL.ordinal()] = "</tr>";
     tokenList[token.SUBHEAD.ordinal()]="<td>";
     tokenList[token.SUBTAIL.ordinal()]="</td>";
     tokenList[token.PHEAD.ordinal()]="<p>";
     tokenList[token.PTAIL.ordinal()]="</p>";
     
     
    }
    private String getHeadToken(Color _bgColor) {
    	if (_bgColor !=null) {
    	return "<tr bgcolor='"+_bgColor+"'>";
    	} else {
    		return "<tr>";
    	}
    }
    private String getHeadToken() {
    	
    	if (bgColorString !=null && bgColor==null){
    		return "<tr bgcolor='"+bgColorString+"'>";
    	}else if (bgColor !=null && bgColorString==null){
    		return "<tr bgcolor='#"+Integer.toHexString(bgColor.getRGB())+"'>";
    		
     } else {
    	
    		return tokenList[token.HEAD.ordinal()];
    }
    }
    private String getSubHeadToken() {
    	
    	if (bgColorString !=null && bgColor==null){
    		return "<p bgcolor='"+bgColorString+"'>";
    	}else if (bgColor !=null && bgColorString==null){
    		return "<p bgColor='"+bgColor+"'>";  
    		
     } else {
    	
    		return tokenList[token.SUBHEAD.ordinal()];
    }
    }

    public void attachColor(String _bgC) {
    	bgColorString = _bgC;
    }
    private String getSubTailToken() {
    	return tokenList[token.SUBTAIL.ordinal()];
    }

    private String getTailToken() {
    	return tokenList[token.TAIL.ordinal()];
    }
    public String tokenString =null;
    public StructureTR(String _line) {
    	this();
    	tokenString=_line;    	
    	type = TYPE.STRING;
    	
    	stringBuffer.append("\n");
    	stringBuffer.append(getHeadToken());
    	stringBuffer.append(getSubHeadToken());
    	stringBuffer.append(tokenList[token.PHEAD.ordinal()]);
    	stringBuffer.append(_line);
    	stringBuffer.append(tokenList[token.PTAIL.ordinal()]);
    	stringBuffer.append(getSubTailToken());
    	stringBuffer.append(getTailToken());
    	
    }
    public Boolean tokenBoolean=null;
    public StructureTR(Boolean _bValue) {
    	this();
    	tokenBoolean=_bValue;    	
    	type = TYPE.STRING;
    	
    	stringBuffer.append("\n");
    	stringBuffer.append(getHeadToken());
    	stringBuffer.append(getSubHeadToken());
    	stringBuffer.append(tokenList[token.PHEAD.ordinal()]);
    	stringBuffer.append(tokenBoolean);
    	stringBuffer.append(tokenList[token.PTAIL.ordinal()]);
    	stringBuffer.append(getSubTailToken());
    	stringBuffer.append(getTailToken());
    	
    }
    public int tokenInt=0;
    public StructureTR(int _value) {
    	this();
    	tokenInt = _value;    	
    	type = TYPE.INT;
    	
    	stringBuffer.append("\n");
    	stringBuffer.append(getHeadToken());
    	stringBuffer.append(getSubHeadToken());
    	stringBuffer.append(tokenList[token.PHEAD.ordinal()]);
    	stringBuffer.append(tokenInt);
    	stringBuffer.append(tokenList[token.PTAIL.ordinal()]);
    	stringBuffer.append(getSubTailToken());
    	stringBuffer.append(getTailToken());
    	
    }


		
	
	public void attach(Color _bgColor)  {	
		bgColor = _bgColor;
		renewBuffer();
	}
	public void attach(String _debug) {
		debug=_debug;
	}
	public StructureGeneral pull() throws KCMException {		
		StructureGeneral sg = generalList.peek();
		if (sg!=null) {
			return generalList.pop();
		} else {
			return null;
		}
		
	}
	private void renewBuffer() {
		stringBuffer.setLength(0);
		stringBuffer.append(getHeadToken());
		stringBuffer.append(getSubHeadToken());
    	stringBuffer.append(tokenList[token.PHEAD.ordinal()]);
		if (type == TYPE.INT) {
	    	stringBuffer.append("\n");
	    	stringBuffer.append(getHeadToken());	    	
	    	stringBuffer.append(tokenString);
		} else if (type == TYPE.STRING) {
			stringBuffer.append(tokenString);
		} else if (type == TYPE.BOOLEAN) {
			stringBuffer.append(tokenBoolean);
		}
    	stringBuffer.append(tokenList[token.PTAIL.ordinal()]);
    	stringBuffer.append(getSubTailToken());
    	stringBuffer.append(getTailToken());


		
	}
	public String snapShot() throws KCMException  {
		StringBuffer sb = new StringBuffer();		
		for (int i=0;i < generalList.size(); i++) {
			StructureGeneral structG = generalList.get(i);
			if (structG instanceof StructureTD) {
			StructureTD structTD =(StructureTD) structG;
			String result = structTD.snapShot();
			if (result !=null) {
			//

			sb.append("\n"+getSubHeadToken());
			sb.append(result);
			sb.append(getSubTailToken());
			//
			}
			
			} else if (structG instanceof StructureTR) {
				StructureTR structTR1=(StructureTR) structG;
				
                                        
	            	sb.append(structTR1.stringBuffer.toString());
	            	//sb.append(getSubTailToken());
	            
				sb.append(getHeadToken());
				for (int j=0; j < structG.generalList.size(); j++) {					
					StructureTD structTD2 =(StructureTD) structG.generalList.get(j);
					sb.append(getSubHeadToken());
					sb.append(structTD2.snapShot());
					sb.append(getSubTailToken());
					}
				sb.append(getTailToken());
					
				}
				
			}
			
		return stringBuffer.toString() + sb.toString();
		
	}
	
	public void push(StructureGeneral _sg) throws KCMException  {
		//stringBuffer.append(_sg.pull());
		renewBuffer();
		generalList.push(_sg);
		// TODO Auto-generated method stub
		 
	}
	

	
	}


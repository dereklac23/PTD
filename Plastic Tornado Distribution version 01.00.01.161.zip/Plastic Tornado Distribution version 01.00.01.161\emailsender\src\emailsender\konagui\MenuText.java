package emailsender.konagui;



import java.awt.BorderLayout;
import java.awt.Dimension;


import javax.swing.JPanel;
import javax.swing.JTextArea;

import emailsender.SenderGui;

public class MenuText extends JPanel {
    public JTextArea editor=null;
    private String htmlIndexPage=null;
	public MenuText(JTextArea jText) {
		super();
		add(BorderLayout.NORTH, jText);

		editor = jText;
		editor.setText("Welcome to Send Email with Text");
		editor.setPreferredSize(new Dimension(SenderGui.WIDTH, SenderGui.HEIGHT));		
		
		
	}  

}

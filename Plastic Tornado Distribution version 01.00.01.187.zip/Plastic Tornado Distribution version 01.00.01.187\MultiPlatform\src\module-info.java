/**
 * 
 */
/**
 * 
 */
module MultiPlatform {
	requires java.desktop;
	requires emailsender;
	requires PTCommons;
	//opens ptcommons.PTCommons;
	//requires emailsender.SenderGui;
	//opens emailsender;
	//requires konagui;
	
	//requires konagui;
//	requires konagui;
//	reques emailsender;
}
package multiplatform;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

import emailsender.gui.ExpansionFrameEmail;
import mpdatamodel.SettingsListener;
import mpdatamodel.SettingsModel;
import ptgui.ExpansionFrameGtml;
import ptgui.ExpansionFrameSettings;
import ptgui.HTMLOutput;
import ptgui.KonaTabbedPane;
import ptgui.MenuHtml;
import ptgui.MenuText;
import ptgui.PropertiesPage;
import ptgui.TEXTOutput;


public class MultiPlatform extends JFrame {
  /**
	 * 
	 */
  private static final long serialVersionUID = 1L;
  private static MultiPlatform multiP=null;
  private int WIDTH=600, HEIGHT=600, OFFSET=20;
  private JPanel mainPanel=null;
  private KonaTabbedPane tabbedPanel=null;
  private JPanel southPanel =null,  northPanel=null;
  
  public MultiPlatform() {
	  super("MultiPlatform");
	  JPanel panel = (JPanel) this.getContentPane();
	  panel.setLayout(new BorderLayout());
	  panel.add(BorderLayout.NORTH, northPanel = getNorthPanel());
	  panel.add(BorderLayout.CENTER,mainPanel =  getCenterPanel());
	  panel.add(BorderLayout.SOUTH, southPanel = getSouthPanelExpansion());
	  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      mainPanel.setPreferredSize(new Dimension(WIDTH+OFFSET*3, HEIGHT/5*2+HEIGHT+OFFSET*2));      
      this.setSize(new Dimension(WIDTH+OFFSET*3, HEIGHT/5*2+HEIGHT+OFFSET*2));
      this.setVisible(true);
  }

  private JPanel getCenterPanel() {
	  JPanel panel = new JPanel();
	  MenuText mt = new MenuText(new TEXTOutput());	  
	  tabbedPanel = new KonaTabbedPane(WIDTH, HEIGHT-OFFSET);
	  tabbedPanel.allocate("Settings",  KeyEvent.VK_1, new MenuHtml(new HTMLOutput(), "Settings"));
	  tabbedPanel.allocate("Email Sender",  KeyEvent.VK_2, new MenuHtml(new HTMLOutput(), "Email Sender"));
	  tabbedPanel.allocate("Music Reactant",  KeyEvent.VK_3, mt);
	  tabbedPanel.freeze(panel);
	  return panel;	  
  }
  private JButton btnExpansion=null;
  private JPanel getSouthPanel() {
	  JPanel panel = new JPanel();
	  panel.setLayout(new BorderLayout());
	  panel.add(btnExpansion=new JButton("Expansion frame"));
	  btnExpansion.addActionListener(new ExpansionListener(settingsModel));
	  return panel;
  }
  public SettingsModel settingsModel=null;
  private SettingsListener settingsListener=null;
  private JPanel getNorthPanel() {
	  PropertiesPage pp = null;
	  JPanel panel = new JPanel();
	  panel.setLayout(new BorderLayout());
	  settingsModel= new SettingsModel(panel);	  
	  panel.add(pp=new PropertiesPage(PropertiesPage.TYPE.SETTINGS,WIDTH, HEIGHT/5, settingsModel ));
	  settingsModel.fireTableDataChanged();	 
	  settingsListener= new SettingsListener(pp, null);	
	  return panel;	  
  }
  public static void main(String args[]) {	
	    SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
  }
	private static void createAndShowGUI() {
		multiP= new MultiPlatform();
      
    }
	
	private ExpansionFrameEmail expansionFrameHtml=null;
	private ExpansionFrameEmail expansionFrameText=null;
	private JButton btnExpansionHtml =null, btnExpansionText=null;
	
	private JPanel getSouthPanelExpansion() {
    	expansionFrameHtml = new ExpansionFrameEmail(ExpansionFrameEmail.TYPE.HTML);
    	expansionFrameHtml.setPreferredSize(new Dimension(WIDTH+WIDTH/2, HEIGHT));
    	expansionFrameHtml.pack();    	
    	

    	expansionFrameText = new ExpansionFrameEmail(ExpansionFrameEmail.TYPE.TEXT);
    	expansionFrameText.setPreferredSize(new Dimension(WIDTH+WIDTH/2, HEIGHT));
    	expansionFrameText.pack();    	
    	

		JPanel panel = new JPanel();
		panel.add(btnExpansionHtml=new JButton(("Open Expansion Frame Html")));
		btnExpansionHtml.addActionListener(  new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               expansionFrameHtml.setVisible(true);      
                      	
            	
            }
        });
		panel.add(btnExpansionText=new JButton(("Open Expansion Frame Text")));
		btnExpansionText.addActionListener(  new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               expansionFrameText.setVisible(true);      
                      	
            	
            }
        });

		return panel;
		
	}
	
	private class ExpansionListener implements ActionListener {
         AbstractTableModel atm=null;
		
		ExpansionListener(AbstractTableModel _atm) {
			atm=_atm;
		}
		@Override
		public void actionPerformed(ActionEvent e) {			
			atm.fireTableDataChanged();
			//pp.
			// TODO Auto-generated method stub
			//pp.
		}
		
	}
}


package emailsender.html;
import java.awt.Color;
//import emailsender.html.StructureGeneral;
import java.util.ArrayList;
import java.util.EmptyStackException;
import java.util.Stack;

import emailsender.html.StructureGeneral.token;
import emailsender.konagui.KCMException;

public class StructureTD extends StructureGeneral {
	public enum TYPE {INT, STRING,BOOLEAN, NULL}
	public TYPE type = TYPE.NULL;
	
	public Color bgColor=null;
	public String stringColor=null;
	public StringBuffer stringBuffer = new StringBuffer(1028);
    
    public StructureTD() {
        tokenList[token.HEAD.ordinal()] = "<td>";
        tokenList[token.TAIL.ordinal()] = "</td>";
        tokenList[token.SUBHEAD.ordinal()] = "<P>";
        tokenList[token.SUBTAIL.ordinal()] = "</p>";
     
    }
    
    public int tokenInt=0;
    public boolean tokenBoolean=false;
    
    private String getHeadToken(Color _bgColor) {
    	if (_bgColor ==null && stringColor==null) {
    	return "<td>";	
    	} else {
    	
    	return "<td bgColor='"+stringColor+"'>";
    	}
    }
    private String getHeadToken() {
    	if (bgColor ==null && stringColor==null) {
    		return "<td>";
    				
    	} else if (bgColor==null && stringColor!=null) {
    		return "<td bgColor='"+stringColor+"'>";
    	}
    	else {
    		return tokenList[token.HEAD.ordinal()];
    		
    }
    }
    private String getTailToken() {
    	return tokenList[token.TAIL.ordinal()];
  
    }
    
    private String getSubHeadToken() {
    	if (bgColor ==null && stringColor==null) {
    		return "<p>";
    				
    	} else if (bgColor==null && stringColor!=null) {
    		return "<p bgColor='"+stringColor+"'>";
    	}
    	else {
    		return tokenList[token.SUBHEAD.ordinal()];
    		
    }
    }
    private String getSubTailToken() {
    	return tokenList[token.SUBTAIL.ordinal()];
  
    }
    
    
	public void push( String _token) {
		if (_token !=null ) {
		type = TYPE.STRING;		
		stringBuffer.append(getSubHeadToken());
		stringBuffer.append(_token);
		stringBuffer.append(getSubTailToken());
		}
		
	}
    public void push( int _tokenInt) {
    	type = TYPE.INT;
    	stringBuffer.append(getHeadToken());
		stringBuffer.append(Integer.toString(_tokenInt));
		stringBuffer.append(getTailToken());		
	}
	public StructureTD(int _tokenInt) {
		this();
		type = TYPE.INT;
		stringBuffer.append(getHeadToken());
		stringBuffer.append(Integer.toString(_tokenInt));
		stringBuffer.append(getTailToken());
		tokenInt = _tokenInt;
		
	}
	public StructureTD(String _token) {
		this();
		if (_token !=null) {
		type = TYPE.STRING;
		stringBuffer.append(getHeadToken());
		stringBuffer.append(_token);
		stringBuffer.append(getTailToken());
		tokenString = _token;

		
		}
	}
	public String tokenString=null;
	public StructureTD(boolean _bValue) {
		this();
		type = TYPE.BOOLEAN;
		stringBuffer.append(getHeadToken());
		stringBuffer.append(_bValue);
		stringBuffer.append(getTailToken());
		tokenBoolean = _bValue;
		
	}
	private String debugMessage = null;
	public void attach(String _debug) {
		debugMessage= _debug;
	}
	public void attachColor(String _color) {
		stringColor=_color;
	}
	private String getDebugMessage() {
		if (debugMessage !=null) {
			return "Error in snapshot:"+ debugMessage;
		} else {
			return "Error in TD stack";
		}
	}
	 
	public StructureGeneral  pull() throws KCMException {
		try {
		StructureGeneral sg = generalList.peek();
		if (sg!=null) {
			return generalList.pop();
		} else {
			return null;
		}
		} catch (EmptyStackException ese) {
			throw new KCMException(getDebugMessage());
		}
		
	}
	public String snapShot() throws KCMException  {
		StringBuffer sb = new StringBuffer();
		
		sb.append("\n"+stringBuffer.toString());
		
		
		sb.append(getHeadToken());
		for (int i=0;i < generalList.size(); i++) {			
			StructureGeneral structG = (StructureGeneral) generalList.get(i);
			if (structG instanceof StructureTD) {			
			StructureTD structTD =(StructureTD) generalList.get(i);
			    //sb.append(tokenList[token.SUBHEAD.ordinal()]);
			     if (structTD.type== TYPE.BOOLEAN) {
			     sb.append(getSubHeadToken());
			     sb.append(structTD.tokenBoolean);
			     sb.append(getSubTailToken());
			     } else if (structTD.type== TYPE.INT) {
				     sb.append(getSubHeadToken());
				     sb.append(structTD.tokenInt);
				     sb.append(getSubTailToken());
				  } else if (structTD.type == TYPE.STRING) {
					  sb.append(getSubHeadToken());
					  sb.append(structTD.tokenString);
					  sb.append(getSubTailToken());
				  }
				
				
				
			} else if (structG instanceof StructureTR) {
				
			}
			
		}
		sb.append(getTailToken());
		
		
		return sb.toString();
	}
	
	public void push(StructureGeneral _sg) throws KCMException  {
		
		
		generalList.push(_sg);
		// TODO Auto-generated method stub
		 
	}

	
}

package ptgui;


import java.util.List;

import javax.swing.table.AbstractTableModel;

import pttools.BookInfoUnit;
import pttools.BookUtil;

import ptdatamodel.FileEntry;
import pttools.LocalInfoUtil;
public class BookPageModel extends AbstractTableModel {
    private String[] columnNames = {
    		
    		"Author First Name",
    		"Author Last Name", 
    		"Publish date",
    		"Creation date",
    		"Category",
    		"Title",
    		"Tagline",    		
    		"Volume", 
    		"Series",
    		};
    private List<FileEntry> bookPageCollection=null, chapterCollection=null, pageCollection=null;
   public BookPageModel(List<FileEntry>_book, List<FileEntry> _chapter, List<FileEntry> _page) {
	   bookPageCollection=_book;
	   chapterCollection = _chapter;
	   pageCollection= _page;
   }
    public int getColumnCount() {
    	return BookInfoUnit.TYPE_STRING.length;

    }
 
    public int getRowCount() {
    	int count=0;
        for (int i=0; i < bookPageCollection.size(); i++) {
        	FileEntry fEntry = bookPageCollection.get(i);
        	if (fEntry.type == FileEntry.BOOK_EXTERNAL) {
        		count++;
        	}
        }
        
        return  count;

    }

    private String getTagKey(int _col) {
    	String strList[] = BookInfoUnit.TYPE_STRING[_col].split("/");
        if (strList !=null && strList.length > 1) {
        	return strList[1];
        } else return null;
    }
    public String getColumnName(int col) {
        String key=null;
        
        
        return getTagKey(col);    
        
        
    }
    

public Object getValueAt(int row, int col) {
    	
    	
        int index = row;
        
     	if (bookPageCollection.size() > 0 && row < bookPageCollection.size() ) {
        	FileEntry fEntry= bookPageCollection.get(row);
        	if (fEntry==null) {
        	 return "empty";   	
            } else if (fEntry.type == FileEntry.BOOK_EXTERNAL) {
            	return fEntry.getColumnValue(BookInfoUnit.getKey(col));
        
            } else {
     	return "no book";
    	}
    }
     	return " ";
}


   
    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {	    
        return (col ==2);	        
    }

    public void setValueAt(Object value, int row, int column) {	        
        fireTableCellUpdated(row, column);
    }
}




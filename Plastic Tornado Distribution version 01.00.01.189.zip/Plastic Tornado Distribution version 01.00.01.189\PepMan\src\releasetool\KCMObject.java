package releasetool;

import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class KCMObject {
    public File directoryPointer=null;
    
    private final static String  PREFIX="Plastic Tornado Distribution version ",PROJECT_PREFIX="PLASTIC_TORNADO", 
    		KMP="KMP.war", StarShip ="StarShip.jar", PepMan ="PepMan.jar", MultiPlatform ="MultiPlatform.jar", 
    		DEV_ROOT="C:\\users\\derek\\eclipse-workspace\\dist\\lib";
    private File fileKMP, fileStarShip, filePepMan, fileMultiPlatform;
    
    public KCMObject targetDirectory=null;
    public DirectoryObject directoryObject=null;
	
	public KCMObject(DirectoryObject _do) {
	 	directoryObject =  _do;
	}  
    
    public KCMObject(File root, String name) throws KCMException {
		directoryPointer = new File(root, name);
		if (!directoryPointer.isDirectory()) {
			throw new KCMException("\nroot has to be a directory");
		}
		if (name.endsWith(".tmp")) {
			return ;
			//ignore
		}
		Matcher matcher=compile(PREFIX+"(\\d)\\.(\\d)\\.(\\d\\d)\\.(\\d\\d)", name);
		directoryObject  = new DirectoryObject(directoryPointer,PREFIX,matcher);
	    System.out.println("\ndone with allocating directory object");
	}
    
    //using only commandline
    public KCMObject(File _root, String _prefix, String _regex) throws KCMException {
    	
          Pattern pattern=Pattern.compile(_prefix +  _regex);    	
          String list []= _root.list(new FileFilterSh(FileFilterSh.FILE_T.DIRECTORY));
          DirectoryObject directoryPointer=null;
          int runningID=0;
         for (int i=0; i < list.length; i++) {
        	 directoryObject = new DirectoryObject(_root,  pattern, list[i]);
        	 if (directoryObject.version!=null && directoryObject.compare(runningID)) {
        		 directoryPointer=directoryObject ;
        		 runningID=directoryObject.getVersionInt();
        	 }
         }
         if (directoryPointer !=null) {
         System.out.println(_root+File.separator+_prefix+directoryPointer.getVersionString(1));
         }
    	
    }
	public KCMObject(File root,  KCMObject kObj) {
		fileKMP = new File(root, KMP);
		fileStarShip = new File(root, PROJECT_PREFIX+"-"+StarShip);
		filePepMan = new File(root, PROJECT_PREFIX+"-"+PepMan);
		fileMultiPlatform = new File(root, PROJECT_PREFIX+"-"+MultiPlatform);	
		targetDirectory = kObj;
		
	}
	

	
	
	public KCMObject () {
		directoryObject = new DirectoryObject();
	}
	
    public void performCopy() throws IOException {
    	System.out.println("\ndoing copy"+targetDirectory.directoryObject.getVersionString());
    	File targetKMP = new File(targetDirectory.directoryObject.docRelease, KMP);
    	File targetStarShip= new File(targetDirectory.directoryObject.docRelease, PROJECT_PREFIX+"-"+StarShip);    	
    	File targetPepMan= new File(targetDirectory.directoryObject.docRelease, PROJECT_PREFIX+"-"+PepMan);
    	File targetMultiPlatform= new File(targetDirectory.directoryObject.docRelease, PROJECT_PREFIX+"-"+MultiPlatform);    	
    	
    	Files.copy( 
    			Paths.get(fileStarShip.getCanonicalPath()),
    			Paths.get(targetStarShip.getCanonicalPath()), 
    			StandardCopyOption.REPLACE_EXISTING);
    	
    	Files.copy( 
    			Paths.get(filePepMan.getCanonicalPath()),
    			Paths.get(targetPepMan.getCanonicalPath()), 
    			StandardCopyOption.REPLACE_EXISTING);
    	
    	Files.copy( 
    			Paths.get(fileMultiPlatform.getCanonicalPath()),
    			Paths.get(targetMultiPlatform.getCanonicalPath()), 
    			StandardCopyOption.REPLACE_EXISTING);

    	
    	
    }
    public void performCopyWarBinaries() throws IOException {
    	File devRoot = new File(DEV_ROOT	);
    	File warSourceFile = new File(devRoot, KMP);
    	warSourceFile.isFile();
    	String warFileStr= warSourceFile.getCanonicalPath();
    	File targetKMPWarFile = new File(directoryObject.fileDirectoryTarget, KMP);
    	Files.copy(
    			Paths.get(warFileStr),
    			Paths.get(targetKMPWarFile.getCanonicalPath()),
    			StandardCopyOption.REPLACE_EXISTING);
    }
	private Matcher compile(String regex, String targetString) {		
		    Pattern pattern = Pattern.compile(regex);
		    Matcher matcher = pattern.matcher(targetString);		    
		    if (matcher.find()) {
		    	return matcher;
		        
		    }
		    return null;
		      
	}
	


}
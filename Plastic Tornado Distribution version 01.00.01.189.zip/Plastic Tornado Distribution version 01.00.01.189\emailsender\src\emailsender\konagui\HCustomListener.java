package emailsender.konagui;

import java.util.ArrayList;

import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import emailsender.html.PNotesHTMLOutput;

public abstract class HCustomListener implements HyperlinkListener {
	
    protected PNotesHTMLOutput htmlOutput=null;
    protected ArrayList<String> actionList=null;
	public HCustomListener (PNotesHTMLOutput _hOutput, String _action) {
		actionList = new ArrayList<String>();
	 htmlOutput= _hOutput;	
	 htmlOutput.setEditable(false);
	 actionList.add(_action);
	 htmlOutput.addHyperlinkListener(this);
	}
	

	
	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		for (int i=0; i < actionList.size();i++) {
			String action = actionList.get(i);			
				execute();
		
		}
		
		// TODO Auto-generated method stub
		
	}
	public void exec(String _action) {
		for (int i=0; i < actionList.size();i++) {
			String action = actionList.get(i);
			if (action.equals(_action)) {
				execute();
			}
		}
	}
	public abstract void printLink();
	public abstract void execute() ;


}
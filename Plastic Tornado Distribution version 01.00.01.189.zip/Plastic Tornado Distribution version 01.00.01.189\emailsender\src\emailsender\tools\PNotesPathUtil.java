package emailsender.tools;

import emailsender.FileFilterSh;
import emailsender.PNotesKCMObject;
import emailsender.ListFilesRecurse;
import emailsender.gui.*;
import emailsender.html.PNotesHTMLOutput;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.BufferedInputStream;

import java.io.BufferedReader;
import java.io.File;
//import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


import javax.swing.JTextArea;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

//import konaware.server.atom.KWServerHashMapEntry;

//import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/

public class PNotesPathUtil {
	  private final static String TOMCAT="D:\\utility\\apache-tomcat-11.0.3"; 
	  private PNotesHTMLOutput jEditor=null;
	  public Set<String> keySet=null;
	  public Set<PNotesKCMObject> entrySet=null;
	  
	  public NodeList nodesModulo=null,nodesSystemVerbose=null;
public PNotesPathUtil(File _targetRoot) throws PNotesKCMException {
	try {
	     DocumentBuilderFactory builderFactory =
	             DocumentBuilderFactory.newInstance();
	     DocumentBuilder builder = null;

	    builder = builderFactory.newDocumentBuilder();
		 Document doc = builder.parse(_targetRoot);
		 XPathFactory xpathfactory = XPathFactory.newInstance();
		 XPath xpath = xpathfactory.newXPath();
		 XPathExpression exprModulo = xpath.compile("/PlasticNotes/Group/@Modulo");
		 Object result = exprModulo.evaluate(doc, XPathConstants.NODESET);
		 nodesModulo = (NodeList) result;
		 XPathExpression exprSystem = xpath.compile("/PlasticNotes/System/@Verbose");
		 Object resultModulo = exprSystem.evaluate(doc, XPathConstants.NODESET);
		 nodesModulo = (NodeList) resultModulo;
		 Object resultSystem= exprSystem.evaluate(doc, XPathConstants.NODESET);
		 nodesSystemVerbose= (NodeList) resultSystem;


		 
	 
	} catch (ParserConfigurationException e) {
		// TODO Auto-generated catch block
		throw new PNotesKCMException ("Parser config error");
	} catch (IOException ioe) {
		throw new PNotesKCMException ("IO read error");
		
	} catch (SAXException sax) {
         throw new PNotesKCMException ("Sax error");
	} catch (XPathExpressionException e) {
		// TODO Auto-generated catch block
		throw new PNotesKCMException("sax error");
	}

	
}
private boolean parseTrue(String _arg) {
	if (_arg == null) return false;
	else if (_arg.equals("true") || _arg.equals("TRUE")) {
		return true;
	}
	try {
	return Integer.parseInt(_arg) > 0;
	} catch (NumberFormatException nfe) {
		return false;
	}
	
}

/*
public String getModuloText(KCMObject _kcmObject, int _runningCount) {
	Node nodeSelect=null;
	
	

    System.out.println("\nrunning total"+ _runningCount);
     if (nodes ==null) {
    	 return "null nodes";
     }
	StringBuffer sb = new StringBuffer();
	
	int indexGroup=0, indexModulo=0;
	if (_runningCount < 200) {
		return "1";
    } else if (_runningCount < 300) {    	
    	indexGroup = _runningCount -200;
    	indexModulo = _runningCount%2;
		nodeSelect = nodes.item(1);
		if (nodeSelect==null) {
			return "Group 2 has null node";
		} 
		return getModuloString(2, indexModulo,nodeSelect);
		
	} else if (_runningCount < 400) {
		indexGroup = _runningCount-300;
		indexModulo = _runningCount%3;
		
		nodeSelect = nodes.item(2);
		if (nodeSelect==null) {
			return "Group 3 has null node";
		}
		return getModuloString(3, indexModulo,nodeSelect);
		
	} 	else if (_runningCount < 500) {
		indexGroup = _runningCount-300;
		indexModulo = _runningCount%3;
		nodeSelect = nodes.item(3);
		if (nodeSelect==null) {
			return "Group 4 has null node";
		}
		return getModuloString(4, indexModulo,nodeSelect);
		
	} 
	return "XXXX";

}
*/
public boolean bIterateFilter=false;
private void processXml(Path _targetRoot, PNotesHTMLOutput _jEditor) {



 	try {
 	     DocumentBuilderFactory builderFactory =
 	             DocumentBuilderFactory.newInstance();
 	     DocumentBuilder builder = null;

 	    builder = builderFactory.newDocumentBuilder();
 	    
		 Document doc = builder.parse(_targetRoot.toFile());
		 XPathFactory xpathfactory = XPathFactory.newInstance();
		 XPath xpath = xpathfactory.newXPath();
		 XPathExpression exprModulo = xpath.compile("/EmailSender/Group/@Modulo");
		 Object resultModulo = exprModulo.evaluate(doc, XPathConstants.NODESET);
		 XPathExpression exprSystem = xpath.compile("/EmailSender/System/@Iterate.Filter");
		 Object resultSystem = exprSystem.evaluate(doc, XPathConstants.NODESET);
		 nodesModulo = (NodeList) resultModulo;
		 nodesSystemVerbose = (NodeList)resultSystem;
		 
		 if (nodesSystemVerbose !=null) {
			 nodesSystemVerbose= (NodeList) resultSystem;
			 Node nSystem = nodesSystemVerbose.item(0);
			 if (nSystem !=null && nSystem.getNodeValue()!=null) {
				 String nodeSystemValueString = nSystem.getNodeValue();				 
				 bIterateFilter= Boolean.parseBoolean(nodeSystemValueString);
				
				 
			 }
		 }
		 
		 
		 for (int i = 0; i < nodesModulo.getLength(); i++) {
		   System.out.println("\n>"+nodesModulo.item(i).getNodeValue()); 
		 }
	 
	} catch (ParserConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException ioe) {
		System.err.println("ioe error"+ioe.getMessage());
	} catch (SAXException sax) {

	} catch (XPathExpressionException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
 
 }
 PNotesKCMObject directoryKCM= new PNotesKCMObject();

 private FileFilterSh fileFilter=null;
 private ListFilesRecurse listFilesRecurse=null;
 private ArrayList<PNotesKCMObject> allFiles=null;
 public List<PNotesKCMObject> allFilesSync=null;
public PNotesPathUtil() {
	
}
public void processRecursive(Path _pathRoot, PNotesHTMLOutput jEd) throws PNotesKCMException {
	 PNotesKCMObject  kObject=null;	
	 allFiles = new ArrayList<PNotesKCMObject>();	
	 allFilesSync = (List<PNotesKCMObject>) Collections.synchronizedList(new ArrayList(allFiles));	 
	 
     int runningCount=0; 
	 try (DirectoryStream<Path> stream = Files.newDirectoryStream(_pathRoot)) 
     {
		 
         for (Path entry : stream) {        	 
             if (Files.isDirectory(entry)) {
            	 System.out.println("\ndirctory");
             } else {
            	 try {
            	  PNotesKCMObject kcmObject=null; 
            	  kcmObject = new PNotesKCMObject(entry, runningCount);         
            	  allFilesSync.add(kcmObject);
            	 } catch (PNotesKCMException kcm) {
            		 System.out.println(kcm.toString());
            		
            	 }
            	  
            	  
            	  
             }
         }
         
     } catch (IOException ioe) {
    	 throw new PNotesKCMException("Error in reading Path recursively");
     }
	
	 jEditor = jEd;
	 jEditor.attachHeader();
	 jEditor.attachP("Done adding all the Directory. Total count:"+allFilesSync.size()); 
	 jEditor.printPage();

 }
 
 private void processRecursive(File _targetRoot, PNotesHTMLOutput jEd) throws PNotesKCMException {
	 PNotesKCMObject  kObject=null;	
	 allFiles = new ArrayList<PNotesKCMObject>();	
	 allFilesSync = (List<PNotesKCMObject>) Collections.synchronizedList(new ArrayList(allFiles));	 
	 Path rootPath = Paths.get(_targetRoot.getAbsolutePath());
     int runningCount=0; 
	 try (DirectoryStream<Path> stream = Files.newDirectoryStream(rootPath)) 
     {
		 
         for (Path entry : stream) {        	 
             if (Files.isDirectory(entry)) {
            	 System.out.println("\ndirctory");
             } else {
            	 PNotesKCMObject kcmObject=null;
            	 try {
            	  kcmObject = new PNotesKCMObject(entry, runningCount);         
            	  allFilesSync.add(kcmObject);
            	 } catch (PNotesKCMException kcm) {
            		 System.out.println(kcm.toString());
            		
            	 }
            	  
            	  
            	  
             }
         }
         
     } catch (IOException ioe) {
    	 throw new PNotesKCMException("Error in reading Path recursively");
     }
	
	 jEditor = jEd;
	 jEditor.attachHeader();
	 jEditor.attachP("Done adding all the Directory. Total count:"+allFilesSync.size()); 
	 jEditor.printPage();

 }
 public PNotesPathUtil (Path _targetRoot, PNotesHTMLOutput jEd) throws PNotesKCMException {
	 if (_targetRoot.toFile().isDirectory()) {
		 processRecursive(_targetRoot, jEd);
		 KCMComp comparator =new KCMComp();
		 Collections.sort(allFilesSync, comparator);
	 } else {
		 processXml(_targetRoot, jEd);
	 }
 }
 StringBuffer pageBuffer =new StringBuffer(); 
 public boolean bCoreType() {
	 return fileFilter.bCoreType;
 }
 public void provisionHeader() throws PNotesKCMException {
	 pageBuffer.setLength(0);
	 pageBuffer.append("Starting to parse the tags");
	
 }
 private int tagCount=0;
 public boolean Iterate(PNotesPathUtil _pathGroup)  throws PNotesKCMException {
    if (allFilesSync == null) {
    	throw new PNotesKCMException("Parsed into memory failed");
    }
	PNotesKCMObject kcmO= allFilesSync.get(indexKCM);
	indexKCM++;
	runningTotal +=kcmO.totalCount;
	String clipboardText=null;
	 synchronized (allFilesSync) {
	jEditor.printPage(clipboardText);
	copyToClipboard(clipboardText);
	 }
	 return true;
	 


}
  
 public int getKCMIndex() {
	 return indexKCM;
 }
 private int indexKCM=0, runningTotal=0;
 public void Reset() {
	 indexKCM=0;
	 runningTotal=0;
 }
 
 
 
 public void copyToClipboard(String text) {
		StringSelection stringSelection = new StringSelection(text);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, null);

 }

 	 
     public void createWrite() throws ParserConfigurationException,
		            TransformerException {
    		    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		        DocumentBuilder builder = factory.newDocumentBuilder();
		        Document doc = builder.newDocument();

		        Element root = doc.createElementNS("zetcode.com", "users");
		        doc.appendChild(root);

		        root.appendChild(createUser(doc, "1", "Robert", "Brown", "programmer"));
		        root.appendChild(createUser(doc, "2", "Pamela", "Kyle", "writer"));
		        root.appendChild(createUser(doc, "3", "Peter", "Smith", "teacher"));

		        TransformerFactory transformerFactory = TransformerFactory.newInstance();
		        Transformer transf = transformerFactory.newTransformer();

		        transf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		        transf.setOutputProperty(OutputKeys.INDENT, "yes");
		        transf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
		        DOMSource source = new DOMSource(doc);
		        File myFile = new File("d:\\dev\\gnoo1\\users.xml");

		        StreamResult console = new StreamResult(System.out);
		        StreamResult file = new StreamResult(myFile);

		        transf.transform(source, console);
		        transf.transform(source, file);
}
     private static Node createUser(Document doc, String id, String firstName,
             String lastName, String occupation) {
         Element user = doc.createElement("user");
         user.setAttribute("id", id);
         user.appendChild(createUserElement(doc, "firstname", firstName));
         user.appendChild(createUserElement(doc, "lastname", lastName));
         user.appendChild(createUserElement(doc, "occupation", occupation));
         return user;
     }

     private static Node createUserElement(Document doc, String name,
             String value) {

         Element node = doc.createElement(name);
         node.appendChild(doc.createTextNode(value));

         return node;
     }
     public boolean checkTomcatDirectory(File _file) {
    	 File binFile =  new File(_file,"bin");
    	  File listFile [] =binFile.listFiles(new FileFilterSh());
    	 return listFile !=null && listFile.length > 5;
    			 
    	
     }
     
private class KCMComp implements Comparator <PNotesKCMObject>{
    KCMComp() {
     System.out.println("\nNew dcom");
    }

	@Override
	public int compare(PNotesKCMObject o1, PNotesKCMObject o2) {
	  
	  if (o1.directoryObject ==null) {
		  return 0;
	  } else if (o1.directoryObject.root==null) {
		  return 0;
	  }
	  
	  else {
		  System.out.println("\ncomparing:"+o1.directoryObject.root.getName());  
			return o1.directoryObject.root.getName().compareTo(
			o2.directoryObject.root.getName());
			
		}
	}
	
}
}

    
    


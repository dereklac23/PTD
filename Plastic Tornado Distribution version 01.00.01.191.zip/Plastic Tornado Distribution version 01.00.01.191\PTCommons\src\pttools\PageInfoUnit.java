package pttools;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;



public class PageInfoUnit implements GeneralUnit {
	
	
	
	public File root=null;
	public String header=null;
	public Path path=null;
	public String body=null;
	private final static String prefix ="/Book";
	public String uniqueID = null;
	public String nameTag=null;
	
	public PageInfoUnit(String _uniqueID, String _nameTag) {
		uniqueID = _uniqueID;
		nameTag = _nameTag;
	}
	public PageInfoUnit(String _nameTag) {
		nameTag= _nameTag;
	}
	public PageInfoUnit(File _root, String _header,Path _p) {	
		root=_root;
		header = _header;
		path = _p;		
	}
	
	public PageInfoUnit(Path _p) throws KCMException {
		path = _p;
	}
	public PageInfoUnit(File _root, String _header,String _body) {
		root=_root;
		header = _header;
		body = _body;		
		
	}
	
		
	
	public String getTag() {
		return nameTag;
	}

	
	
}

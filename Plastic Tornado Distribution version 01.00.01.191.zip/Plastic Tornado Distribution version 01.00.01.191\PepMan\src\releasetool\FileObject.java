package releasetool;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;

public class FileObject {
  String fileHeadString=null;
  File fileRoot=null;
  ArrayList<File> fileList = new ArrayList<File>();
  ArrayList<PageObject> pageList = new ArrayList<PageObject>();
  StringBuffer sb = new StringBuffer();
 public FileObject () {
	 
 }
 public void setFileHeadString(String _head) {
	 fileHeadString = _head;
 }
 public FileObject(File  _root) {
	 fileRoot = _root;
 }
 public FileObject(String _root) {
	 File _rootFile = new File(_root);
	 if (_rootFile ==null) {
		 System.out.println("\nroot file is null:"+_root);
	 }
	
	 fileRoot = _rootFile;
	 fileList.add(_rootFile);
}
 public void addFile(File _f) {
	 fileList.add(_f);
 }
 public void addPage(File _f) {
	 pageList.add(new PageObject(_f));
 }
 public void addBuffer(String _str) {
	 sb.append(_str);
 }
 public boolean bHasContent() {
	 return fileList.size() > 0 || pageList.size() > 0;
 }
 public void processGTMLContent() {
	 
	 pageList.forEach(p->processPage(p));
	 
 }
 
 private void processPage(PageObject p) {
	 try {
     	 p.process();
	 } catch (KCMException kcm) {
		 System.err.println("Error in processing page of bundled jar resource");
	 }
 }


 
}

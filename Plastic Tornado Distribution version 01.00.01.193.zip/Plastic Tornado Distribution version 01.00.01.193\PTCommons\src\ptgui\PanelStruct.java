package ptgui;

import java.awt.GridLayout;
import java.awt.event.KeyEvent;

import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel; 

/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/

public class PanelStruct {
 public JComponent comp=null;
 public JDialog compDialog=null;
 public String title = null;
 public String description =null;
 public int kEvent =-1;
   
 public PanelStruct(String _t, String _d, int _kE) {
	 title = _t;
	 description = _d;
	 kEvent  =_kE;
	 JPanel panel = new JPanel(false);
     JLabel filler = new JLabel(_t);
     filler.setHorizontalAlignment(JLabel.CENTER);
     panel.setLayout(new GridLayout(1, 1));
     panel.add(filler);
     comp=panel;
     //compDialog=null;
	 
 }
 
 public PanelStruct(String _t, String _d,  int _w, int _h,int _kE) {
	 title = _t;
	 description = _d;
	 kEvent  =_kE;
	 //MenuLayer4 panel = new MenuLayer4(_w, _h);
     //compDialog=panel;
 }
}

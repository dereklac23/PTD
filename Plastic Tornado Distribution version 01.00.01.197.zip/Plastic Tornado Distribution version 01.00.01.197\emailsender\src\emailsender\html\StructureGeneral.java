package emailsender.html;

import java.util.Stack;

import emailsender.tools.PNotesKCMException;

public abstract class StructureGeneral {
  public Stack<StructureGeneral> generalList= new Stack<StructureGeneral>();

  public String tokenList [] = new String[token.values().length];
  public abstract  void push(StructureGeneral _sg) throws PNotesKCMException ;
  public abstract StructureGeneral pull()  throws PNotesKCMException ;
  public abstract String snapShot() throws PNotesKCMException ;
  public enum token {HEAD, TAIL, SUBHEAD, SUBTAIL, PHEAD, PTAIL};
}
   
/**
 * 
 */
/**
 * 
 */
module MultiPlatform {
	requires java.desktop;
	requires emailsender;
	requires PTCommons;
	requires java.xml;
	requires jdk.xml.dom;
	
}
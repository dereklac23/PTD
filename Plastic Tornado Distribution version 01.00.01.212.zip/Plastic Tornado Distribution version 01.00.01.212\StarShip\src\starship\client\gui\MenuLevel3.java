package starship.client.gui;
import starship.atom.*;
import starship.util.*;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/ 

 


public class MenuLevel3 extends JPanel {
    
    private PanelTopGui panelTopGui=null;
    MenuLevel4 menuLayer4=null;
    RealmTools   realmTools=null;
    
    private int width=0, height=0;
    private LocalContainer globalContainer=null;
	public MenuLevel3(int _width, int _height, LocalContainer gCL0) {
		    width=_width;
		    height=_height;
		    menuLayer4 = new MenuLevel4(_width, height, gCL0);
		    
		    
		    realmTools = new RealmTools(25, 400);
		    add(BorderLayout.NORTH, new PanelTopGui());
            menuLayer4.setState(MenuLevel4.STATE.INACTIVE);
            realmTools.setState(RealmTools.STATE.INACTIVE);
            globalContainer=gCL0;
	}
	
	JPanel panelCredential=null, panelURL=null;
	
	 public void setStateClose() {
		 menuLayer4.setState(MenuLevel4.STATE.INACTIVE);
         realmTools.setState(RealmTools.STATE.INACTIVE);   
         menuLayer4.dispose();
         realmTools.dispose();
	 }
	// private GlobalContainer globalContainerL2=null;
	 
	 public class PanelTopGui extends JPanel {
			public PanelTopGui() {
				GridLayout gridLayout = new GridLayout(2,1);
		        GridBagConstraints c = new GridBagConstraints();
		        setFont(new Font("SansSerif", Font.PLAIN, 14));
		        setLayout(gridLayout);
		        
				panelCredential = new JPanel();
				panelURL= new JPanel();
				menuLayer4.panelCredential= panelCredential;
				menuLayer4.panelURL = panelURL;
				panelCredential.add(new JLabel("User name:"));
				panelCredential.add(menuLayer4.jtfUser=new JTextField (12));
				
				panelCredential.add(new JLabel("Password:"));
				panelCredential.add(menuLayer4.jtfPassword=new JTextField (12));
				panelCredential.add(menuLayer4.btnConnect= new JButton("Connect"));
				
				panelURL.add(menuLayer4.jtfURL = new JTextField(35));
		        panelURL.add(menuLayer4.btnSend = new JButton("Send"));
				panelURL.add(menuLayer4.btnTools = new JButton("Tools"));	
				


			    
				
				//kmw.add(
		        menuLayer4.btnConnect.addActionListener(new ActionListener() {
		            @Override
		            public void actionPerformed(ActionEvent e) {
		            	menuLayer4.setState(MenuLevel4.STATE.ACTIVE, globalContainer);
		            	
		            	
		            	
		            }
		        });
		        
		        menuLayer4.btnTools.addActionListener(new ActionListener() {
		            @Override
		            public void actionPerformed(ActionEvent e) {
		            	
		            	realmTools.setState(RealmTools.STATE.ACTIVE);
		            }
		        });
			
			
		          
			       add(menuLayer4.panelCredential);
			       add(menuLayer4.panelURL);
			       
				
				
			}
	 }
}
	


package emailsender;
import emailsender.konagui.*;
import emailsender.tools.PNotesKCMException;
import emailsender.tools.PNotesPathUtil;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;






/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/

public class FileFilterSh implements FilenameFilter {

	  
	  
	  
	  public ArrayList<PNotesKCMObject> kListDefault =  new ArrayList<PNotesKCMObject>();
	  public List<PNotesKCMObject> kListSync=  Collections.synchronizedList(new ArrayList(kListDefault));
			  

	  public ArrayList<PNotesKCMObject> hListDefault =  new ArrayList<PNotesKCMObject>();
	  public List<PNotesKCMObject> hListSync=  Collections.synchronizedList(new ArrayList(hListDefault));
	  private String headerString = null;
	  public FileFilterSh() {
		  
	  }
  
  //public KCMObject fileObject=null;

  public PNotesKCMObject getKCMObject(File dir, String name) throws PNotesKCMException  {
	  PNotesKCMObject fileObject = new PNotesKCMObject(dir, name);
      if (fileObject.directoryPointer!=null) {
   	   System.out.println("\nGot a file Directory object as:"+fileObject.directoryPointer.getName());
   	   return fileObject;
      }
      return null;
 
	  
  }


  public int getKCMSize() {
	 return  kListSync.size();
  }
  public int getKCMIndex() {
	  return listIter.nextIndex();
  }
  private ListIterator <PNotesKCMObject> listIter=null;
  public void Reset() {
	  listIter=null;
	  
		  listIter= kListSync.listIterator();
		  groupCount=1;
	  
	  	  
  }
  public boolean bCoreType=false;
  public int groupCount=1, tagCount=0;
  public String Iterate(PNotesPathUtil _pathGroup) throws PNotesKCMException  {
	  PNotesKCMObject kObject =null;
	  StringBuffer sb = new StringBuffer();
	  groupCount++;
	  if (listIter==null) {
		  throw new PNotesKCMException ("Iterator is null");
	  }
	  if (!listIter.hasNext()) {
		  return null;
	  }
	  try {
	  kObject = listIter.next();

	  
	  bCoreType = kObject.bCoreType();
	  
	  } catch (NoSuchElementException noe) {
		  throw new PNotesKCMException ("\nEnd of list");
		  
	  }
	  tagCount += kObject.tagCount;
	  //sb.append(_pathGroup.getModuloText(kObject.tagCount));
	  //sb.append( kObject.getTagList(tagCount));
	  sb.append(bCoreType);
	  
	  return sb.toString();
	  
  }
  
  private String header=null;
  public String getHeader() {
	  return "Group count:"+groupCount+" "+header;
  }
  @Override
	public boolean accept(File dir, String name) {
	  System.out.println("\n accepting"+ name);
	   try {
		 if (dir != null) {
           PNotesKCMObject fileObject = new PNotesKCMObject(dir, name);
           if (fileObject.bDirectory) {
        	   return true;
           } else if (fileObject.directoryObject.getPrefix().equals("HEADER")) {
        	   
        	   header = fileObject.getHeader();
        	   
           } else {
           kListSync.add(fileObject);
           }
           return fileObject.directoryObject.isTagFile();   		       
		      
		      }
	   } catch (PNotesKCMException kcm) {
		   System.err.println("\nkcm errror"+kcm.description);
	   }
		 
	  
		 return false;
 
 }
  
  
	
	public String getName(String name) {
		  int i = name.lastIndexOf('.');
	      if (i > 0 && i < name.length() - 1) {
	        return name.substring(0,i);
	      }
	    
	    return null;
	}
	public String getExtension(String name) {
	      int i = name.lastIndexOf('.');
	      if (i > 0 && i < name.length() - 1) {
	        return name.substring(i + 1).toLowerCase();
	      }
	    
	    return null;
	  }

	
}


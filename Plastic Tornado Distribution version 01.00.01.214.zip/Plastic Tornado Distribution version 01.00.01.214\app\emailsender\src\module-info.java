/**
 * 
 */
/**
 * 
 */
module emailsender {
	requires java.desktop;
	requires java.xml;
	requires java.datatransfer;
	//requires konagui;
	exports emailsender;
	exports emailsender.gui;
	exports emailsender.html;
	exports emailsender.konagui;
	exports emailsender.tools;
	
}
/**
 * 
 */
/**
 * 
 */
module PTCommons {
	requires java.desktop;
	//requires emailsender;
	
	//requires PTCommons;
	exports ptgui;
	exports pttools;
	exports ptsets;
	exports ptdatamodel;
}
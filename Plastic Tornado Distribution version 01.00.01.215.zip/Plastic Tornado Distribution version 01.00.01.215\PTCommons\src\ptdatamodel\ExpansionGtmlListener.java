package ptdatamodel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import ptgui.ExpansionFrameSettings;
import ptgui.ExpansionFrameGtml;
import ptgui.ExpansionFrameGtml.SP_TYPE;

public class ExpansionGtmlListener implements ActionListener {
   public SP_TYPE type = ExpansionFrameGtml.SP_TYPE.REFRESH;
   public int ordinal=0;
   public ExpansionFrameGtml gtmlFrame=null;
	public ExpansionGtmlListener(ExpansionFrameGtml _gtmlFrame,int _ordinal) {
		ordinal = _ordinal;
		gtmlFrame = _gtmlFrame;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		switch (ordinal) {
		case 0: break; //ExpansionFrameGtml.SP_TYPE.REFRESH: break;
		case 1: break; //ExpansionFrameGtml.SP_TYPE.ANNOTATE: break;
		case 2: break; //ExpansionFrameGtml.SP_TYPE.FLATLINE: break;
			
		}
	}
}

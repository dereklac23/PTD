package starship.atom;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

//import konaware.util.KWMessageWrapper;


public class KWHashMapEntry {
    private StringAtom key=null;
    private AtomCore data=null;
    
	public KWHashMapEntry(String _key, AtomCore _data) {
		try {
			key = (StringAtom) AtomCore.getAtom("string");
			key.setString(_key);
		} catch (AtomException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		data=_data;
		
	    	
	} 
	public KWHashMapEntry (StringAtom atomKey, AtomCore atomCore) {
		key = atomKey;
		data=atomCore;
	}
	
	
	public StringAtom getKeyAtom() {
		return key;
	}
	public AtomCore getDataAtom() {
		return data;
	}
	public String getKey() {
		return key.getString();
	}
	
	 
	public KWHashMapEntry(String _key, int _data)  {		
		 try {
			key = (StringAtom) AtomCore.getAtom("string");
			key.setString(_key);
			IntegerAtom dataInteger = (IntegerAtom)AtomCore.getAtom("int");
			dataInteger.setInteger(_data);
			data= dataInteger;
		 } catch (AtomException at) {
			 System.err.println("\nError in creating hash mash entry for realm board");
		 }
	
		
	}
	public KWHashMapEntry (String _key) {
		try {
		key = (StringAtom) AtomCore.getAtom("string");
		key.setString("string");
		
		data= AtomCore.getAtom("integer");		
	    IntegerAtom aI = (IntegerAtom)data;
	    aI.setInteger(0);
		} catch (AtomException ae) {
			
		}
	}
	
	
	public void Print(PrintWriter printWriter) {
	   	key.print(printWriter);
	   	if (data instanceof IntegerAtom) {
	   		IntegerAtom atomI = (IntegerAtom)data;
	   		atomI.print(printWriter);
	   		
	   	} else if (data instanceof StringAtom) {
	   		StringAtom atomS = (StringAtom) data;
	   		atomS.print(printWriter);
	   	}
	   	
	}
	public boolean Read(BufferedReader bufferedReader) throws AtomException {
		
	
		  String token = null;
		  try {
		  while ((token = bufferedReader.readLine())!=null) {
			  AtomCore atom= AtomCore.getAtom(token);
			  
			  
			  String dataToken = bufferedReader.readLine();
			  if (dataToken ==null) {
				  return false;
			  } else  if (! (atom instanceof StringAtom)) {
				  throw new AtomException("Procol error: Needs to be String Atom for key");
			  }
			  StringAtom atomKey = (StringAtom)atom;			  
			  atomKey.setString(dataToken);
			  
			  
			  token= bufferedReader.readLine();
			  if (token==null) {
				  return false;
			  } else if (! (atom instanceof IntegerAtom)) {
				  throw new AtomException("Error in in rececinb data part of the exchange protocol for KWHashMapEntry");
			  }
			  AtomCore atomData = AtomCore.getAtom(token);
			  key = atomKey;
			  data = atomData;
			 
			  
		  }
		  
		  } catch (IOException ioe) {
			  System.err.println("IOE in reading into KWHashMapEntry");
		  } catch (AtomException aoe) {
			  System.err.println("Protocol mismatch in KWHashMapEntry");
		  }
		  return true;
	}
	public String getString() {
		StringBuffer sb = new StringBuffer ();
		sb.append(key.getString());
		
	    return sb.toString();	
	}
}

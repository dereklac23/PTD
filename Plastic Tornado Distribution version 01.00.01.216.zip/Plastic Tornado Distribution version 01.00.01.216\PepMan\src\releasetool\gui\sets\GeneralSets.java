package releasetool.gui.sets;

import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class GeneralSets {
	public enum ACTION_TYPE  {CLICKED, INITIAL};
    public ACTION_TYPE actionType = ACTION_TYPE.INITIAL;


}

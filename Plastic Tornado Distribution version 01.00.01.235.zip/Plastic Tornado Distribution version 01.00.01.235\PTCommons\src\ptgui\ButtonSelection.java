package ptgui;

public class ButtonSelection {
    public String label=null, description=null;
    public enum BSTypeDistribution  {PROVISION, COPY_KCM, COPY_TOMCAT,LOAD_GTML, NULL};
    
    public BSTypeDistribution typeDistribution=BSTypeDistribution.NULL;
    
    public enum BSTypeSettings {TREE_VIEW, GTML, CONFIGURE, WORKING, CLASSPATH, SANDBOX, BUNDLED_JAR};
    public BSTypeSettings typeSettings= BSTypeSettings.TREE_VIEW;
    
    
    
    public ButtonSelection(BSTypeSettings _bType,String _text) {
  	  label = _text;
  	  typeSettings= _bType;
  	}
    
    public ButtonSelection(BSTypeDistribution _bType,String _text) {
  	  label = _text;
  	  typeDistribution = _bType;
  	  
  	}
    
    public ButtonSelection(BSTypeDistribution _bType,BSTypeSettings _typeSettings,String _text) {
    	typeDistribution = _bType;
    	typeSettings = _typeSettings;
    	label = _text;
    }
    
    public ButtonSelection(String _label, String _description) {
    	label = _label;
    	description  = _description;
    }
    public String getLabel() {
    	    	return label;
    }
	
}

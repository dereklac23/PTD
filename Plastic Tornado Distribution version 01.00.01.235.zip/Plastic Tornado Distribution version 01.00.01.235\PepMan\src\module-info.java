/**
 * 
 */
/**
 * 
 */
module PepMan {
	requires java.desktop;
	requires java.xml;

	exports releasetool.gui;
}
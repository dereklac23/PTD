package mpdatamodel;

import java.util.ArrayList;

import emailsender.PNotesKCMObject;
import emailsender.gui.EmailBatch;
import emailsender.gui.Entry;
import emailsender.html.PNotesHTMLOutput;
import emailsender.konagui.GroupModel;

public class MPBatch {
    int index=0;
    public MPBatch batch=null;
    public int batchNumber=0;
    public MPEmailBatch emailBatchPointer=null;
    public StringBuffer body=null;
    public PNotesKCMObject kcm=null;
	public static ArrayList<MPBatch> batchList= new ArrayList<MPBatch>();
    
	public MPBatch(MPEmailBatch _eb, int _index) {
		index = _index;		
		emailBatchPointer = _eb;
		
		body = new StringBuffer();
	}
	


	public String getName() {
		return emailBatchPointer.startIndex +":" + emailBatchPointer.endIndex;
	}
	public EmailEntry entry=null;
	private GroupModel groupModel= new GroupModel();
	
	public String getBatchHeader(GroupModel.GROUP_TYPE _type) {
		StringBuffer sb = new StringBuffer();
		if (_type == GroupModel.GROUP_TYPE.HTML   ) {
			sb.append("<tr bgcolor='#94BD84'>");
			sb.append("<td>Batch number:" + batchNumber+"</td>");

			
			sb.append("<td>"+ groupModel.getMaskKey(batchNumber)+"</td>");
			sb.append("<td>Group id:"+groupModel.getGroup(batchNumber)+"</td>");
			sb.append("</tr>");
			
		} else if (_type == GroupModel.GROUP_TYPE.TEXT) {
			sb.append("Mask key" + groupModel.getMaskKey(batchNumber));
			sb.append("Group id"+ groupModel.getGroup(batchNumber));
		}
		return sb.toString();
	}
	public static String getBatchInfo(MPGroupModel.GROUP_TYPE _type) {
		StringBuffer sb = new StringBuffer(1028);
		if (_type == MPGroupModel.GROUP_TYPE.HTML) {
			sb.append("<tr><td>Total batch :" + batchList.size() +"</td></tr>");			
			for (int i=0; i < batchList.size(); i++) {
			  MPBatch b1 = batchList.get(i);			 
			//	EmailBatch eb= GroupModel.getEmailBatch(b1.batchNumber);
			  /*
			 if (eb !=null ) { 				
			  sb.append(b1.getBatchHeader(GroupModel.GROUP_TYPE.HTML));
			  sb.append("<tr><td>" + b1.getTagString(GroupModel.GROUP_TYPE.HTML, b1.kcm)+ "</td></tr>");
			 }
			 */
			  
			} //for

			
		} else if (_type == MPGroupModel.GROUP_TYPE.TEXT) {
			for (int i=0; i < batchList.size(); i++) {
				  MPBatch b1 = batchList.get(i);			 
				//	EmailBatch eb= GroupModel.getEmailBatch(b1.batchNumber);
				  /*
				 if (eb !=null ) { 				
				  sb.append(b1.getBatchHeader(GroupModel.GROUP_TYPE.TEXT));
				  sb.append(b1.getTagString(GroupModel.GROUP_TYPE.TEXT, b1.kcm));
				 }
				 */
				  
				} //for
		}
		return sb.toString();
	}
	public String extract(PNotesHTMLOutput.TAG _tag) {
		StringBuffer sb = new StringBuffer();
		sb.append("<tr bgcolor='#b57841'><td>");
		sb.append(body);
		sb.append("</td></tr>");
		return sb.toString();
		
	}
	public static String getTagString(GroupModel.GROUP_TYPE _type , PNotesKCMObject _kcmO) {
		StringBuffer sb = new StringBuffer();
		if (_type == GroupModel.GROUP_TYPE.HTML) {
			
		 for (int i=0; i < _kcmO.entryList.size(); i++) {
			 Entry e1 = _kcmO.entryList.get(i);
			 sb.append("<tr><td>"+ e1.line+"</td></tr>");
		}
				
	
		} else if (_type == GroupModel.GROUP_TYPE.TEXT) {
			 for (int i=0; i < _kcmO.entryList.size(); i++) {
				 Entry e1 = _kcmO.entryList.get(i);
				 sb.append(e1.line);
			}
			
			
		}
		return sb.toString();
	}
	
}


package mpdatamodel;

public class MPKCMException extends Exception {
    public String description=null;
	public MPKCMException(String des) {
		description = des;
	}
	public String getString() {
		return description;
	}
	
}

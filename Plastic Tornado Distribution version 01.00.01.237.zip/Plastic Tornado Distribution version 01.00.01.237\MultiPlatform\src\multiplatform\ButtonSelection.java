package multiplatform;

public class ButtonSelection {

	public ButtonSelection() {
		
	}
}

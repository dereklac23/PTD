package emailsender.tools;

public class PNotesKCMException extends Exception {
    public String description=null;
	public PNotesKCMException(String des) {
		description = des;
	}
	public String toString() {
		return description;
	}
	
}

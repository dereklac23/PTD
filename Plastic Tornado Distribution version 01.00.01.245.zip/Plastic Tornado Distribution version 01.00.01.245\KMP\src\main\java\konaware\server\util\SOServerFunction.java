package konaware.server.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ProtocolException;
import java.util.LinkedList;

import jakarta.servlet.ServletContext;

//import konaware.atom.KWHashMapEntry;
//import konaware.atom.KWHashMapEntry;
import konaware.server.KMPGateway;
import konaware.server.RealmSpace;
//import konaware.util.DimensionStateOperation;
//import konaware.util.KWAtom;
//import konaware.util.RealmRenderFunction;
//import konaware.util.StateOperationException;
import konaware.server.atom.KWServerHashMapEntry;

public class SOServerFunction  {

	public enum HASHMAP_WEB { PROVISION,  PRINT_TABLE,ADD, EDIT, REMOVE, CHECK, SEND};
    public  enum HTML_PARTS { HEAD, BODY, TAIL};
    
    public enum MESSAGE_COMMAND {PROVISION, SEND, PUT, COM_GET, COM_POST};
    
    public enum MESSAGE_COMMAND_EXT {IN_LIST};
    
	public KWServerMessageWrapper kwMessageWrapper=null;
	
    
	public LocalServerContainer localContainer=null;
	public ServletContext servletContext=null;
	
	public SOServerFunction() {
		this(null);
		localContainer = new LocalServerContainer();
		kwMessageWrapper = new KWServerMessageWrapper();
		
	}
	public  SOServerFunction(LocalServerContainer _lc) {
		localContainer = _lc;
		

		
	}
	
	public void execute(MESSAGE_COMMAND mCommand, LocalServerContainer _lSC) {
		if (mCommand== MESSAGE_COMMAND.PROVISION) {
			localContainer = _lSC;
			
			kwMessageWrapper.Put(_lSC.dso);
			
		} 
		
	}
	public void execute(MESSAGE_COMMAND mCommand , DimensionServerStateOperation _dso) {
		if (mCommand== MESSAGE_COMMAND.PUT) {
		 kwMessageWrapper.Put(_dso);	
			
			
		} 
	} 
	
	public void execute(MESSAGE_COMMAND mCommand, ServletContext _context) {
		if (mCommand == MESSAGE_COMMAND.PROVISION) {
			servletContext = _context;
			if (kwMessageWrapper !=null) {
				kwMessageWrapper.context= _context;
			}
		}
		
		
	}
	
	public void execute(MESSAGE_COMMAND mCommand, BufferedReader br, PrintWriter pw) {
		if (mCommand == MESSAGE_COMMAND.PROVISION) {
		kwMessageWrapper.Provision(br, pw);
		}
	}
	public void execute(MESSAGE_COMMAND mCommand , MESSAGE_COMMAND_EXT mCommandExt) {
		if (mCommand == MESSAGE_COMMAND.COM_GET && mCommandExt == MESSAGE_COMMAND_EXT.IN_LIST) {
			System.out.println("\nsending");
			kwMessageWrapper.Send();
		}
	}
	public void execute(MESSAGE_COMMAND mCommand) {
        if (mCommand == MESSAGE_COMMAND.COM_GET) {
        	   log("\ncom get");
        	   if (kwMessageWrapper!=null) {
        		   kwMessageWrapper.Send();
        	   }
        	
		 	
		} else if (mCommand == MESSAGE_COMMAND.PROVISION) {
			KWServerHashMapEntry mapEntryX = new KWServerHashMapEntry(
			  RealmSpace.BOARD_PROVISION_X_STRING, 
			  RealmSpace.BOARD_WIDTH);
		 	
			kwMessageWrapper.Put(RealmSpace.BOARD_PROVISION_X_STRING,mapEntryX);
			
			KWServerHashMapEntry mapEntryY = new KWServerHashMapEntry(
					  RealmSpace.BOARD_PROVISION_Y_STRING, 
					  RealmSpace.BOARD_HEIGHT);
				 	
					kwMessageWrapper.Put(RealmSpace.BOARD_PROVISION_Y_STRING,mapEntryY);
			//dso = new DimensionServerStateOperation (mapEntryX, mapEntryY); 
		}
	}
	public DimensionServerStateOperation getDSO() {
		KWServerHashMapEntry entryWidth   = kwMessageWrapper.Get(RealmSpace.BOARD_PROVISION_X_STRING);
		KWServerHashMapEntry entryHeight  = kwMessageWrapper.Get(RealmSpace.BOARD_PROVISION_Y_STRING);
		return new DimensionServerStateOperation(entryWidth, entryHeight);
	}
	public DimensionServerStateOperation getDSO(String _keyWidth, int _width, String _keyHeight, int _height) {
		KWServerHashMapEntry entryWidth  = new KWServerHashMapEntry(_keyWidth, _width);
		KWServerHashMapEntry entryHeight = new KWServerHashMapEntry(_keyHeight, _height);
		DimensionServerStateOperation dso = new DimensionServerStateOperation (entryWidth, entryHeight);
		return dso;
	}
/* utiliity for State operations */	
	private void log(String _message) {
		if (servletContext !=null) {
			servletContext.log(_message);
		}
	}
    
}


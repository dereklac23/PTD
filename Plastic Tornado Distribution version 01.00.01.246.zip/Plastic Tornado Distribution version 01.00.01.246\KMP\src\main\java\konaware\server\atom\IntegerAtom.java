package konaware.server.atom;

import java.io.PrintWriter;

public class IntegerAtom extends AtomCore {

	final static String token="int";
    protected int payload=0;

    public IntegerAtom() {
    	
    }
    public IntegerAtom(int _payload)  {
    	payload = _payload;
    	
    }
    public void print(PrintWriter printWriter ) {
    	printWriter.println(token);
    	printWriter.println(Integer.valueOf(payload));
    }
    public int getInteger() {
    	return payload;
    }
    public void setInteger(int _value) {
    	payload=_value;
    	
    }
    public String getString() {
    	return Integer.valueOf(payload).toString(); 
    }

}

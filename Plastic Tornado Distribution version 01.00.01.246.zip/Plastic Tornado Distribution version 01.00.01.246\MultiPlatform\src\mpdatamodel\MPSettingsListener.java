package mpdatamodel;


import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import multiplatform.MPPropertiesPage;
import ptgui.ExpansionFrameGtml;


public class MPSettingsListener implements ListSelectionListener {
	  private MPPropertiesPage propertiesPage=null;
	  private ExpansionFrameGtml expansionFrame=null;
	  private JTable jTable=null;
        public MPSettingsListener(MPPropertiesPage pp, ExpansionFrameGtml _expansion ) {
        	jTable = pp.jTable;
        	propertiesPage = pp;
        	ListSelectionModel cellSelectionModel = jTable.getSelectionModel();
            cellSelectionModel.addListSelectionListener(this);
            jTable.setCellSelectionEnabled(true);
    	    cellSelectionModel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        	
        }
     
	@Override
	public void valueChanged(ListSelectionEvent e) {		  
		  String selectedData = null;
          SettingsModel sm = (SettingsModel)propertiesPage.abstractModel;
          
          if (sm.setBTick()) {
        	  for (int i=0; i < jTable.getRowCount(); i++) {
        		  if (jTable.isRowSelected(i)) {
        			  sm.latchRow(i);
        			  if (jTable.isColumnSelected(1)) {
        				  
        				  sm.latchPath();
        			  }
        		  }
  		    	
  		    }
          	
          	
          }
		   

		
	}

    
}

	

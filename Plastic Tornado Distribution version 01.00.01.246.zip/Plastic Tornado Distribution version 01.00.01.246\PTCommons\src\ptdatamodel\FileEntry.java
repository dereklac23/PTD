package ptdatamodel;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import pttools.KCMException;
import pttools.BookInfoUnit;
import pttools.ChapterInfoUnit;
import pttools.PageInfoUnit;

public class FileEntry {
    private Path path=null;
    private String fileName=null;	
    private final static String ALPHANUMERIC_Group = "([a-zA-Z0-9]+)";
    private final static String INTERNAL="INTERNAL", EXTERNAL="EXTERNAL";
    private final static String NUMERIC_Group = "([0-9]+)";
    
    public final  static String BOOK_INTERNAL=
    		"(BOOK|Book)\\."+
           ALPHANUMERIC_Group+"\\."+
            INTERNAL+            
        "\\.xml";
    public final  static String BOOK_EXTERNAL=
    		"(BOOK|Book)\\."+
           ALPHANUMERIC_Group+"\\."+
            EXTERNAL+            
        "\\.xml";
       
   
    public final  static String CHAPTER=
            "(CHAPTER|Chapter)\\."+
            ALPHANUMERIC_Group+"\\."+
            NUMERIC_Group+
        "\\.xml";


    public final  static String PAGE=
    		"(PAGE|Page)\\."+
            ALPHANUMERIC_Group+"\\."+
            NUMERIC_Group+
            "\\.html";
   

    
     

    public String type = null;
    public HashMap<String,BookInfoUnit> attributeBookMap=null;
    public List<ChapterInfoUnit>attributeChapterList=null;
    public PageInfoUnit piu = null;
    public void setBookAttributes(HashMap<String,BookInfoUnit> _attMap) {
    	synchronized (this) {
    	attributeBookMap=_attMap;
    	}
    }
    public void setChapterAttributes(List<ChapterInfoUnit> _attList) {
    	synchronized (this) {
    	attributeChapterList=_attList;
    	}
    }
    public void printMap() {
    	
    	for (String k :attributeBookMap.keySet()) {
    		BookInfoUnit biu = attributeBookMap.get(k);
    		
    	}
    }
    public String getColumnValue(String _key) {
    	if (_key==null) {
    		return " ";
    	}     else if (attributeBookMap ==null) {
    		return " ";
    	}
    	BookInfoUnit biu= attributeBookMap.get(_key);
    	if (biu !=null && biu.value !=null) {

    		return biu.value;
    	}
    	return " ";
    }
    public String tagString[] =null;

    protected Matcher matcher=null;
    public boolean bMatched=false;
    
 
   
    public String getTagSplit(int _index) {
    	if (_index >= tagStringSplitList.length) {
    		return "";
    	}
    	else if (tagStringSplitList[_index] !=null) {
    		return tagStringSplitList[_index];
    	} else return "";
    }
    private String extractSplit(String _target) {    	
    	String returnSplit[] =_target.split("\\.");
    	if (returnSplit.length >= 1) {    	
    		return returnSplit[0];
    	}
    	return _target;
    }
    private String [] extractSplitList(String _target) {
    	
          return _target.split("\\.");

    }
   
    public String getName() {
       if (tagString[1]!=null) {
    		return tagString[1];
    	} else if (tagString[0]!=null) {
    		//return extractSplit(tagString[0]);
    		return tagStringSplitList[0];
    	}
    	return "Content:";
    }
    public StringBuffer body = new StringBuffer(5024);
    public int  ordinalPointer=0;
    public int groupCount=0;
    public String tagStringSplitList[]=null;
    protected int parseInternal(String _keyEntry, Path _p) throws KCMException {
    	String integerString=null;
    	int returnValue=0;
    	try {
    	
    	  DocumentBuilderFactory builderFactory =
		             DocumentBuilderFactory.newInstance();
		     DocumentBuilder builder = null;
           
				 builder = builderFactory.newDocumentBuilder();
				 Document doc = builder.parse(new File(_p.toString()));
				 XPathFactory xpathfactory = XPathFactory.newInstance();
				 XPath xpath = xpathfactory.newXPath();				 
				 String exprString ="/Book/"+_keyEntry+"/text()";				 

					XPathExpression expr = xpath.compile(exprString);
				 String nodes = (String)expr.evaluate(doc, XPathConstants.STRING);
				 
				 System.out.println("\nResult:"+nodes);
				 return Integer.parseInt(nodes);
        } catch (ParserConfigurationException pce) {
        	 throw new KCMException ("\nCannot extract max iteration");
           } catch (IOException ioe) {
        	   throw new KCMException("\nCannot read xml to extrax max iteration value");
           } catch (SAXException sax) {
        	   throw new KCMException ("\nSAX error in extracting max iteration value");
           } catch (XPathExpressionException pe) {
        	   throw new KCMException("\nX Path expression error to extract max iteration value");
           }
    	//return returnValue;
    	
    }
    protected boolean compile(String _regex, String _fileName) throws KCMException {
    	Pattern  pattern = Pattern.compile(_regex); 
		 matcher = pattern.matcher(fileName);
		 groupCount = matcher.groupCount();
		if (matcher.groupCount() == 0) {
			
           throw new KCMException("Error: internal compile regex does not match for:"+_fileName);
			
		}
		ordinalPointer=0;
		matcher.reset();
		
		//extractGroup()
	    tagString = new String[matcher.groupCount()];
		while (matcher.find()) {
			tagString[ordinalPointer] = matcher.group(ordinalPointer);
			bMatched=true;
			ordinalPointer++;		
        } 

		if (tagString[0] !=null) {
		tagStringSplitList = extractSplitList(tagString[0]);
		}
				
		return ordinalPointer > 0;
    }
    
   
    private String extractGroup(int _index, Matcher _targetMatcher) {
    	return  _targetMatcher.group(_index);
    	
    }
    public int maxIteration =0;
	public FileEntry(Path _p) throws KCMException {
		
		//typeString = _type;
		Pattern  pattern=null;
		path=_p;
		fileName=path.getFileName().toString();
		if (compile(BOOK_INTERNAL, fileName) && fileName.endsWith(INTERNAL+".xml")) {
			type = BOOK_INTERNAL;
			try {
			maxIteration = parseInternal("Max-Iteration",_p);
			
			
			} catch (KCMException kcm) {
				System.out.println("\nError: parse error for Max-Iteration"); 
			}

		} else if (compile(BOOK_EXTERNAL, fileName) && fileName.endsWith(EXTERNAL+".xml")) {
			System.out.println("\ngot external");
			type = BOOK_EXTERNAL;

			
		}		else if (compile (CHAPTER, fileName)) {
			type = CHAPTER;
		} else if (compile(PAGE, fileName)) {
			type = PAGE;
			try {
			BufferedReader br = new BufferedReader(new FileReader(_p.toString()));
			String line=null;
			while ((line =br.readLine())!=null) {
				body.append(line);
			}
			br.close();
			
			} catch (FileNotFoundException fne) {
				throw new KCMException ("Error: file not found");
			} catch (IOException ioe) {
				throw new KCMException ("Error: Cannot read into buffer");
			}
			
		}
		
	}
	private final static String returnGeneralError = "<p>Error: The file naming convention for Book has to be (BOOK|Book).UNIQUE-ID.([0-9])+"
			+ "\\.xml. </p>"+		
  "<p>For example: 'BOOK.OralHistory.0001.xml.'</p>" +
  "<p>The file naming convention for Chapter has to be (CHAPTER|Chapter).UNIQUE-ID.([0-9])+"
	+ "\\.xml. </p>"+
"<p>For example: 'CHAPTER.OralHistory.0001.xml.The unique identify UNIQUE-ID has to match of ones of CHAPTER.</p>"+
"<p>The file naming convention for Page has to be (PAGE|Page).UNIQUE-ID.([0-9])+"
+ ".xml. </p>"+
"<p>For example: 'PAGE.OralHistory.0001.xml'. The unique identify UNIQUE-ID has to match of ones of BOOK.</p>";
	
	

	public String getPageEntry() {
		if (piu !=null && piu.body !=null) {
		return piu.body.toString();
		} else {
			return null;
		}
	}
	public String getBookEntry(String _key) {	
		
		System.out.println("\nGetting book entry with index at:"+_key);
		if (attributeBookMap !=null ) {
			synchronized (this) {
		   BookInfoUnit biu1 = attributeBookMap.get(_key);
		   if (biu1 !=null) {
			return attributeBookMap.get(_key).value;
		   }
			}
		} 
			return null;
		
		
	}
	public String getHeadTag(int _hIndex) {
		switch (_hIndex) {
		case 1: return "<h1>";
		case 2: return "<h2>";
		case 3: return "<h3>";
		case 4: return "<h4>";
		case 5: return "<h5>";
		case 6: return "<h6>";
			
		}
		return "<h1>";
	}
	public String getTailTag(int _hIndex) {
		switch (_hIndex) {
		case 1: return "</h1>";
		case 2: return "</h2>";
		case 3: return "</h3>";
		case 4: return "</h4>";
		case 5: return "</h5>";
		case 6: return "</h6>";
			
		}
		return "</h1>";
	}
	public String getChapterEntry(int _index) {

		if (attributeChapterList ==null) {
		return null;				
		}
		if (attributeChapterList.size () > 1 && _index ==0) {
			return attributeChapterList.get(0).chapterString;
		}
        synchronized (this) {
        	for (int i=0; i < attributeChapterList.size();i++) {
        		
	    	   ChapterInfoUnit ciu1 = attributeChapterList.get(i);
	    	   if (ciu1.headerString !=null) {	    		   
	    		   return getHeadTag(i+1)+ciu1.headerString+ getTailTag(i+1);
	    	   }
			
			} //for
		} //sync 
        return null;
		
	}
	public String getString() {
		if (bMatched) return body.toString();
		else if (type !=null &&type.equals(BOOK_EXTERNAL) && (fileName.contains("Book") || fileName.contains("BOOK"))) {
			return "Error for:<" + fileName
					+ ">. The file naming convention for Book has to be (BOOK|Book)_UNIQUE-ID_([EXTERNAL|INTERNAL])+"
					+ "_\\.xml. "+
		  "For example: 'BOOK_OralHistory_EXTERNAL.xml.'";
				
		}else if (type != null && type.equals(CHAPTER) && (fileName.contains("Chapter") || fileName.contains("CHAPTER"))) {
			return "Error for: <" + fileName +">.The file naming convention for Chapter has to be (CHAPTER|Chapter)_UNIQUE-ID_([0-9])+"
					+ "_\\.html. "+
		  "For example: 'CHAPTER_OralHistory_0001.xml.'. The unique identify UNIQUE-ID has to match of ones of CHAPTER.";
		}else if (type!=null && type.equals(PAGE) && (fileName.contains("Page") ||  fileName.contains("PAGE"))) {
			return "Error for:<" + fileName +".>The file naming convention for Page has to be (PAGE|Page)_UNIQUE-ID_([0-9])+"
					+ "_\\.html. "+
		  "For example: 'PAGE_OralHistory_0001.html'. The unique identify UNIQUE-ID has to match of ones of BOOK.";
		}
		return "Error for: <"+fileName+">"+ returnGeneralError;
	}
}

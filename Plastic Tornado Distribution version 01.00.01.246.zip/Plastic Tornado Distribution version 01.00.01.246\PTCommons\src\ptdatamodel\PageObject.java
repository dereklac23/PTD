package ptdatamodel;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import pttools.KCMException;

public class PageObject {
	File filePointer=null;
	BufferedReader bufferedReader=null;
  public PageObject(File _f) {
	  filePointer=_f;
  }
  void process() throws KCMException {
	  if (filePointer.getName().endsWith(".xml")) {
		  processXML();
	  }
  }
  private void processXML() throws KCMException {
	  try {
	  bufferedReader= new BufferedReader(new FileReader(filePointer));
	  } catch (IOException ioe) {
		  throw new KCMException ("Error: file not found"+ filePointer.getName());
	  }
	  
  }
}

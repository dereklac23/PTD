package ptgui;

public interface MenuInterface {
	//public HTMLOutput editor=new HTMLOutput();

	//public abstract void printBody(String _body);
	  public abstract ExpansionFrameSettings allocate(ExpansionFrameSettings _control);
	  public abstract ExpansionFrameGtml allocate(ExpansionFrameGtml _control);
}

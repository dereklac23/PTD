package emailsender.core;
import emailsender.tools.PNotesKCMException;
import emailsender.tools.PNotesPathUtil;
import konagui.*;
import emailsender.gui.*;
import emailsender.html.PNotesHTMLOutput;
import emailsender.html.PNotesTEXTOutput;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;





public class SenderGui {

	private static SenderGui senderGui=null;
	private  enum PANEL_TYPE {  HTML,TEXT, CUBE_CONTROL, PVM, HELP};
	JFrame frame=null;
	public  SenderGui() {		
		    frame = new JFrame("Sender Tool");
	        JPanel panel = (JPanel) frame.getContentPane();
	        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        frame.setSize(600, 700);
	        
	        // Add a label to the frame
	        JLabel label = new JLabel("Sender Tool!", JLabel.CENTER);
	        panel.setLayout(new BorderLayout());
	        panel.add(BorderLayout.NORTH, getNorthPanel());
	        panel.add(BorderLayout.CENTER, getCenterPanel());
	        panel.add(BorderLayout.SOUTH, getSouthPanel());
	        frame.setVisible(true);
	}
    private	int countCommand=0;
	private void doPrintMenu() {
		
		System.out.println("\n1) Load up Annotation SenderGui.xml\nE) Exit\nOptions: [1,E]\n["+countCommand+
				"]>:");
		countCommand++;
	}
	private PNotesPathUtil pathUtil=null, pathUtilSystem, pathUtilSave=null;
	
	private void doLoadAnnotation() throws PNotesKCMException {
		
		pathUtilSystem= new PNotesPathUtil(new File("bin/EmailSender.xml"));
		System.out.println("\nDone loadng annotation");
	}
	private SenderGui(String _command) {
		if (!_command.equals("-commandline")) return;
		

		try {
		BufferedReader bReader= new BufferedReader(new InputStreamReader(System.in));
		doPrintMenu();
		String line=bReader.readLine();
		while (line !=null) {
			
			if (line.equals("1")) {
				doLoadAnnotation();
			} else if (line.equals("E") || line.equals("e")) {
				System.out.println("\nExited SenderGui");
				return;
			}
			doPrintMenu();
			line = bReader.readLine();
		}
		} catch (IOException ioe ) {
			System.err.println("\nError in  reading input");
		} catch (PNotesKCMException kce) {
			System.err.println("KCM error"+ kce.toString());
		}
		
		
	}
	public static void main(String args[] ) {
		if (args.length==1 ) {
		  	senderGui= new SenderGui(args[0]);
		} else {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
		}
	}
	private static void createAndShowGUI() {
		senderGui= new SenderGui();
      
    }

    private JTable jTable=null;
	private JPanel getNorthPanel() {
		
		
		JPanel panel = new JPanel();
                 		
	
		JButton btnAction =new JButton("Provision directory");
		   btnAction.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	            	try {
	               	performProvision();
	            	}catch (PNotesKCMException kcm) {
	            		System.err.println("\nKCMException :"+kcm.toString());
	            	}
	            	jEditor.printPage("Done performing provision size");
	            	
	            }
	        });
		panel.add(btnAction);
		
		JButton btnReset =new JButton("Reset");
	       btnReset.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	           
	            	expansionFrameHtml.reset();
	            	expansionFrameText.reset();
	           
	            	jEditor.printPage("Resetting");
	            	
	            }
	        });
	       
			JButton btnIterate =new JButton("Iterate");
		       btnIterate.addActionListener(new ActionListener() {
		            @Override
		            public void actionPerformed(ActionEvent e) {
		            	performIterate();
		            }
		            		        });


		panel.add(btnAction);
		panel.add(btnReset);
		panel.add(btnIterate);
		//panel.add(jbGroup);
		ComboRenderer cr = new ComboRenderer();
		//jbGroup.setRenderer(cr);
		return panel;
	}
    public void performIterate() {	
    
    	try {
    	StringBuffer sb = new StringBuffer(1028);
    	String text=null;
    	int selectedIndex= kTabPanel.tabbedPanel.getSelectedIndex();
    	if (selectedIndex== kTabPanel.getTabbedIndexHtml()) {
    	sb.append(expansionFrameHtml.provisionHeader());	
    	sb.append(expansionFrameHtml.iterate());
    	text = sb.toString();
    	kTabPanel.htmlOutput.editorHtml.printPage(text);
    	pathUtilSystem.copyToClipboard(text);
    	} else if (selectedIndex == kTabPanel.getTabbedIndexText()) {
    		
    		sb.append(expansionFrameText.provisionHeader()); 
    		Entry entry=null;
    		if (pathUtilSystem.bIterateFilter ) {
    		entry=expansionFrameText.iterateFilter();
    		
    		} else {
    		
    			entry=expansionFrameText.iterate();
    		}
    			
    			if (entry!=null) {
    			sb.append(expansionFrameText.extract(entry.kcmObject,false));
    			} else {
    				sb.append("End");
    			}
    			
    			
    		
        	
        	String fbLink = expansionFrameText.getFacebookLink();
        	if (fbLink!=null) {
        	sb.append("\n\n"+expansionFrameText.getFacebookLink());
        	}
        	text = sb.toString();
        	
        	kTabPanel.textOutput.editor.setText(text);
        	kTabPanel.validate();
        	
        	pathUtilSystem.copyToClipboard(text);
        	
    	}  	
    	
    	
    	
    	} catch (PNotesKCMException kcm) {
    		System.err.println("\nError in kcm:"+kcm.toString());
    	}
    	
    
    	
    }

    
	private JButton btnExpansionHtml=null, btnExpansionText=null;
	public final static int WIDTH=500, HEIGHT=500;
	private ExpansionFramePNotes expansionFrameHtml=null, expansionFrameText=null;
	private JPanel getSouthPanel() {
    	expansionFrameHtml = new ExpansionFramePNotes(ExpansionFramePNotes.TYPE.HTML, WIDTH, HEIGHT);
    	expansionFrameHtml.setPreferredSize(new Dimension(WIDTH+WIDTH/2, HEIGHT));
    	expansionFrameHtml.pack();    	
    	

    	expansionFrameText = new ExpansionFramePNotes(ExpansionFramePNotes.TYPE.TEXT, WIDTH, HEIGHT);
    	expansionFrameText.setPreferredSize(new Dimension(WIDTH+WIDTH/2, HEIGHT));
    	expansionFrameText.pack();    	
    	

		JPanel panel = new JPanel();
		panel.add(btnExpansionHtml=new JButton(("Open Expansion Frame Html")));
		btnExpansionHtml.addActionListener(  new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               expansionFrameHtml.setVisible(true);      
                      	
            	
            }
        });
		panel.add(btnExpansionText=new JButton(("Open Expansion Frame Text")));
		btnExpansionText.addActionListener(  new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               expansionFrameText.setVisible(true);      
                      	
            	
            }
        });

		return panel;
		
	}
	private PNotesHTMLOutput jEditor=null, menuMR;
	private PanelStruct panelArray [] = new PanelStruct[PANEL_TYPE.values().length];
	private PNotesMenuHtml menuHtml =null;
	private PNotesMenuText menuText=null;
	private JTextArea jTextArea=null;
	private JTabbedPane tabbedPane=null;
	private  PNotesTabbedPane kTabPanel=null;
	private JPanel getCenterPanel() {
		JPanel panel = new JPanel();
		tabbedPane = new JTabbedPane();		
		jEditor=new PNotesHTMLOutput(WIDTH, HEIGHT);
		jTextArea = new JTextArea();
		kTabPanel = new PNotesTabbedPane( WIDTH, HEIGHT);	
		
		kTabPanel.allocate("Settings",KeyEvent.VK_1, new PNotesMenuHtml(new PNotesHTMLOutput(WIDTH, HEIGHT), "Settings version 1.0.00.100"));
		kTabPanel.allocate("JTree Html", KeyEvent.VK_3, new PNotesMenuHtml(new PNotesHTMLOutput(WIDTH, HEIGHT), "HTML"));
		kTabPanel.allocate("Twitter Text", KeyEvent.VK_2, new PNotesMenuText(new JTextArea()));
		/*
		kTabPanel.allocate("Music Reactant", KeyEvent.VK_2, new PNotesMenuHtml(
				menuMR=new PNotesHTMLOutput(WIDTH, HEIGHT), 
				"Music Reactant is da' beat! Boom! Boom! Bomm!"));
				*/
	    kTabPanel.freeze(panel);		
		return panel;
	}
	private String targetDirString="data", targetDirBin="bin/data/x";		
	private void performProvision() throws PNotesKCMException {	
		
		if (pathUtil !=null || pathUtilSystem!=null) {
			jEditor.printPage("\nNo need to create a new path util");
		}
		
				
		frame.revalidate();
		
		}
}
	
	



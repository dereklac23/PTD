package konaware.server.util;

import java.awt.Color;
import java.awt.Graphics;
import java.io.PrintWriter;



import konaware.server.RealmSpace;
import konaware.server.atom.IntegerAtom;
import konaware.server.atom.KWServerHashMapEntry;


public class DimensionServerStateOperation {
	
	
	public KWServerHashMapEntry eWidth=null, eHeight=null;
	public DimensionServerStateOperation(String keyWidth, int _eWidth, String keyHeight, int _eHeight) {
		KWServerHashMapEntry mapWidth = new KWServerHashMapEntry(keyWidth, _eWidth);
		KWServerHashMapEntry mapHeight = new KWServerHashMapEntry(keyHeight, _eHeight);		
		eWidth = mapWidth;
		eHeight= mapHeight;
		 
	 }
	public DimensionServerStateOperation(int _eWidth, int _eHeight) {
		KWServerHashMapEntry mapWidth = new KWServerHashMapEntry(RealmSpace.BOARD_PROVISION_X_STRING, _eWidth);
		KWServerHashMapEntry mapHeight = new KWServerHashMapEntry(RealmSpace.BOARD_PROVISION_Y_STRING, _eHeight);		
		eWidth = mapWidth;
		eHeight= mapHeight;		 
	 }

	public DimensionServerStateOperation(KWServerHashMapEntry width, KWServerHashMapEntry height) {
		eWidth= width;
		eHeight = height;
		
	}
	 public void print(PrintWriter pw) { 
		 eWidth.Print(pw);
		 eHeight.Print(pw);
	     
	 }
	 public int getWidth() {
		 IntegerAtom atomI = (IntegerAtom)eWidth.getDataAtom();
		 return atomI.getInteger();
	 }
	 
	 public int getHeight() {
		 IntegerAtom atomI = (IntegerAtom)eHeight.getDataAtom();
		 return atomI.getInteger();
	 }
	 
	 public String getDescribeString() {
		StringBuffer sb = new StringBuffer();
		sb.append("\n Describing DSO"+ getWidth() + ":"+ getHeight());
		return sb.toString();
	 }

	 public void paintComponent(Graphics g) {
		 
		 int width = getWidth();
		 int height = getHeight();
		 System.out.println("\npaitining"+width+":"+height);
		 g.setColor(Color.PINK);
		 g.fillRect(0, 0, width, height);				          
		 g.setColor(Color.GRAY);
		 g.fillRect(10, 10, width-20, height-20);
	 }
}

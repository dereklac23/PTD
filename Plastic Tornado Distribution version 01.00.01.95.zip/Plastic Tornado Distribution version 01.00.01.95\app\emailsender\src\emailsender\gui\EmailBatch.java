package emailsender.gui;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JLabel;

import emailsender.KCMException;
import emailsender.KCMObject;
import emailsender.gui.Entry.EntryType;
import emailsender.html.HTMLOutput;

public class EmailBatch {
    public int startIndex=0, endIndex=0, groupNumber=0, modulo=0, runningIndex=0;
    public JLabel label=null;
    
    private final static int MAX_GROUP = 4;
    private char moduloArray[] = new char[MAX_GROUP];
    public String summaryHTML=null;
    public ArrayList<Entry> batchList =null;
//    public numEntry=0;
   
	public EmailBatch(int _groupNumber, int _startIndex, int _endIndex) {
		groupNumber = _groupNumber;
		startIndex =_startIndex;
		endIndex = _endIndex;
		label = new JLabel ("item"+_startIndex +":"+_endIndex);
		batchList = new ArrayList<Entry>();
		
	}
	public int getNumEntry() {
		int totalCount=0;
	  for (int i=0; i < batchList.size(); i++) {
		  Entry bEntry = batchList.get(i);
		  totalCount+=bEntry.numEntry;
		  
	  }
	  return totalCount;
	  
	}
	
	public Entry allocateEntry(EntryType _t, KCMObject _kcm, int _runningCount) throws KCMException  {
		Entry e =new Entry( this,_kcm, _runningCount);
		
		batchList.add(e);
		return e;
		
	}
	public String extract(HTMLOutput.TAG _tag) throws KCMException  {
		StringBuffer sb = new StringBuffer();
	
		if (_tag == HTMLOutput.TAG.TABLE) {
			   sb.append("<tr bgcolor='#b57841'>"+HTMLOutput.getTD(Color.gray,"Group:("+groupNumber +
					   ") Start index:["+startIndex+"] to End index:["+ 
		                     endIndex +"] Total Batch Count:"+ batchList.size()+"</tr>"));
			 int totalCount=0;
		   	for (int i=0; i < batchList.size(); i++) {
		   		Entry entryBatch = batchList.get(i);
		   		totalCount +=entryBatch.numEntry;
		   		//sb.append(entryBatch.extract(HTMLOutput.TAG.TABLE));
		   		
		   	}
		   		
		   		
		   		
		
		}
		return sb.toString();
	}
	
  
	public int compare(Batch _pointer) {
		if (_pointer ==null) {
			return -1;
		} else {
		return (_pointer.index - endIndex) ;
		}
		 
	}
	
	public String toStringHTML() {
		return "\nGroup number:" + groupNumber+":\n"+summaryHTML+':'+ modulo;
				
	}
	public void setModulo(int _value) {
		modulo = _value;		
		//allocateModulo();
		
	}
	private String getTD(int _value) {
		return "<td>"+_value+"</td>";
	}
	private String getTD(String _body) {
		return "<td>"+_body+"</td>";
	}
	private String getModuloTD(int _groupNumber,int _value) {
		if (_groupNumber==1 ) {
			return "<td>Always 1</td>";
		} else {
			return getTD(_value);
		}
	}
	private String getModuloMaskXmlTD() {
         return getTD(getMaskXml());	 																						
	}
	
	public String getXmlSummaryTable(HTMLOutput.TAG _tag) throws KCMException  {
		StringBuffer sb = new StringBuffer(1028);
		if (_tag== HTMLOutput.TAG.TABLE) {
		  //sb.append("<tr><td>Group ID</td><td>Modulo value</td><td>Modulo mask</td></tr>");
		  sb.append("<tr><td>Group number:</td>" + getTD(groupNumber) + "<td>Modulo</td>"+
		  getModuloTD(groupNumber,modulo)+"<td>Modulo mask</td>"+getModuloMaskXmlTD());
		  
		} else if (_tag== HTMLOutput.TAG.RAW) {
		  sb.append("\nGroup number:"+groupNumber+":"+ getMaskXml());
			
		}
		
		int runningCount=0;
		for (int i=0; i < batchList.size() ; i++) {
			Entry eTag = batchList.get(i);
			//sb.append("<tr><td>");
			runningCount += eTag.numEntry;
			//sb.append("<tr bgcolor='#bff0ed'><td>"+ runningCount+"</td></tr>");
			sb.append("<tr bgcolor='#bff0ed'><td>Group running count:"+ runningCount+"</td></tr>");
					
			sb.append(eTag.extract(HTMLOutput.TAG.TABLE));
			sb.append("<tr bgcolor='#aff3ed'><td>Group Batch Number:"+ i +"</td></tr>");
			//sb.append("</td></tr>");
		}
		return sb.toString();
	}
	public boolean bGroup(int _runningIndex) {
	
		return _runningIndex >= startIndex && _runningIndex < endIndex;
	}

	private char getChar(boolean _bHit) {
		if (_bHit) {
			return 'O';
		} else {
			return '0';
		}
	}
	public String getMaskXml() {
		
		char charArray[]= allocateZeroChar(groupNumber);
		if (groupNumber==1) {
		charArray[0]='O';
		} else {
			charArray[modulo]='X';
		}
		return new String(charArray);
		
//		return summaryHTML;
	}
	public String getMaskKey() {
		char charArray[]= allocateZeroChar(groupNumber);
		if (groupNumber==1) {
		charArray[0]='|';
		} else {
			charArray[modulo]='|';
		}
		return new String(charArray);
	}
	public String getMaskKey(int _index) {
		int moduloValue = _index%groupNumber;
		char charArray[]= allocateZeroChar(groupNumber);
		if (groupNumber==1) {
		charArray[0]='|';
		} else {
			charArray[moduloValue]='|';
		}
		return new String(charArray);
	}
	
	
	public String getSendStatus(int _index) {
		int moduloValue = _index%groupNumber;
		//char charArray[]= allocateZeroChar(groupNumber);
		if (groupNumber == 1) {
			return "Sent";
		}else  if (moduloValue == modulo) {
			return "Sent";
		} else return "Filtered";
		
	}

	
	private char[] allocateZeroChar(int _length) {
		char charArray[]=null;
		charArray = new char[_length];
		for (int i=0; i < charArray.length; i++) {
			charArray[i]='O';
		}
		
		return charArray;
	}
	
	public String getModulo(int _runningIndex) {
		StringBuffer sb = new StringBuffer();
		sb.append("Group number:"+groupNumber);
		char charArray []=null;
		if (groupNumber ==1) {
			return "Always X for Group 1";
		} else if (groupNumber > 1 && groupNumber <=4) {
			int moduloCompute= _runningIndex % groupNumber;
             charArray = allocateZeroChar(groupNumber);             
	       charArray[moduloCompute]='O';
	       return new String(charArray).toString();
		
	}
		return "<>";
	}
}


	
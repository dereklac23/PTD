/**
 * 
 */
/**
 * 
 */
module MidiPiano {
	requires java.desktop;
}
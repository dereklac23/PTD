package wepiano;

import javax.sound.midi.MidiMessage;
import javax.sound.midi.Receiver;
import javax.sound.midi.ShortMessage;

public class MidiInputReceiver implements Receiver {
        @Override
        public void send(MidiMessage message, long timeStamp) {
            if (message instanceof ShortMessage) {
                ShortMessage sm = (ShortMessage) message;
                System.out.println("Received MIDI message: Command=" + 
                sm.getCommand() + " Channel=" + sm.getChannel() + 
                " Data1=" + sm.getData1() + " Data2=" + sm.getData2());
            }
        }

        @Override
        public void close() {
            // Handle receiver close if needed
        }
    }
  
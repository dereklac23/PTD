/**
 * 
 */
/**
 * 
 */
module ReleaseTool {
	requires java.desktop;
	requires java.xml;
}
package releasetool.gui.datamodel;

import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;

public class ComboListener implements TableModelListener {
   public ComboListener() {
	System.out.println("\nCombo listener added");   
   }
	@Override
	public void tableChanged(TableModelEvent e) {
		// TODO Auto-generated method stub
       
           
	}

}

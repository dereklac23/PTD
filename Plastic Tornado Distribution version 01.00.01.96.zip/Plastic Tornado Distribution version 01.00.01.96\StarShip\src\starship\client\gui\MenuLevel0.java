package starship.client.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import starship.atom.LocalContainer;


public class MenuLevel0 extends JPanel {
    private LocalContainer localContainer=null;
    private JTextArea taOutput=null;
    private JButton btnWorkingDirectory =null, btnUploadFile=null;
    private JTextField tfFileDirectory =null, tfWorkingDirectory=null;
    private FileProperties fileProperties = null;
	public MenuLevel0 (LocalContainer _localContainerL0) {
		localContainer = _localContainerL0;
		add(BorderLayout.CENTER, getControlPanel());
		
	}
	private boolean shouldFill = true, shouldWeightX =true;
	JFileChooser fileChooser=null;
	File workingDirectory =null;
	//private PathUtil pathUtil = new PathUtil();
	private JPanel getControlPanel() {
		JPanel panel = new JPanel();		
		panel.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		
		if (shouldFill) {
		                //natural height, maximum width
		                c.fill = GridBagConstraints.HORIZONTAL;
		}

		btnWorkingDirectory = new JButton("Select Working Directory:");
		fileChooser  = new JFileChooser();
		    
	        
	        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	        btnWorkingDirectory.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                // Show a message dialog when the button is clicked
	            	 int returnVal = fileChooser.showOpenDialog(panel);

	                 if (returnVal == JFileChooser.APPROVE_OPTION) {
	                     workingDirectory= fileChooser.getSelectedFile();
	                     fileProperties.populate(workingDirectory);
	                     
	                     
	                 } else {
	                 }
	            }
	        });


	  
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx=.05;
		panel.add(btnWorkingDirectory, c);
	
        

		tfWorkingDirectory= new JTextField(25);
		
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 0.95;
		c.gridx = 1;
		c.gridy = 0;
		panel.add(tfWorkingDirectory, c);
		
		
		btnUploadFile= new JButton("Upload File:");
		c.fill = GridBagConstraints.HORIZONTAL;
		c.weightx = 0.05;
		c.gridx = 0;
		c.gridy = 1;
		panel.add(btnUploadFile, c);
		

        btnUploadFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
            	fileProperties.execute();
                    }
        });


		c.fill = GridBagConstraints.HORIZONTAL;
		c.ipady = 10;      //make this component tall
		c.weightx = 0.0;
		c.gridwidth = 2;
		c.gridx = 0;
		c.gridy = 2;
		//fileProperties = new FileProperties(localContainer);		
//		panel.add(fileProperties,c);

		


		c.fill = GridBagConstraints.HORIZONTAL;		
		c.ipady = 10;      //make this component tall
		c.weightx = 0.0;
		c.gridwidth = 2;
		c.gridx = 0;
		c.gridy = 3;
		
		panel.add(taOutput = new JTextArea(10,10), c);

		
		return panel;
	}

} 

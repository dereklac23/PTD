package emailsender.gui;
import emailsender.html.*;



import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Vector;

import emailsender.DirectoryObject;
import emailsender.KCMException;
import emailsender.KCMObject;
import emailsender.html.HTMLOutput;
import emailsender.html.StructureTable;
import emailsender.konagui.ClickRename;

public class Entry {
    Entry father;
    Entry  mother;
    public ArrayList<Entry> children;
    private String name;
    public  File file=null, directory=null;
    public String body=null;
    public String value=null;
    public int index=0, numEntry=0;
    public String line=null;

    public StringBuffer bufferBody=null;
   
    public ArrayList<String> pathList = null;
    public File root=null;
    public String header=null;
    public GroupModel groupModel=null;
    public EmailBatch emailBatchPointer=null;
    public Entry batch=null;
    public KCMObject kcmObject=null;
    
    

    public enum EntryType {ROOT,GROUP,EMAIL_BATCH,BATCH,KCM, TAG, FACEBOOK_LINK, CORE, BASIC};
    public enum EntrySubType {HEADER, UNIQUE_ID,  ITERATION};
    public EntryType type = EntryType.GROUP;
    public DirectoryObject directoryObject=null;
    public ArrayList <Entry> entryList=null;
    //public int batchNumber=0;
    public ArrayList<Batch> batchList = null;
   
    public String tag=null;
   
    
    
    public Entry(KCMObject _kcmO, int _runningIndex) {
    	type = EntryType.TAG;
    	kcmObject = _kcmO;
    	index = _runningIndex;
    	
    }
    public Entry(EmailBatch _batchPointer,KCMObject _kcm, 
    		int _runningIndex) {
      type = EntryType.TAG;
      emailBatchPointer = _batchPointer;
      kcmObject = _kcm;
      index  = _runningIndex;
      
      numEntry = kcmObject.entryList.size();
   
    }
    public Entry(Entry _e, KCMObject _kcm,int _index) {
    	type = EntryType.BATCH;
    	batch= _e;
    	index = _index;
    	kcmObject = _kcm;
    	
    }

    public Entry(Entry _batchEntry, int _runningIndex) {
      type = EntryType.BATCH;
      batch = _batchEntry;      
      index  = _runningIndex;      
//      
    }
    
    public Entry(EntryType _type, String _line) {
    	type = EntryType.TAG;
    	line = _line;
    	numEntry = kcmObject.entryList.size();
    	//index = _runningCount;
    }
    
    
    public Entry(EntryType _type, String _line, DirectoryObject _dO) {
    	type =_type;
    	line = _line;
    	directoryObject = _dO;
    }
    
    
    /**
     * Main entry for tag
     */
   
    
    public Entry( EmailBatch _eb) {    	
    	emailBatchPointer = _eb;
    	children = new ArrayList<Entry>();
    	for (int i=0; i < emailBatchPointer.batchList.size(); i++) {
    		Entry entryBatch = emailBatchPointer.batchList.get(i);
    	   	Entry eBatch = new Entry(entryBatch,  _eb.startIndex + i);
    	   	children.add(eBatch);
    	}
 
    }
    
    
    public Entry (EntryType _type,KCMObject _kcmO) {
    type = _type;    
    bufferBody= _kcmO.bodyBuffer;
    }

    public Entry (EntryType _type, StringBuffer _sb) {
    	type = _type;
    	bufferBody = _sb;
    	
    }
   
    
    public EmailBatch emailGroup=null;
  
    
    public Entry(String _title, GroupModel _gM) {
    
     type = EntryType.ROOT;
     name = _title;
     groupModel = _gM;
     
    }
    
   public String extract(HTMLOutput.TAG _tagType) throws KCMException {
	   StructureTable st  = new StructureTable();
	   
	   StringBuffer sb = new StringBuffer();
	   StructureTD structTD= new StructureTD();
	   StructureTR structTR= new StructureTR();
	   //StructureTable structTable = new StructureTable();
	   if (type == EntryType.GROUP && emailBatchPointer==null) {
		   structTD.push("Empty batch");
		   structTR.push(structTD);
		   //structTable.push(structTR);
		   
		  return structTR.pull();
	   }
	   if (type == EntryType.GROUP) {
		   structTD.push(emailBatchPointer.extract(_tagType));		   
		   structTR.push(structTD);
		   //structTable.push(structTR);
		   if (_tagType == HTMLOutput.TAG.TABLE) {
			  
		   return structTR.pull();
		   }
			   
	
      } else if (type == EntryType.BATCH && _tagType == HTMLOutput.TAG.TABLE) {
    	  if (kcmObject == null ) {
    		  throw new KCMException ("Batch has emty tags entry.");
    	  }
    	  

    	  
    	  
      } else if (type == EntryType.EMAIL_BATCH) {
    	  if (_tagType == HTMLOutput.TAG.TABLE) {
    		  
    		  if (children !=null) {
    			  
    		  for (int i=0; i < children.size(); i++) {
    			  Entry eBatch= children.get(i);
    			  sb.append("<tr bgcolor='gray'>");
    			  sb.append("<td>"+"Email Batch"+ "</td></tr>");
    			  sb.append(eBatch.extract(_tagType));
    		  }
    		  
    		  }
    		
    	  }
      } else if (type == EntryType.BASIC || type == EntryType.CORE) {
    	  sb.append("<tr><td>"+line +"</td></tr>");    	  
    	  
      } else if (type == EntryType.TAG) {
    	  if (_tagType == HTMLOutput.TAG.TABLE) {
    		  int runningIndex =0, totalCount=0;
    		  for (int i=0; i < kcmObject.entryList.size(); i++) {
    			  runningIndex = index + i;
    			  Entry e = kcmObject.entryList.get(i);
    			 // totalCount += kcmObject.entryList.size();
    			  if (e.line !=null) {
    			  sb.append("\n<tr bgcolor='gray'><td> "+e.line+"</td></tr>");
    			  }
    		  }
    		  //sb.append("<tr><td>"+line+"</td></tr>");  
    	  } else if (_tagType == HTMLOutput.TAG.RAW) {
    		  for (int i=0; i < kcmObject.entryList.size(); i++) {
    			  Entry e = kcmObject.entryList.get(i);
    			  if (e.line !=null) {
    			  sb.append(e.line);
    			  }
    		  }
    	  }
    	  
      }

	   return sb.toString();
	   
   }
    
    public void print (HTMLOutput _htmlO, Entry _entryChild) throws KCMException  {
    	 ClickRename clickRename = new ClickRename(_htmlO, "Rename");
    	 
    	if (type == EntryType.ROOT ) {
    		_htmlO.attachHeader();
    		_htmlO.attachP("root:");
    		_htmlO.attachRaw("<table>");
    		_htmlO.attachRaw("<tr><td>Start of table</td></tr>");
    		 groupModel.printSummaryBody(_htmlO);    		
    		

    		_htmlO.attachRaw("</table>");
//    		StringBuffer sb = new StringBuffer();
    		 
    		clickRename.printLink();    		
    		_htmlO.attachEnder();
    		
    		_htmlO.printPage();
    		groupModel.copyToClipboard(_htmlO.getPageBuffer());
    		
    		
    		
    	} else if (type == EntryType.GROUP) {
    		_htmlO.attachHeader();
    		if (children !=null) {
    		_htmlO.attachP("Group:"+ children.size());
    		} else if (emailBatchPointer !=null) {
    		   _htmlO.attachP("Group embatchpointer:" + emailBatchPointer.extract(HTMLOutput.TAG.TABLE));
    		}
    		_htmlO.attachEnder();
    		_htmlO.printPage();    		
    		
    		
    	} else if (type == EntryType.EMAIL_BATCH) {
    		_htmlO.attachHeader();
    		_htmlO.attachP("Info");
    		_htmlO.attachP("Email batch"+ index);
    		_htmlO.attachRaw("<table>");
    		StringBuffer sb = new StringBuffer();
    		if (children ==null) {
    			throw new KCMException ("EmailBatch has empty batch entries of type BATCH");
    		}
    		for (int i=0; i < children.size(); i++) {
    			Entry entry = children.get(i);
    		    sb.append("<tr bgcolor='green'>");
    		    entry.extract(HTMLOutput.TAG.TABLE);
    		    sb.append("</tr>");
    		}
    		_htmlO.attachRaw("</table>");
    		_htmlO.attachEnder();
    		_htmlO.printPage();
    	} else if (type == EntryType.BATCH ) {
    		
    		_htmlO.attachHeader();
    		
    		for (int i=0; i < batch.kcmObject.entryList.size();i++) {
    			Entry eTag = batch.kcmObject.entryList.get(i);
    			_htmlO.attachP(eTag.line);
    		}
    		
    		_htmlO.attachEnder();
    		_htmlO.printPage();
    		
    	} else if (type == EntryType.FACEBOOK_LINK) {
    		
    		_htmlO.attachHeader();
    		_htmlO.attachP(bufferBody.toString());
    		_htmlO.attachEnder();
    		_htmlO.printPage();
    		
    	} else if (type == EntryType.BASIC || type == EntryType.CORE) {
            _htmlO.attachHeader();
             _htmlO.attachHeader();
    		_htmlO.attachP(line);
    		_htmlO.attachEnder();
    		_htmlO.printPage();

    	
    	} else if (type == EntryType.TAG) {
    		_htmlO.attachHeader();
    		_htmlO.attachP(line);
    		_htmlO.attachEnder();
    		_htmlO.printPage();
    	}
    	System.out.println("\n end of group:"+ type);
    }

    /**
    *   Link together all members of a family.
    *
    *   @param pa the father
    *   @param ma the mother
    *   @param kids the children
    */
    public static void linkFamily(Entry pa,
                                  Entry ma,
                                  Entry[] kids) {
        for (Entry kid : kids) {
            pa.children.add(kid);
            ma.children.add(kid);
            kid.father = pa;
            kid.mother = ma;
        }
    }
    public static void linkFamily(Entry ma,
            Entry[] kids) {
    	for (Entry kid : kids) {    		
    		ma.children.add(kid);    		
    		kid.mother = ma;
        }
}
    
    public static void linkFamily(Entry ma,
    		 Entry kid) {
    	ma.children.add(kid);
    	kid.mother= ma;
    }
    
    

/// getter methods ///////////////////////////////////

    public String toString() {

    	  if (type== EntryType.BATCH) {
    			  return "Batch:";//batchPointer.batchNumber;
    	  } else if (type == EntryType.FACEBOOK_LINK) {    		  
    		  return "Facebook:"+bufferBody.toString().substring(0, 10);
    	  } else if (type == EntryType.CORE || type == EntryType.BASIC) {
    		  return "X TAg:"+ line;
    	  } else if (type == EntryType.GROUP) {
    		  return "I:"+index;
    		  
    	  } else if (type == EntryType.TAG) {
    		  return "Tag: "+line;
    	  } else if (type == EntryType.ROOT) {
    		  return "Root: "+name;
    		  
    	  }
    		
    	return "X Tag:"+ type;    		
    }
    	 
    	
    
    public Entry  getFather() { return father; }
    public Entry getMother() { return mother; }
    public int getChildCount() { 
    	if (children ==null) {
    		return 0;
    	}else return children.size(); }
    public Entry getChildAt(int i) {
        return (Entry)children.get(i);
    }
    public int getIndexOfChild(Entry kid) {
        return children.indexOf(kid);
    }
  
}

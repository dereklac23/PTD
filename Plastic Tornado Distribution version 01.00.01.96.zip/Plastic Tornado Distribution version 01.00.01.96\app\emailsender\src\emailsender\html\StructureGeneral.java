package emailsender.html;

import java.util.Stack;

public abstract class StructureGeneral {
  public Stack<StructureGeneral> generalList= new Stack<StructureGeneral>();

  public String tokenList [] = new String[token.values().length];
  public abstract  void push(StructureGeneral _sg) ;
  public abstract String pull() ;
  public enum token {HEAD, TAIL};
}

package emailsender.html;
//import emailsender.html.StructureGeneral;
import java.util.ArrayList;
import java.util.Stack;

public class StructureTD extends StructureGeneral {
	public enum token2 {HEAD, TAIL};
    
    public StructureTD() {
     tokenList[token2.HEAD.ordinal()] = "<tr>";
     tokenList[token2.TAIL.ordinal()] = "</tr>";
     
    }
    private String token=null;
    
   public StructureTD(String _token) {
	   token = _token;
   }
	
	public void push( String _token) {
		generalList.add(new StructureTD(_token));
		token= _token;
		
	}
	public String pull() {
		StringBuffer sb = new StringBuffer();
		for (int i=0; i < generalList.size(); i++) {
			
			sb.append(tokenList[token2.HEAD.ordinal()]);
			sb.append(token);
			
			sb.append(tokenList[token2.TAIL.ordinal()]);
		}
		
		// TODO Auto-generated method stub
		return sb.toString();
	}
	
	public void push(StructureGeneral _sg) {
		// TODO Auto-generated method stub
		
	}

	
}

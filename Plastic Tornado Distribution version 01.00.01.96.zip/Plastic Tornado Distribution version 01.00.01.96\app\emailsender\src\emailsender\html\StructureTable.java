package emailsender.html;

import java.util.ArrayList;
import java.util.Stack;

public class StructureTable extends StructureGeneral  {
    
    
    public StructureTable() {
     tokenList[token.HEAD.ordinal()] = "<table>";
     tokenList[token.TAIL.ordinal()] = "</table>";
     
    }
    
	@Override
	
	public void push(StructureGeneral _sg) {
		generalList.add(_sg);
	}
	public String pull() {
		StringBuffer sb = new StringBuffer();
		for (int i=0; i < generalList.size(); i++) {
			sb.append(tokenList[token.HEAD.ordinal()]);
			StructureGeneral sg = generalList.pop();
			sb.append(sg.pull());
			sb.append(tokenList[token.TAIL.ordinal()]);
		}
		
		// TODO Auto-generated method stub
		return sb.toString();
	}

	
}

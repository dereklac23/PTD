package emailsender.konagui;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JFileChooser;

import emailsender.html.HTMLOutput;

public class ClickRename extends HCustomListener {

	JFileChooser chooser = new JFileChooser();
    File defaultDir=null;

// I don't want this to be hard-coded:
      //String filePath = "/Users/Bill/Desktop/hello.txt";
	
	public ClickRename(HTMLOutput _hOutput, String _action) {
		super(_hOutput, _action);
		chooser.setFileSelectionMode(  JFileChooser.FILES_ONLY);
		chooser.setCurrentDirectory(defaultDir=new File("D:/dev"));
		// TODO Auto-generated constructor stub
	}

	@Override
	public void execute() {
	    int returnValue = chooser.showOpenDialog( null ) ;
	    if( returnValue == JFileChooser.APPROVE_OPTION ) {
	    File file = chooser.getSelectedFile() ;
	    try {
	    PrintWriter pw = new PrintWriter(  file);
	    System.out.println("saved:"+ htmlOutput.getPageBuffer());
	    pw.write(htmlOutput.getPageBuffer());
	    pw.close();
	    } catch (IOException ioe) {
	    	System.err.println("\nCannot write to file.");
	    }
	    
	    
	    
	    
	    String content=htmlOutput.getPageBuffer();	    
	    }
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printLink() {
		// TODO Auto-generated method stub
		
		htmlOutput.attachRaw("<a href='rename'>Rename</a>");
		
	}


	
}

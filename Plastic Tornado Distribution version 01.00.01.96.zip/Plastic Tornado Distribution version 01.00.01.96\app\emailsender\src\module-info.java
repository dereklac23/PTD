/**
 * 
 */
/**
 * 
 */
module emailsender {
	requires java.desktop;
	requires java.xml;
	requires java.datatransfer;
}
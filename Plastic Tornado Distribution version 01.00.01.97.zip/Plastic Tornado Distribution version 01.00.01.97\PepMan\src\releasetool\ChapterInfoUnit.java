package releasetool;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;

import releasetool.BookInfoUnit.TYPE;

public class ChapterInfoUnit implements GeneralUnit {
	public File root=null;
	public Path path=null;
	
	public String uniqueID = null;
	public String nameTag=null;
	public String h1, h2, h3, h4, h5, h6;
	public enum TYPE {
		CHAPTER,
		H1, H2, H3, H4, H5, H6
		};
	private final static String prefix ="/Chapter";
	public String []TYPE_STRING= {
			"/Display/@Value",
			"/H1/@Value", 
			"/H2/@Value",
			"/H3/@Value", 
			"/H4/@Value", 
			"/H5/@Value", 
			"/H6/@Value", 
    };
	private int  ordinalPointer=0;
	public HashMap<String, ChapterInfoUnit> chapterMap = new HashMap<String, ChapterInfoUnit>();
	public ChapterInfoUnit infoUnit[] = new ChapterInfoUnit[TYPE.values().length];
	public ArrayList<ChapterInfoUnit> listOfChapters = new ArrayList<ChapterInfoUnit>();
	public ChapterInfoUnit(int _ordinalPointer) {
		ordinalPointer = _ordinalPointer;
	}
	public ChapterInfoUnit(String _uniqueID, String _nameTag) {
		uniqueID = _uniqueID;
		nameTag = _nameTag;
	}
	public ChapterInfoUnit(String _nameTag) {
		nameTag= _nameTag;
	}
	public ChapterInfoUnit(File _root, Path _p) {	
		root=_root;		
		path = _p;
		load();
	}
	
	
	
		
		public String getTag() {
		//System.out.println("\nTag of ordinar"+ ordinalPointer);
			return prefix+TYPE_STRING[ordinalPointer];
	}
	public String getValue() {
		//System.out.println("\nGetting value:"+ ordinalPointer +":"+TYPE_STRING[ordinalPointer]);
		
		ChapterInfoUnit ciu= chapterMap.get(TYPE_STRING[ordinalPointer]);
		if (ciu ==null) {
			return null;
		} else if (ciu.getValue()==null){
			return null;
		} else {
			
			return ciu.getValue();
		}
	}
	public String headerString=null, chapterString;
	  
   public void add(ChapterInfoUnit _ciu) {	   
	   chapterMap.put(_ciu.getTag(), _ciu);
   }
	
   public String getEntry (int _index) {
	   
	   if (_index==0) {
		   return chapterString;
	   }
	   for (int i=0; i < listOfChapters.size(); i++) {
		   ChapterInfoUnit ciu = listOfChapters.get(i);
		   if (ciu.headerString!=null) {
			   return ciu.headerString;
		   }
	   }
	   return null;
	   
   }
   
   
	private void load() {
		for (int i=0; i < TYPE.values().length; i++) {
			//System.out.println("\nadding units for parsing");
			listOfChapters.add(new ChapterInfoUnit(i));
		}
	}

	
	
	
}

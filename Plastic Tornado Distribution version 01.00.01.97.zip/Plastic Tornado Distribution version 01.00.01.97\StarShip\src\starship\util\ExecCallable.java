package starship.util;
public interface ExecCallable {
		//public abstract void doExecute(LocalContainer localContainer) throws AtomException ;
		public abstract void doExecute();
			
		
		
	}
package emailsender.html;
import emailsender.gui.*;

import java.util.ArrayList;

import javax.swing.JTextArea;

import emailsender.KCMException;
import emailsender.gui.Entry.EntryType;
import emailsender.gui.GroupModel.GROUP_TYPE;

public class TEXTOutput extends JTextArea {
  public GroupModel groupModel =null;
  public String description=null;
  public TEXTOutput(GroupModel _groupM) {
	  groupModel = _groupM;
  }
  public TEXTOutput() {
	  
  }
  public String extractBodyGroup(Entry _entry) {
	  StringBuffer sb = new StringBuffer();
	  sb.append("Full summary of the send tags.");
	  sb.append("\n"+_entry.children.size());
	  for (int i=0; i < _entry.children.size(); i++) {
		  Entry entryChild = _entry.children.get(i);
		  sb.append("\n"+entryChild.toString());
		  if (entryChild.type == Entry.EntryType.TAG) {
		  //sb.append("\n"+extractTag(entryChild.batchList));		
		  }
	  }
	  return sb.toString();
  }
  private String extractTag(Batch _batch) throws KCMException {
	  return extractTag(_batch.batch.kcm.entryList);
  }
  private String extractTag(ArrayList<Entry>_entryList) throws KCMException {
	  if (_entryList== null) {
		  throw new KCMException("Array list tag entries is null");
	  }
	  StringBuffer sb = new StringBuffer(1028);
	  for (int i=0; i < _entryList.size(); i++) {
		  Entry eC = _entryList.get(i);
		  if (eC !=null) {
		  sb.append("\n"+_entryList.get(i));
		  }
		  
	  }
	  return sb.toString();
  }
  
  public String extractHeader(HTMLOutput.TAG _tag) throws KCMException {
	  return groupModel.getModuloXmlSummary(_tag);
	  
  }
  
  public String extract(EmailBatch _eb) {
	StringBuffer sb = new StringBuffer();	
	return sb.toString();
  }
  public String extractBody(ArrayList<Entry> _entryList, boolean verbose) throws KCMException {
	  StringBuffer sb = new StringBuffer(1028);
	  if (verbose ) {
		  for (int i=0; i < _entryList.size(); i++) {
			  Entry eLine= _entryList.get(i);
			  sb.append(eLine.line);
			  
		  }
		  
		  
	  } else {
		  if (_entryList== null) {
			  throw new KCMException("Body extract: entry list is null");
		  } 
		  for (int i=0; i < _entryList.size(); i++) {
			  Entry entry= _entryList.get(i);
			  sb.append(entry.line);
			  //EmailBatch eb = entryChild.emailGroup;
			  //extract(eb);
			  
		  }
		  
	  }
	  return sb.toString();
  }
  
  /*
   * for (int i=0; i < batch.kcmObject.entryList.size();i++) {
    			Entry eTag = batch.kcmObject.entryList.get(i);
    			_htmlO.attachP(eTag.line);
    		}
   */
  
  public String extractFullReport(Entry _entry) throws KCMException {

	  StringBuffer sb = new StringBuffer(1028);
	  
	  sb.append("Summary of the send tags.");
	  sb.append("\n"+groupModel.getModuloXmlSummary(HTMLOutput.TAG.RAW));
	  sb.append("\nTotal batch:"+_entry.children.size());
	  sb.append("\n");
	  
	  for (int i=0; i < _entry.children.size(); i++) {
		  Entry entryChild = _entry.children.get(i);
		 // 
		  
		  //sb.append("\n"+entryChild.body);
            
			int groupNumber = groupModel.getGroup(_entry.index+i);
		    sb.append("\n\n\n  Group number:"+groupNumber + "  :  " + 
			      
				 groupModel.getSendStatus(groupNumber,  _entry.index+i));
		    
		  
		    //sb.append(extractTag(entryChild));
		    sb.append(groupModel.getMaskKey(groupNumber, _entry.index+i));
		    sb.append(extractModuloInfo(entryChild));
		    
		  
		  
		  
	  }

	  
	  return sb.toString();
  }
  public String extractModuloInfo(Entry _entry) {
	  //StringBuffer sb = new StringBuffer(1028);
	 return groupModel.getMaskKey(_entry.index);
	 //return sb.toString();
  }
//  public String 
}

package releasetool.gui.datamodel;

import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public abstract class HCustomListener implements HyperlinkListener {

	
	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		System.out.println("\n@@@custom listener");
		// TODO Auto-generated method stub
		
	}
	public void execute() {
		
	}


}
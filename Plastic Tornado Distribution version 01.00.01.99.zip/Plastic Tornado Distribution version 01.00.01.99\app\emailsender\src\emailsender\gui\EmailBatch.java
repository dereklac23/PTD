package emailsender.gui;
import emailsender.html.*;

import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JLabel;

import emailsender.KCMException;
import emailsender.KCMObject;
import emailsender.gui.Entry.EntryType;
import emailsender.html.HTMLOutput;

public class EmailBatch {
    public int startIndex=0, endIndex=0, groupNumber=0, modulo=0, runningIndex=0;
    public JLabel label=null;
    
    private final static int MAX_GROUP = 4;
    private char moduloArray[] = new char[MAX_GROUP];
    public String summaryHTML=null;
    public ArrayList<Entry> batchList =null;
//    public numEntry=0;
   
	public EmailBatch(int _groupNumber, int _startIndex, int _endIndex) {
		groupNumber = _groupNumber;
		startIndex =_startIndex;
		endIndex = _endIndex;
		label = new JLabel ("item"+_startIndex +":"+_endIndex);
		batchList = new ArrayList<Entry>();
		
	}
	public int getNumEntry() {
		int totalCount=0;
	  for (int i=0; i < batchList.size(); i++) {
		  Entry bEntry = batchList.get(i);
		  totalCount+=bEntry.numEntry;
		  
	  }
	  return totalCount;
	  
	}
	
	public Entry allocateEntry(EntryType _t, KCMObject _kcm, int _runningCount) throws KCMException  {
		Entry e =new Entry( this,_kcm, _runningCount);		
		batchList.add(e);
		return e;
		
	}
	public String extract(HTMLOutput.TAG _tag) throws KCMException  {
		StringBuffer sb = new StringBuffer();
	
		if (_tag == HTMLOutput.TAG.TABLE) {
			   StructureTD  structTD =new StructureTD();
			   structTD.push(new StructureTD("Group:"+ groupNumber));
			   structTD.push(new StructureTD("Start index:"+ startIndex));
			   structTD.push(new StructureTD("End index:"+ endIndex));
			   structTD.push(new StructureTD("Total batch count:"+ batchList.size()));
			   StructureTR  structTR = new StructureTR();
			   structTR.push(structTD);			   
			
			   sb.append(structTR.snapShot());
			 int totalCount=0;
		   	for (int i=0; i < batchList.size(); i++) {
		   		Entry entryBatch = batchList.get(i);
		   		totalCount +=entryBatch.numEntry;
		   		//sb.append(entryBatch.extract(HTMLOutput.TAG.TABLE));
		   		
		   	}
		   		
		   		
		   		
		
		}
		return sb.toString();
	}
	
  
	public int compare(Batch _pointer) {
		if (_pointer ==null) {
			return -1;
		} else {
		return (_pointer.index - endIndex) ;
		}
		 
	}
	
	public String toStringHTML() {
		return "\nGroup number:" + groupNumber+":\n"+summaryHTML+':'+ modulo;
				
	}
	public void setModulo(int _value) {
		modulo = _value;		
		//allocateModulo();
		
	}
	private String getTD(String _body) {
		return "<td>"+_body+"</td>";
	}

	private String getModuloMaskXmlTD() {
         return getTD(getMaskXml());	 																						
	}
	private int getModulo(int _gr, int _mod) {
		switch (_gr) {
		
		case 0: return 1; 
		default: return _mod;
		}
	}
	
	public String getXmlSummaryTable(HTMLOutput.TAG _tag) throws KCMException  {
		StructureTR structTR1=new StructureTR(), structTR2 = new StructureTR(), structTR3 = new StructureTR(),
				structR4 = new StructureTR();
		StructureTR structTRA = new StructureTR(), structTRB = new StructureTR(), structTRC= new StructureTR(),
				structTRD = new StructureTR(), structTRE= new StructureTR();
		StructureTD  structTD1=new StructureTD(), structTD2 = new StructureTD(), structTD3= new StructureTD(), 
				structTD4 = new StructureTD();
		StructureTable structTable= new StructureTable();
		StringBuffer sb = new StringBuffer(1028);
		String stringBgPink = "#f08080", stringSent = "#5E856E", stringFiltered ="#DF526E", stringSendingStatus=null, stringHeadRow="#ABA698";
		if (_tag== HTMLOutput.TAG.TABLE) {			
			structTRB.attachColor(stringHeadRow);
			structTD1.attachColor(stringHeadRow);
			structTRB.push(structTD2=new StructureTD("Group number:"+ groupNumber));			
			structTD2.attachColor(stringHeadRow);
			structTD1.push(structTD2=new StructureTD("Modulo:"+ modulo));
			structTD2.attachColor(stringHeadRow);
			structTD1.push(structTD2=new StructureTD("Mask:"+ getMaskXml()));
			structTD2.attachColor(stringHeadRow);
			structTRB.push(structTD1);
								
			
			
			structTD1.attachColor(stringHeadRow);
			
						
			
		
			
			structTRA.attachColor("#855C60");
			structTRA.push(structTRB);
			
			StructureTR headFiller = new StructureTR("   ");
			headFiller.attachColor(stringHeadRow);
			
			structTRA.push(headFiller);
			structTRA.push(headFiller);
			
			//structTRB.push(structTD2);
			
			
            structTable.push(structTRA);
            //structTable.push(structTRB);		  
          
            
		  
		} else if (_tag== HTMLOutput.TAG.RAW) {
		  sb.append("\nGroup number:"+groupNumber+":"+ getMaskXml());
		  return sb.toString();
		}
		
		int runningCount=0;		
		
		
		for (int i=0; i < batchList.size() ; i++) {
			int batchNumber = i + startIndex;
			Entry eTag = batchList.get(i);
			
			runningCount += eTag.numEntry;
			
			StructureTR sHeader = new StructureTR();
			
			StructureTD structureGroupStatus = null;
			
			if (bSendStatus(batchNumber)) {
				stringSendingStatus = stringSent;
				
			} else {
				stringSendingStatus = stringFiltered;
			}
			
			sHeader.push(structureGroupStatus=new StructureTD("Group running count:"+ runningCount));
			structureGroupStatus.attachColor(stringSendingStatus);
			
			sHeader.push(structureGroupStatus=new StructureTD("Batch number:"+batchNumber));
			structureGroupStatus.attachColor(stringSendingStatus);
			sHeader.push(structureGroupStatus=new StructureTD("Send status:"+getSendStatus(batchNumber)));
			structureGroupStatus.attachColor(stringSendingStatus);
			sHeader.attachColor(stringBgPink);
			structTR1=new StructureTR(eTag.extract(HTMLOutput.TAG.TABLE));
			
			  if (bSendStatus(batchNumber)) {
					structTR1.attachColor(stringSendingStatus);
					sHeader.attachColor(stringSendingStatus);

				  
					
				} else {
					structTR1.attachColor(stringSendingStatus);
					  sHeader.attachColor(stringSendingStatus);
					  
					  
					
				}
			sHeader.push( structTR1);
            
            
            
          

            //structTable.push(structTRE);
			structTable.push(sHeader);
			
			
			
		}
		
		String result2=  structTable.snapShot();
		System.out.println("\n"+result2);
		return result2;
	}
	public boolean bGroup(int _runningIndex) {
	
		return _runningIndex >= startIndex && _runningIndex < endIndex;
	}

	private char getChar(boolean _bHit) {
		if (_bHit) {
			return 'O';
		} else {
			return '0';
		}
	}
	public String getMaskXml() {
		
		char charArray[]= allocateZeroChar(groupNumber+1);
		if (groupNumber==0) {
		charArray[0]='O';
		} else {
			charArray[modulo]='X';
		}
		return new String(charArray);
		
//		return summaryHTML;
	}
	public String getMaskKey() {
		char charArray[]= allocateZeroChar(groupNumber+1);
		if (groupNumber==0) {
		charArray[0]='|';
		} else {
			charArray[modulo]='|';
		}
		return new String(charArray);
	}
	public String getMaskKey(int _index) {
		int moduloValue = _index%(groupNumber+1);
		char charArray[]= allocateZeroChar(groupNumber+1);
		if (groupNumber==0) {
		charArray[0]='|';
		} else {
			charArray[moduloValue]='|';
		}
		return new String(charArray);
	}
	
	
	
	public String getSendStatus(int _index) {
		int moduloValue = _index%(groupNumber+1);
		//char charArray[]= allocateZeroChar(groupNumber);
		if (groupNumber == 0) {
			return "Sent";
		} else if (groupNumber == 3 && _index >= (startIndex+ (batchList.size() -4 ))) {
			return "Sent";
		} else  if (moduloValue == modulo) {
			return "Sent";
		} else return "Filtered";
		
	}
	public boolean bSendStatus(int _index) {
		int moduloValue = _index%(groupNumber+1);
		if (groupNumber == 0) {
			return true;
		}else if (groupNumber ==3 && _index >=startIndex+ (batchList.size() -4)) {
			
			return true;
    	} else {
    		return moduloValue == modulo; 
	}
	}
		
	private char[] allocateZeroChar(int _length) {
		char charArray[]=null;
		charArray = new char[_length];
		for (int i=0; i < charArray.length; i++) {
			charArray[i]='O';
		}
		
		return charArray;
	}
	
	public String getModulo(int _runningIndex) {
		StringBuffer sb = new StringBuffer();
		sb.append("Group number:"+groupNumber);
		char charArray []=null;
		if (groupNumber ==0) {
			return "Always X for Group 1";
		} else if (groupNumber >= 1 && groupNumber <=3) {
			int moduloCompute= _runningIndex % (groupNumber+1);
             charArray = allocateZeroChar(groupNumber+1);             
	       charArray[moduloCompute]='O';
	       return new String(charArray).toString();
		
	}
		return "<>";
	}
}


	
package emailsender.gui;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ComboBoxModel;
import javax.swing.JLabel;
import javax.swing.event.ListDataListener;

import org.w3c.dom.Node;

import emailsender.KCMException;
import emailsender.KCMObject;
import emailsender.PathUtil;
import emailsender.gui.Entry.EntryType;
import emailsender.html.HTMLOutput;
import emailsender.html.TEXTOutput;

public class GroupModel implements ComboBoxModel  {
	public enum GROUP_TYPE {HTML, TEXT};
	public ArrayList<Batch> list = null;
	public static final int MAXIMUM_BATCH=10;
	public   ArrayList<EmailBatch> listEmail = new ArrayList<EmailBatch>();
	public EmailBatch emailBatch =null;
	
	public GroupModel() {
	
		listEmail.add(new EmailBatch(0, 0, 30));
		listEmail.add(new EmailBatch(1, 30, 45));
		listEmail.add(new EmailBatch(2, 45, 50));
		listEmail.add(new EmailBatch(3, 50, 1000));
		StringBuffer sb = new StringBuffer();
	//	listEmail.forEach(child->sb.append("\n<p>"+child.toStringHTML()+"</p>"));
	
	}
	public GroupModel(int _index) {
		list = new ArrayList<Batch>(MAXIMUM_BATCH);
		for (int i=0; i < listEmail.size(); i++) {
			EmailBatch eb = listEmail.get(i);
			if (_index >= eb.startIndex && _index < eb.endIndex) {
				emailBatch = eb;
			}
		}
		
	}
	
	public  EmailBatch getEmailBatch(int _index) {
		for (int i=0; i < listEmail.size(); i++) {
			EmailBatch eb = listEmail.get(i);
			if (_index >= eb.startIndex && _index < eb.endIndex) {				
				return eb;
			}
			
		}
		return null;
	}
	 
 
    
	public void setPathUtil(PathUtil _pathUtil) {
		synchronized (listEmail) {
			EmailBatch eg1 = listEmail.get(0);
			eg1.setModulo(1);
			for (int i=1; i < listEmail.size(); i++) {
				Node  n=_pathUtil.nodesModulo.item(i);
				EmailBatch eg = listEmail.get(i);
				eg.setModulo(Integer.parseInt(n.getNodeValue()));
			
			}
	
		}
	}
	public void printSummaryBody(HTMLOutput _h)  throws KCMException {
		StringBuffer sb = new StringBuffer(1028);
		sb.append("<tr><td colspan='3'>Summary of Modulo mask descriptor for this instance of email send.</td></tr>");
		//sb.append(em)
		int totalCount=0;
		for (int i=0; i < listEmail.size(); i++ ) {
			EmailBatch eb = listEmail.get(i);			
			totalCount +=eb.getNumEntry();	
			sb.append(eb.extract(HTMLOutput.TAG.TABLE));
			sb.append(eb.getXmlSummaryTable(HTMLOutput.TAG.TABLE));		
			}
		sb.append("<tr bgcolor='#b4bfe0'>"+HTMLOutput.getTD("Total handle:"+totalCount)+ "</tr>");			
        String resultSummary = sb.toString();
		_h.attachRaw(resultSummary);
		
		
	}
	
	public void print(TEXTOutput _tO) {		
		_tO.setText(Batch.getBatchInfo(GroupModel.GROUP_TYPE.TEXT));
	}
	public  void copyToClipboard(String _body) {
		StringSelection stringSelection = new StringSelection(_body);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, null);
	}
	public String getModuloXmlSummary(HTMLOutput.TAG _tag) throws KCMException {		
		StringBuffer sb =new StringBuffer(1028);
		if (_tag == HTMLOutput.TAG.TABLE) {
		sb.append("<table><tr><td>Group number</td><td>Modulo</td>");
		sb.append("<tr><td>");
		sb.append("</td></tr>");
				} else if (_tag  == HTMLOutput.TAG.RAW) {
		sb.append("Email Instance Descriptor");
		}
		for (int i=0; i < listEmail.size(); i++ ) {
			EmailBatch eg = listEmail.get(i);
			sb.append(eg.getXmlSummaryTable(_tag));		
			}
		if (_tag == HTMLOutput.TAG.TABLE) 		sb.append("</tr></table>");
		
		return sb.toString();
	}

     int runningIndex=0;
    public  int  getIndex() {
    	return runningIndex;
    }
    public void resetIndex() {
    	runningIndex=0;
    }
    public Entry allocateEntry(EntryType _type, KCMObject _kcm, int _runningCount ) throws KCMException {
    	
    	for (int i=0;  i < listEmail.size(); i++) {
    		EmailBatch eb = listEmail.get(i);
    		if (eb.bGroup(_runningCount)) {
    			
    		return	eb.allocateEntry(_type,_kcm, _runningCount);
    		}
    	}
    	return null;

    }
    public Iterator getIterator() {
    	return listEmail.iterator();
    }
    public  void addEntry(Entry _entry) throws KCMException {
    	if (_entry==null) {
    		throw new KCMException("Cannot add empty entry.");
    	}
    	runningIndex+=_entry.index;
    	for (int i=0;  i < listEmail.size(); i++ ) {
    		EmailBatch eb = (EmailBatch)listEmail.get(i);
    		
    		if ( eb.bGroup(runningIndex)) {
    			//eb.addEntry(_entry);
    		}
    		
    		
    	}
    }
    /*
    public Entry extractEntry() {
    	Entry entryGroup = new Entry(EntryType.GROUP);
    	for (int i=0; i < listEmail.size(); i++) {   		    		
    		EmailBatch eb = listEmail.get(i);
    		Entry entryEmailGroup = new Entry( eb);
    		for (int j=0; j < eb.batchList.size(); j++) {
   // 			Batch batch= eb.batchList.get(j);
    //			eb.groupNumber= i;
    			
    			//entryEmailGroup.add(new Entry(eb));
    			
    			//entryGroup.add(new Entry(batch));
    			
    		
    	 entryGroup.add(entryEmailGroup);
    		}
    	

    
    }
    	return entryGroup;
    }
    */
	public   String getMaskKey(int _index) {
		
		StringBuffer sb = new StringBuffer(1028);
		for (int i=0; i < listEmail.size(); i++) {
			EmailBatch eg = listEmail.get(i);
			if (eg.bGroup(_index)) {
				
				sb.append(" : "+eg.getMaskXml() + " : "+ eg.getMaskKey(_index) + " : "+ eg.getSendStatus(_index));
			}
		}
        return sb.toString();
		
	}
	public   String getMaskKey(int _groupId, int _index) {
		if ((_groupId - 1) < 0) {
			return " ";
		}
		EmailBatch eg = (EmailBatch)listEmail.get(_groupId-1);
		return eg.getMaskKey(_index);
		
	}
	public boolean bSendStatus(int _groupId, int _index) {
		EmailBatch eg = (EmailBatch)listEmail.get(_groupId);
		return eg.bSendStatus(_index);
		
	}
	public  String getSendStatus(int _groupId, int _index) {
		EmailBatch eg = (EmailBatch)listEmail.get(_groupId);
		return eg.getSendStatus(_index);
	}

	public   int getGroup(int _batchIndex) {
		for (int i=0;  i < listEmail.size(); i++ ) {
    		EmailBatch eb = (EmailBatch)listEmail.get(i);
    		
    		if (eb.bGroup(_batchIndex)) {
    	           return eb.groupNumber;
    		}
    	}
		return 0;
	}
    public   String getModulo(int _runningIndex) {
    	StringBuffer sb = new StringBuffer();
    	for (int i=0;  i < listEmail.size(); i++ ) {
    		EmailBatch eg = (EmailBatch)listEmail.get(i);
    		
    		if (eg.bGroup(_runningIndex)) {
    		return eg.getModulo(_runningIndex);
    		}
    	}
    	return "XXXX";
    }
    public  boolean bModulo(int _runningIndex) {
    	for (int i=0;  i < listEmail.size(); i++ ) {
    		EmailBatch eg = (EmailBatch)listEmail.get(i);
    		
    		if ( eg.bGroup(_runningIndex)) return true;
    		
    		
    	}
    	return false;
    }


    
	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return listEmail.size();
	}

	@Override
	public Object getElementAt(int index) {
		// TODO Auto-generated method stub
		EmailBatch eg = listEmail.get(index);
		return eg.label;
		//return null;
	}

	@Override
	public void addListDataListener(ListDataListener l) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeListDataListener(ListDataListener l) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setSelectedItem(Object anItem) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getSelectedItem() {
		// TODO Auto-generated method stub
		return null;
	}

}

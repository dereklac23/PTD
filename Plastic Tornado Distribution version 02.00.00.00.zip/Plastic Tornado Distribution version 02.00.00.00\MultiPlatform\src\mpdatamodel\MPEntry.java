package mpdatamodel;
import multiplatform.*;
import emailsender.core.DirectoryObject;


import emailsender.html.*;

import java.awt.Color;
import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Vector;

import mpdatamodel.MPObject;
import emailsender.tools.PNotesKCMException;
import konagui.PNClickRename;

public class MPEntry {
    MPEntry father;
    MPEntry  mother;
    public ArrayList<MPEntry> children;
    private String name;
    public  File file=null, directory=null;
    public String body=null;
    public String value=null;
    public int index=0, numEntry=0;
    public String line=null;

    public StringBuffer bufferBody=null;
   
    public ArrayList<String> pathList = null;
    public File root=null;
    public String header=null;
    public MPGroupModel groupModel=null;
    public MPEmailBatch emailBatchPointer=null;
    public MPEntry batch=null;
    public MPObject kcmObject=null;
    
    

    public enum EntryType {ROOT,GROUP,EMAIL_BATCH,BATCH,KCM, TAG, FACEBOOK_LINK, CORE, BASIC};
    public enum EntrySubType {HEADER, UNIQUE_ID,  ITERATION};
    public EntryType type = EntryType.GROUP;
    public DirectoryObject directoryObject=null;
    public ArrayList <MPEntry> entryList=null;
    //public int batchNumber=0;
    public ArrayList<MPBatch> batchList = null;
   
    public String tag=null;
   
    
    
    public MPEntry(MPObject _kcmO, int _runningIndex) {
    	type = EntryType.TAG;
    	kcmObject = _kcmO;
    	index = _runningIndex;
    	
    }
    public MPEntry(MPEmailBatch _batchPointer,MPObject _kcm, 
    		int _runningIndex) {
      type = EntryType.TAG;
      emailBatchPointer = _batchPointer;
      kcmObject = _kcm;
      index  = _runningIndex;
      
//      numEntry = kcmObject.entryList.size();
   
    }
    public MPEntry(MPEntry _e, MPObject _kcm,int _index) {
    	type = EntryType.BATCH;
    	batch= _e;
    	index = _index;
    	kcmObject = _kcm;
    	
    }

    public MPEntry(MPEntry _batchEntry, int _runningIndex) {
      type = EntryType.BATCH;
      batch = _batchEntry;      
      index  = _runningIndex;      
//      
    }
    
    public MPEntry(EntryType _type, String _line) {
    	type = EntryType.TAG;
    	line = _line;
//    	numEntry = kcmObject.entryList.size();
    	//index = _runningCount;
    }
    
    
    public MPEntry(EntryType _type, String _line, DirectoryObject _dO) {
    	type =_type;
    	line = _line;
    	directoryObject = _dO;
    }
    
    
    /**
     * Main entry for tag
     */
   
    
    public MPEntry( MPEmailBatch _eb) {    	
    	emailBatchPointer = _eb;
    	children = new ArrayList<MPEntry>();
    	for (int i=0; i < emailBatchPointer.batchList.size(); i++) {
    		MPEntry entryBatch = emailBatchPointer.batchList.get(i);
    	   	MPEntry eBatch = new MPEntry(entryBatch,  _eb.startIndex + i);
    	   	children.add(eBatch);
    	}
 
    }
    
    
    public MPEntry (EntryType _type,MPObject _kcmO) {
    type = _type;    
    bufferBody= _kcmO.bodyBuffer;
    }

    public MPEntry (EntryType _type, StringBuffer _sb) {
    	type = _type;
    	bufferBody = _sb;
    	
    }
   
    
    public MPEmailBatch emailGroup=null;
  
    
    public MPEntry(String _title, MPGroupModel _gM) {
    
     type = EntryType.ROOT;
     name = _title;
     groupModel = _gM;
     
    }
    
   public String extract(MPHtmlOutputPane.TAG _tagType) throws PNotesKCMException {
	   //StructureTable st  = new StructureTable();
	   
	   StringBuffer sb = new StringBuffer();
	   StructureTR structTR= new StructureTR();
	   StructureTD structTD= new StructureTD();
	   

	   if (type == EntryType.GROUP && emailBatchPointer==null) {
		   structTD.push("Empty batch");
		   structTR.push(structTD);		   
		
	   }
	   if (type == EntryType.GROUP) {
		   //st.push(structTR.pullStructure());
		   //structTable.push(structTR);
		   if (_tagType == MPHtmlOutputPane.TAG.TABLE) {
			   structTD.push(emailBatchPointer.extract(_tagType));		   
			   structTR.push(structTD);

			   //st.push(structTR);
			   //return st.pullBody();
		   }
			   
	
      } else if (type == EntryType.BATCH && _tagType == MPHtmlOutputPane.TAG.TABLE) {
    	  if (kcmObject == null ) {
    		  throw new PNotesKCMException ("Batch has emty tags entry.");
    	  }
    	  
    	  
    	  
      } else if (type == EntryType.EMAIL_BATCH) {
    	  
    	  if (_tagType == MPHtmlOutputPane.TAG.TABLE) {
    		  structTD.push("Empty batch");
   		    
   		      
    		  
    		  if (children !=null) {
    			  
    		  for (int i=0; i < children.size(); i++) {
    			  MPEntry eBatch= children.get(i);
    			  structTD.push(eBatch.body);
    				   
    			  
    		  }
    		  
    		  }
    		  structTR.push(structTD);
			  structTR.attach(Color.red);
    		
    	  }
      } else if (type == EntryType.BASIC || type == EntryType.CORE) {
    	  structTD.push("Empty batch");
		  structTR.push(structTD);
    	  
    	  
      } else if (type == EntryType.TAG) {
    	  /*
    	  if (_tagType == MPHtmlOutput.TAG.TABLE) {
    		  int runningIndex =0, totalCount=0;
    		  for (int i=0; i < kcmObject.entryList.size(); i++) {
    			  runningIndex = index + i;
    			  MPEntry e = kcmObject.entryList.get(i);
    			  if (e.line !=null) {
    				 structTD.push(e.line);
    				 //sb.append(e.line);
    				 
    			  }
    		  }
    		*/  
    		  
	
    	  } else if (_tagType == MPHtmlOutputPane.TAG.RAW) {
    	  /*
    	  structTR.push(structTD.pull());
		  structTR.attach(Color.green);
		  structTR.attach("raw line");
		  */
    	  structTD.snapShot();
      }
	   if (_tagType == MPHtmlOutputPane.TAG.TABLE) {
		//   structTR.push(structTD);
		  // return structTR.snapShot();
	   }
	   
	   return sb.toString();
	   
   }
    
    public void print (PNotesHTMLOutput _htmlO, MPEntry _entryChild) throws MPException  {
    	 PNClickRename clickRename = new PNClickRename(_htmlO, "Save");
    	 
    	if (type == EntryType.ROOT ) {
    		_htmlO.attachHeader();
    		_htmlO.attachP("root:");
    		_htmlO.attachRaw("<table>");
    		_htmlO.attachRaw("<tr><td>Start of table</td></tr>");
    		 //groupModel.printSummaryBody(_htmlO);    		
    		

    		_htmlO.attachRaw("</table>");

    		 
    		clickRename.printLink();    		
    		_htmlO.attachEnder();
    		
    		_htmlO.printPage();
    		groupModel.copyToClipboard(_htmlO.getPageBuffer());
    		
    		
    		
    	} else if (type == EntryType.GROUP) {
    		_htmlO.attachHeader();
    		if (children !=null) {
    		_htmlO.attachP("Group:"+ emailBatchPointer.startIndex+":"+emailBatchPointer.startIndex+emailBatchPointer.batchList.size());
    		} else if (emailBatchPointer !=null) {
    		   //_htmlO.attachP("Group embatchpointer:" + emailBatchPointer.extract(MPHtmlOutput.TAG.TABLE));
    		}
    		_htmlO.attachEnder();
    		_htmlO.printPage();    		
    		
    		
    	} else if (type == EntryType.EMAIL_BATCH) {
    		_htmlO.attachHeader();
    		_htmlO.attachP("Info");
    		_htmlO.attachP("Email batch"+ index);
    		_htmlO.attachRaw("<table>");
    		StringBuffer sb = new StringBuffer();
    		if (children ==null) {
    			//throw new PNotesKCMException ("EmailBatch has empty batch entries of type BATCH");
    		}
    		for (int i=0; i < children.size(); i++) {
    			MPEntry entry = children.get(i);
    		    sb.append("<tr bgcolor='green'>");
    		    //entry.extract(MPHtmlOutput.TAG.TABLE);
    		    sb.append("</tr>");
    		}
    		_htmlO.attachRaw("</table>");
    		_htmlO.attachEnder();
    		_htmlO.printPage();
    	} else if (type == EntryType.BATCH ) {
    		
    		_htmlO.attachHeader();
    		/*
    		for (int i=0; i < batch.kcmObject.entryList.size();i++) {
    			MPEntry eTag = batch.kcmObject.entryList.get(i);
    			_htmlO.attachP(eTag.line);
    		}
    		*/
    		
    		_htmlO.attachEnder();
    		_htmlO.printPage();
    		
    	} else if (type == EntryType.FACEBOOK_LINK) {
    		
    		_htmlO.attachHeader();
    		_htmlO.attachP(bufferBody.toString());
    		_htmlO.attachEnder();
    		_htmlO.printPage();
    		
    	} else if (type == EntryType.BASIC || type == EntryType.CORE) {
            _htmlO.attachHeader();
             _htmlO.attachHeader();
    		_htmlO.attachP(line);
    		_htmlO.attachEnder();
    		_htmlO.printPage();

    	
    	} else if (type == EntryType.TAG) {
    		_htmlO.attachHeader();
    		_htmlO.attachP(line);
    		_htmlO.attachEnder();
    		_htmlO.printPage();
    	}
    	//System.out.println("\n end of group:"+ type);
    }

    /**
    *   Link together all members of a family.
    *
    *   @param pa the father
    *   @param ma the mother
    *   @param kids the children
    */
    public static void linkFamily(MPEntry pa,
                                  MPEntry ma,
                                  MPEntry[] kids) {
        for (MPEntry kid : kids) {
            pa.children.add(kid);
            ma.children.add(kid);
            kid.father = pa;
            kid.mother = ma;
        }
    }
    public static void linkFamily(MPEntry ma,
            MPEntry[] kids) {
    	for (MPEntry kid : kids) {    		
    		ma.children.add(kid);    		
    		kid.mother = ma;
        }
}
    
    public static void linkFamily(MPEntry ma,
    		 MPEntry kid) {
    	ma.children.add(kid);
    	kid.mother= ma;
    }
    
    

/// getter methods ///////////////////////////////////

    public String toString() {

    	  if (type== EntryType.BATCH) {
    			  return "Batch:"+ index;
    	  } else if (type == EntryType.FACEBOOK_LINK) {    		  
    		  return "Facebook:"+bufferBody.toString().substring(0, 10);
    	  } else if (type == EntryType.CORE || type == EntryType.BASIC) {
    		  return "X TAg:"+ line;
    	  } else if (type == EntryType.GROUP) {
    		  return "I:<"+emailBatchPointer.startIndex+":"+ (emailBatchPointer.startIndex + emailBatchPointer.batchList.size())+">";
    				  
    		  
    	  } else if (type == EntryType.TAG) {
    		  return "Tag: "+line;
    	  } else if (type == EntryType.ROOT) {
    		  return "Root: "+name;
    		  
    	  }
    		
    	return "X Tag:"+ type;    		
    }
    	 
    	
    
    public MPEntry  getFather() { return father; }
    public MPEntry getMother() { return mother; }
    public int getChildCount() { 
    	if (children ==null) {
    		return 0;
    	}else return children.size(); }
    public MPEntry getChildAt(int i) {
        return (MPEntry)children.get(i);
    }
    public int getIndexOfChild(MPEntry kid) {
        return children.indexOf(kid);
    }
  
}

package emailsender.gui;

import javax.swing.tree.DefaultTreeCellRenderer;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

public class CustomTreeRenderer2 extends  DefaultTreeCellRenderer {
//	private HTMLOutput htmlOutput=null;

	    
    
	public Component getTreeCellRendererComponent(JTree tree, 
			Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        // Call the superclass method to get the default renderer component
		
	
        Component component = super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);
        Entry entry = (Entry)value;
        //if (entry)
        if (entry ==null && entry.emailGroup ==null) {
        	
        	return component;
        }  else if (selected) {
        component.setForeground(Color.black);
        } else if (leaf) {
        	component.setBackground(Color.pink);
        } else if (hasFocus) {
        	component.setBackground(Color.yellow);
        } else if (expanded) {
        	component.setBackground(Color.yellow);
        }
        component.setBackground(Color.pink);
        return component;
	}
}
	
	
        
            
    

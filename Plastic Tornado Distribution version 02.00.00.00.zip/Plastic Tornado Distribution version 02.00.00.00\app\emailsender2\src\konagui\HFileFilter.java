package konagui;

import java.io.File;
import java.io.FilenameFilter;

import javax.swing.filechooser.FileFilter;

public class HFileFilter extends FileFilter implements FilenameFilter {

	@Override
	public boolean accept(File dir, String name) {
		// TODO Auto-generated method stub
		return (dir.isFile());
		
	}

	@Override
	public boolean accept(File f) {
		
		return (f.isFile() && f.getName().endsWith(".html"));
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Only selected file to be saved as .html";
	}
	
	
}

	  
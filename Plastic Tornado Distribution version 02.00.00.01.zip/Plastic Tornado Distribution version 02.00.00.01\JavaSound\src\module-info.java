/**
 * 
 */
/**
 * 
 */
module JavaSound {
	requires java.desktop;
}
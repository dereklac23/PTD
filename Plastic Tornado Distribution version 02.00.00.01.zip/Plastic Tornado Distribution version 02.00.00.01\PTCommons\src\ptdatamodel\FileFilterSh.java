package ptdatamodel;


import java.io.*;
import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import pttools.KCMException;
import pttools.KCMObject;



/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/

public class FileFilterSh implements FilenameFilter {
	public enum FILE_T {RELEASE_NAMING, DIRECTORY, FILE}
	public enum SUB_T {BOOK, CHAPTER, PAGE}

	  private Hashtable filters = new Hashtable();
	  private String description = "unverified";
	  private String fullDescription = null;
	  
	  private FILE_T fileType= FILE_T.DIRECTORY;
	  private SUB_T  subType = SUB_T.BOOK;
	  
	  
	
	  public FileFilterSh(FILE_T _ft) {
		  if (_ft == FILE_T.RELEASE_NAMING) {
			  filters.put("zip", this);
		  } 
	  }
  
  public FileFilterSh(FILE_T _ft ,SUB_T subT) {
	  fileType = _ft;
	  subType =subT;
  }
  public FileFilterSh() {	
	       filters.put("sh", this);
	       filters.put("jar", this);
	       filters.put("xml", this);
	       filters.put("gz", this);
	       filters.put("bat", this);
	 }
  
  //public KCMObject fileObject=null;
  
  public KCMObject getKCMObject(File dir, String name) throws KCMException  {
	  KCMObject fileObject = new KCMObject(dir, name);
      if (fileObject.directoryPointer!=null) {
   	   System.out.println("\nGot a file Directory object as:"+fileObject.directoryPointer.getName());
   	   return fileObject;
      }
      return null;

	  
  }
  @Override
	public boolean accept(File dir, String name) {
	   try {
		 if (fileType == FILE_T.DIRECTORY && dir.isDirectory()) {
			 
			 File targetFile = new File(dir, name);
			 return targetFile.isDirectory();
		 }else 		 if (fileType == FILE_T.RELEASE_NAMING && dir!= null && name !=null) {
            KCMObject fileObject = new KCMObject(dir, name);		    	  
		    	  return fileObject.directoryObject.isKCM();       		       
		      
		      }
	   } catch (KCMException kcm) {
		   //System.err.println("\nkcm");
	   }
		 
	  
		 return false;
  
  }
  
  
	
	public String getName(String name) {
		  int i = name.lastIndexOf('.');
	      if (i > 0 && i < name.length() - 1) {
	        return name.substring(0,i);
	      }
	    
	    return null;
	}
	public String getExtension(String name) {
	      int i = name.lastIndexOf('.');
	      if (i > 0 && i < name.length() - 1) {
	        return name.substring(i + 1).toLowerCase();
	      }
	    
	    return null;
	  }

	
}


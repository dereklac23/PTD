package ptgui;

import java.awt.BorderLayout;
import java.awt.Dimension;


import javax.swing.JPanel;
import javax.swing.JTextArea;



public class MenuHtml extends JPanel {
    public HTMLOutput editorHtml=null;
    private String htmlIndexPage=null;
    public String description=null;
    
	public MenuHtml(HTMLOutput _editorHtml, String _description) {
		super();
		add(BorderLayout.NORTH, _editorHtml);
		description=_description;
		editorHtml = _editorHtml;
		editorHtml.setContentType("text/html");
		editorHtml.setPreferredSize(new Dimension(500,550));
		editorHtml.attachHeader();		
		editorHtml.attachP(description);
		editorHtml.attachEnder();
		editorHtml.printPage();
		
		
	}  

}

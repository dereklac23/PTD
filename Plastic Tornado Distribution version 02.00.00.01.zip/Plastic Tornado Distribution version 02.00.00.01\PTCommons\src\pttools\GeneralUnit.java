package pttools;

import java.io.File;
import java.nio.file.Path;

public interface GeneralUnit {



}

package mpdatamodel;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ComboBoxModel;
import javax.swing.JLabel;
import javax.swing.event.ListDataListener;

import org.w3c.dom.Node;

import emailsender.core.PNotesKCMObject;
import emailsender.gui.Batch;
import emailsender.gui.EmailBatch;
import emailsender.gui.Entry;
import emailsender.gui.Entry.EntryType;
import emailsender.html.PNotesHTMLOutput;
import emailsender.html.PNotesTEXTOutput;
import emailsender.tools.PNotesKCMException;
import emailsender.tools.PNotesPathUtil;
import multiplatform.*;

public class MPGroupModel implements ComboBoxModel  {
	public enum GROUP_TYPE {HTML, TEXT};
	public ArrayList<Batch> list = null;
	public static final int MAXIMUM_BATCH=10;
	public   ArrayList<MPEmailBatch> listEmail = new ArrayList<MPEmailBatch>();
	public MPEmailBatch emailBatch =null;
	
	public MPGroupModel() {
	
		listEmail.add(new MPEmailBatch(0, 0, 35));
		listEmail.add(new MPEmailBatch(1, 35, 45)); 
		listEmail.add(new MPEmailBatch(2, 45, 50));
		listEmail.add(new MPEmailBatch(3, 50, 1000));
		StringBuffer sb = new StringBuffer();
	//	listEmail.forEach(child->sb.append("\n<p>"+child.toStringHTML()+"</p>"));
	
	}
	public MPGroupModel(int _index) {
		list = new ArrayList<Batch>(MAXIMUM_BATCH);
		for (int i=0; i < listEmail.size(); i++) {
			MPEmailBatch eb = listEmail.get(i);
			if (_index >= eb.startIndex && _index < eb.endIndex) {
				emailBatch = eb;
			}
		}
		
	}
	
	public  MPEmailBatch getEmailBatch(int _index) {
		for (int i=0; i < listEmail.size(); i++) {
			MPEmailBatch eb = listEmail.get(i);
			if (_index >= eb.startIndex && _index < eb.endIndex) {				
				return eb;
			}
			
		}
		return null;
	}
	 
 
    
	public void setPathUtil(PNotesPathUtil _pathUtil) throws PNotesKCMException {
		if (_pathUtil.nodesModulo ==null) {
			throw new PNotesKCMException ("The data files located data/x are missing");
		}
		System.out.println("\nSize of modulo node:"+_pathUtil.nodesModulo.getLength());
		synchronized (listEmail) {
			MPEmailBatch eg1 = listEmail.get(0);
			eg1.setModulo(1);
			for (int i=1; i < listEmail.size(); i++) {
				Node  n=_pathUtil.nodesModulo.item(i);
				MPEmailBatch eg = listEmail.get(i);
				eg.setModulo(Integer.parseInt(n.getNodeValue()));
			
			}
	
		}
	}
	public void printSummaryBody(MPHtmlOutputPane _h)  throws PNotesKCMException {
		StringBuffer sb = new StringBuffer(1028);
		sb.append("<tr><td colspan='3'>Summary of Modulo mask descriptor for this instance of email send.</td></tr>");
		//sb.append(em)
		int totalCount=0;
		for (int i=0; i < listEmail.size(); i++ ) {
			MPEmailBatch eb = listEmail.get(i);			
			totalCount +=eb.getNumEntry();	
			sb.append(eb.extract(MPHtmlOutputPane.TAG.TABLE));
			sb.append(eb.getXmlSummaryTable(MPHtmlOutputPane.TAG.TABLE));		
			}
		sb.append("<tr bgcolor='#b4bfe0'>"+PNotesHTMLOutput.getTD("Total handle:"+totalCount)+ "</tr>");			
        String resultSummary = sb.toString();
		_h.attachRaw(resultSummary);
		
		
	}
	
	public void print(PNotesTEXTOutput _tO) {		
		_tO.setText(MPBatch.getBatchInfo(MPGroupModel.GROUP_TYPE.TEXT));
	}
	public  void copyToClipboard(String _body) {
		StringSelection stringSelection = new StringSelection(_body);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, null);
	}
	public String getModuloXmlSummary(MPHtmlOutputPane.TAG _tag) throws PNotesKCMException {		
		StringBuffer sb =new StringBuffer(1028);
		if (_tag == MPHtmlOutputPane.TAG.TABLE) {
		sb.append("<table><tr><td>Group number</td><td>Modulo</td>");
		sb.append("<tr><td>");
		sb.append("</td></tr>");
				} else if (_tag  == MPHtmlOutputPane.TAG.RAW) {
		sb.append("Email Instance Descriptor");
		}
		for (int i=0; i < listEmail.size(); i++ ) {
			MPEmailBatch eg = listEmail.get(i);
			sb.append(eg.getXmlSummaryTable(_tag));		
			}
		if (_tag == MPHtmlOutputPane.TAG.TABLE) 		sb.append("</tr></table>");
		
		return sb.toString();
	}

     int runningIndex=0;
    public  int  getIndex() {
    	return runningIndex;
    }
    public void resetIndex() {
    	runningIndex=0;
    }
    public MPEntry allocateEntry(MPEntry _type, MPObject _kcm, int _runningCount ) throws MPException {
    	
    	for (int i=0;  i < listEmail.size(); i++) {
    		MPEmailBatch eb = listEmail.get(i);
    		if (eb.bGroup(_runningCount)) {
    			
    		return	eb.allocateEntry(_type,_kcm, _runningCount);
    		}
    	}
    	return null;

    }
    public Iterator getIterator() {
    	return listEmail.iterator();
    }
    public  void addEntry(Entry _entry) throws MPException {
    	if (_entry==null) {
    		throw new MPException("Cannot add empty entry.");
    	}
    	runningIndex+=_entry.index;
    	for (int i=0;  i < listEmail.size(); i++ ) {
    		MPEmailBatch eb = (MPEmailBatch)listEmail.get(i);
    		
    		if ( eb.bGroup(runningIndex)) {
    			//eb.addEntry(_entry);
    		}
    		
    		
    	}
    }
 
	public   String getMaskKey(int _index) {
		
		StringBuffer sb = new StringBuffer(1028);
		for (int i=0; i < listEmail.size(); i++) {
			MPEmailBatch eg = listEmail.get(i);
			if (eg.bGroup(_index)) {
				
				sb.append(" : "+eg.getMaskXml() + " : "+ eg.getMaskKey(_index) + " : "+ eg.getSendStatus(_index));
			}
		}
        return sb.toString();
		
	}
	public   String getMaskKey(int _groupId, int _index) {
		if ((_groupId - 1) < 0) {
			return " ";
		}
		MPEmailBatch eg = (MPEmailBatch)listEmail.get(_groupId-1);
		return eg.getMaskKey(_index);
		
	}
	public boolean bSendStatus(int _groupId, int _index) {
		MPEmailBatch eg = (MPEmailBatch)listEmail.get(_groupId);
		return eg.bSendStatus(_index);
		
	}
	public  String getSendStatus(int _groupId, int _index) {
		MPEmailBatch eg = (MPEmailBatch)listEmail.get(_groupId);
		return eg.getSendStatus(_index);
	}

	public   int getGroup(int _batchIndex) {
		for (int i=0;  i < listEmail.size(); i++ ) {
    		MPEmailBatch eb = (MPEmailBatch)listEmail.get(i);
    		
    		if (eb.bGroup(_batchIndex)) {
    	           return eb.groupNumber;
    		}
    	}
		return 0;
	}
    public   String getModulo(int _runningIndex) {
    	StringBuffer sb = new StringBuffer();
    	for (int i=0;  i < listEmail.size(); i++ ) {
    		MPEmailBatch eg = (MPEmailBatch)listEmail.get(i);
    		
    		if (eg.bGroup(_runningIndex)) {
    		return eg.getModulo(_runningIndex);
    		}
    	}
    	return "XXXX";
    }
    public  boolean bModulo(int _runningIndex) {
    	for (int i=0;  i < listEmail.size(); i++ ) {
    		MPEmailBatch eg = (MPEmailBatch)listEmail.get(i);
    		
    		if ( eg.bGroup(_runningIndex)) return true;
    		
    		
    	}
    	return false;
    }


    
	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return listEmail.size();
	}
   
	@Override
	public Object getElementAt(int index) {
		// TODO Auto-generated method stub
		MPEmailBatch eg = listEmail.get(index);
		return eg.label;
		//return null;
	}

	@Override
	public void addListDataListener(ListDataListener l) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeListDataListener(ListDataListener l) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setSelectedItem(Object anItem) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getSelectedItem() {
		// TODO Auto-generated method stub
		return null;
	}

}

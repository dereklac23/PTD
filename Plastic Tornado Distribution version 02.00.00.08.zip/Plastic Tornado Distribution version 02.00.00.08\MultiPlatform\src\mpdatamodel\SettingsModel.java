package mpdatamodel;


import java.io.File;
import java.net.URI;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.table.AbstractTableModel;

import pttools.PTCKCMException;
import pttools.PTCKCMObject;

//import emailsender.KCMObject;

public class SettingsModel extends AbstractTableModel {

	public URI uri=null;
	public enum TYPE {DEFAULT,PATH, URI};
	
	private JPanel panel=null;
	
    private String[] columnNames = {    		
    		"Name",
    		"Path", 
    		"Active",
    		};
   protected ArrayList<SettingsEntry> settingsCollection= new ArrayList<SettingsEntry>();
   
	 
   public List<SettingsEntry>syncCollection= (List<SettingsEntry>) Collections.synchronizedList(new ArrayList(settingsCollection));
	 
	 
   public SettingsModel(List<SettingsEntry> _settings) {	   
	   syncCollection = _settings;
   }
   private String header="data/x";
   private Timer timer=null;
   private MyTimerTask taskT=null;
   private void startTimer() {
	  timer = new Timer();
	  taskT = new MyTimerTask(this);
	  timer.schedule(taskT, 0, 500);
   }
      public SettingsModel(JPanel _p) {
    	SettingsEntry entryWorking=null;
	   syncCollection.add(entryWorking=new SettingsEntry("Workspace"));
	   syncCollection.add(new SettingsEntry("Sandbox"));
	   syncCollection.add(new SettingsEntry("URI"));
	   panel = _p;
	   
	   entryWorking.path = FileSystems.getDefault().getPath(header).toAbsolutePath();
	   PTCKCMObject kcmObject = new PTCKCMObject();
	   try {
	   kcmObject.createDOM(entryWorking.path.toUri().toString());
	   } catch (PTCKCMException ptce) {
		   System.err.println("ptce:"+ptce.toString());
	   }
	   System.out.println("settings model great!");
	   startTimer();
	   
   }
   private int tick=0;
   public boolean setBTick() {
	   tick++;
	   return (tick % 2) ==0;
   }
   public void clearTick() {
	   tick=0;
   }
  
   public int indexRowActive=0;
   public void latchRow(int _row) {
	   indexRowActive=_row;
	   for (SettingsEntry se: syncCollection) {
		   se.active=false;
	   }
	   SettingsEntry seActive = syncCollection.get(_row);
	   seActive.active=true;	   
   }
   
   
   public void latchPath() {
	    if (indexRowActive ==1 ) {
	     SettingsEntry se = syncCollection.get(1);
	     
         JFileChooser fileChooser =new JFileChooser();
         fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		 int returnVal = fileChooser.showOpenDialog(panel);
         if (returnVal == JFileChooser.APPROVE_OPTION) {
             FileSystem fs =FileSystems.getDefault();
          se.path=   fs.getPath(fileChooser.getSelectedFile().toString(), header);
         }           
             
         
             
	    }    
	   
   }
   public void tock() {
	   //setPath();
	   
   }
   
    public int getColumnCount() {
    	return SettingsEntry.length; 

    }
 
    public int getRowCount() {
      return syncCollection.size();

    }

    public String getColumnName(int col) {
    	return columnNames[col];
        
        
    }
    

public Object getValueAt(int row, int col) {
    	SettingsEntry se = syncCollection.get(row);
    	String val = se.get(col);  
    	
     	return val;
}


   
    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {	    
        return (col ==2);	        
    }

    public void setValueAt(Object value, int row, int column) {	        
        fireTableCellUpdated(row, column);
    }
    
    
    private class MyTimerTask extends TimerTask {
    	private SettingsModel settingsModel=null;
    	public MyTimerTask(SettingsModel _sm) {
    		settingsModel=_sm;
    	}

		@Override
		public void run() {
			// TODO Auto-generated method stub
			//System.out.print(".");
		settingsModel.fireTableDataChanged();
		
			
			
		}
    	
    }
}




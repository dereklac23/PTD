/**
 * 
 */
/**s
 * 
 */
module PTCommons {
	requires java.desktop;
	requires java.xml;
	
	exports ptgui;
	exports pttools;
	exports ptsets;
	exports ptdatamodel;
}
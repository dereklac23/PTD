package ptdatamodel;
import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import pttools.PTCKCMException;

public class DirectoryObject {
		public int version[] = new int[5];
		public String prefix=null;
		public File root=null, docRelease=null;
		  public HashMap <String, DirectoryObject> doMap = 
					new HashMap<String, DirectoryObject>();
		  public Map<String, DirectoryObject> eMap =  Collections.synchronizedMap(doMap);
		  public File fileDirectoryTarget=null;
		public DirectoryObject () {
			
		}
		public DirectoryObject(File _targetF) {
			fileDirectoryTarget=_targetF;
		}
		public DirectoryObject(String key, File tomcatDir) {
			eMap.put(key,  new DirectoryObject(tomcatDir));
		}
		public boolean isKCM() {
			return (prefix !=null) && (!prefix.endsWith(".zip"));
			
		}
		public DirectoryObject (String _prefix,Matcher matcher)  throws PTCKCMException {
			if (matcher ==null) {
				throw new PTCKCMException("\nRegex did not get any matches");
			}
			
			prefix = matcher.group(0);
			for (int i=1; i < version.length; i++) {
				version[i] = Integer.parseInt(matcher.group(i));				
			}
			prefix = _prefix;
		}
		public DirectoryObject(File _root,Pattern _pattern, String _name) throws PTCKCMException {
			  //File list [] = Files.list
			String targetString= _root+File.separator + _name;
			  Matcher matcher = _pattern.matcher(targetString);
			  		
				  

				  if (matcher.find()) {
                    
					  version = new int[matcher.groupCount()+1];
					  for (int i=1; i < version.length; i++) {
						  try {
					  version[i] = Integer.parseInt(matcher.group(i));
						  } catch (NumberFormatException nfe) {
							  
						  }
					  
					  
				  }
			 
		          	
		}
		}
		//public int versionIndexId=0;
		public DirectoryObject (File _root,String _prefix,Matcher matcher)  throws PTCKCMException {
			System.out.println("\nRoot:"+_root);
			System.out.println("\n>>prefix"+_prefix);
			if (matcher ==null) {
				throw new PTCKCMException("\nRegex did not get any matches for");
			}
			
			prefix = matcher.group(0);
			for (int i=1; i < version.length; i++) {
				version[i] = Integer.parseInt(matcher.group(i));
			
			}
			
			prefix = _prefix;
			root =_root;
			File  docDirectory= new File(root, "doc");
			docRelease = new File(docDirectory, "release");
		}

		private String pad(int value) {
			if (value < 10) {
				return "0"+value;
			} return Integer.valueOf(value).toString();
		}
		private boolean compare(int target, int runningInt) {
			return target >= runningInt;
		}
		public boolean compare(int runningID) {
			return (compare(getVersionInt(),runningID)) ;
		}
		public int getVersionInt() {
			if (version.length==1) {
				return version[0];
			} else if (version.length==5) {
			return version[1]*10000+ version[2]*1000+ version[3]*100+version[4];
			}
			return 0;
		}
		
		public String getVersionString(int _increment) {
            StringBuffer sb = new StringBuffer();
			int i=1;
			for (; i < version.length-1; i++) {
			sb.append(pad(version[i])+".");
    		}
			sb.append(pad(version[i]+1));

			return sb.toString();

			
		}
		public String getVersionString() {
			StringBuffer sb = new StringBuffer();
			
			for (int i=1; i < version.length; i++) {
			sb.append(pad(version[i]));
    		}

			return sb.toString();
     			
	}
}

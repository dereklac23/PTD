package releasetool;

import releasetool.gui.ButtonSelection;

public abstract interface SeafloorExec {
	
	public enum LEVEL { BASEMENT0, BASEMENT1, BASEMENT2, BASEMENT3}; 
    public enum TYPE { PROVISION, ASSEMBLE, PROPAGATE};
    public enum ATTR  {UPDATE_FILE_STRING, UPDATE_FILE_OBJECT, ENODE_ENTRY};
	
	public abstract void doExecute(LocalContainer _lc, LEVEL _level, TYPE _type, ATTR _attr);
	public abstract void doExecute( ATTR _attr, ButtonSelection.BSTypeSettings _bsSettings) throws KCMException ;
	public abstract void doExecute(ATTR _attr, LocalInfoUtil _infoUtil);
	public abstract void doExecute(ButtonSelection.BSTypeDistribution _typeD, LocalInfoUtil _liu);
	
} 

 
/**
 * 
 */
/**
 * 
 */
module EmailSender {
	requires java.desktop;
	exports emailsender.core;
	exports emailsender.gui;
	exports emailsender.tools;
	exports emailsender.html;
	exports konagui;
	
}
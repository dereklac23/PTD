package mpdatamodel;

public class MPException extends Exception {
    public String description=null;
	public MPException(String des) {
		description = des;
	}
	public String getString() {
		return description;
	}
	
}

package multiplatform;

import java.awt.Color;

public class MPHtmlOutputGenerator {
	private int WIDTH=0, HEIGHT=0;
	private Color bgColor=Color.DARK_GRAY;

	public MPHtmlOutputGenerator() {
		
	}
//	public 
}

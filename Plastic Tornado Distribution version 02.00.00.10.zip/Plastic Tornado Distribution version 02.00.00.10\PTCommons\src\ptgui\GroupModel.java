package ptgui;
import pttools.*;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.ComboBoxModel;
import javax.swing.JLabel;
import javax.swing.event.ListDataListener;

import org.w3c.dom.Node;

import ptgui.PTCKCMObject;

//import konagui.html.TEXTOutput;

public class GroupModel implements ComboBoxModel  {
	public enum GROUP_TYPE {HTML, TEXT};
	public static final int MAXIMUM_BATCH=10;
	
	public GroupModel() {
	
		StringBuffer sb = new StringBuffer();
	
	}
	public GroupModel(int _index) {
		
	}
	 
 
    
	
     int runningIndex=0;
    public  int  getIndex() {
    	return runningIndex;
    }
    public void resetIndex() {
    	runningIndex=0;
    }
    
	@Override
	public void addListDataListener(ListDataListener l) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeListDataListener(ListDataListener l) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setSelectedItem(Object anItem) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getSelectedItem() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public Object getElementAt(int index) {
		// TODO Auto-generated method stub
		return null;
	}

}

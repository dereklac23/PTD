package ptgui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;


public class KonaTabbedPane extends Panel {
    public JPanel panel=null;
    private ArrayList<TabbedItem> panelList = new ArrayList<TabbedItem>();
    private ArrayList<HCustomListener> actionList = new ArrayList<>();
	private JPanel outputPanel=null;
	public static JTabbedPane tabbedPanel=null;
//	public MenuHtml htmlOutput=null;
	//public MenuText textOutput=null;
	private int width=0, height=0;
	public KonaTabbedPane(int _width, int _height) {		
		width = _width;
		height = _height;
	   	tabbedPanel = new JTabbedPane();
	}
	public void allocate(String _title, int _keyEvent,MenuHtml _hO) {	
		panelList.add(new TabbedItem(_title,_keyEvent, _hO));
	}
	public void allocate(String _title, int _keyEvent,MenuText _jA) {	
		panelList.add(new TabbedItem(_title,_keyEvent, _jA));
	}
	public void allocate(HCustomListener _hListener) {
		actionList.add(_hListener);
	}
	public int getTabbedIndexHtml() {
		return 1;
		
	}
	public int getTabbedIndexText() {
		return 2;
	}
    public void execute( ) {
    	
    }
	public void freeze(JPanel _panel) {
		for (int i=0; i < panelList.size(); i++) {
			TabbedItem ti= panelList.get(i);
			tabbedPanel.add(ti.title,ti.panel);
		}
		_panel.add(tabbedPanel);
		
	}
	protected class TabbedItem {
		private int OFFSET=25;
		protected String title =null, description =null;	
		private int keyEvent=0;
		public JPanel panel=null;
		
		public TabbedItem(String _title, int _keyEvent, MenuHtml _hO) {
			title = _title;

			keyEvent = _keyEvent;			
			panel = new JPanel(false);
		    panel.setLayout(new GridLayout(1, 1));
		    panel.add(_hO);
		    panel.setPreferredSize(new Dimension(width,height));
		    
		    		
	    }
		public TabbedItem(String _title, int _keyEvent, MenuText _tOutput) {
			title = _title;
			keyEvent = _keyEvent;
			panel = new JPanel(false);
		    panel.setLayout(new GridLayout(1, 1));
		    panel.add(_tOutput);		    
		    _tOutput.setPreferredSize(new Dimension(width+25, height));
		    panel.setPreferredSize(new Dimension(width,height));
		    
		    		
	    }  

		
	}
}

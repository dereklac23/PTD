package ptgui;
import pttools.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.FileSystem;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import pttools.PTCKCMException;

public class PTCKCMObject {
    public File directoryPointer=null;
    
    private final static String  PREFIX="(BASIC|CORE|HEADER)", KMP="KMP.war", StarShip ="StarShip.jar", 
    		DEV_ROOT="c:\\users\\derek\\eclipse-workspace\\dist\\lib";
    private File fileKMP, fileKonaWare;
    private String header=null;
    public Path pathRoot= null;

    public PTCKCMObject targetDirectory=null;

	public BufferedReader bufferedReader = null;
	public String body=null;
	private final String context="context.xml";
	
	//public StringBuffer stringBuffer= new StringBuffer();

    public StringBuffer bodyBuffer =null;
    private void addEntryPlain(String _line) {
    	
    	bodyBuffer.append(_line);

    	
    }
    public boolean bDirectory=false;
    public int totalCount=0;
    
    public boolean bIsTag() {
    	return totalCount > 0;
    }
   
    public PTCKCMObject(Path _path) {
    	//path=_path;
    }
    public void initPath() throws PTCKCMException {
    	if (pathRoot ==null) throw new PTCKCMException("Internal object has empty path.");
    	
    	if (!Files.exists(pathRoot)) throw new PTCKCMException("Invalid permission for workspace.");
    	Path pathContext = Paths.get(context);
    	Path pathResolved  = pathRoot.resolve(pathContext);
    	if (!Files.exists(pathResolved)) {
    		//File file = new File()
    	}
    	
    		
    	
    	
    }
    public PTCKCMObject(File root, String name) throws PTCKCMException {
    	
		directoryPointer = new File(root, name);
		if (root.isDirectory()) {
			bDirectory=true;
			return;
		}
		
		Matcher matcher=compile(PREFIX+"\\.(\\d\\d\\d)\\.txt", name);
//		directoryObject  = new DirectoryObject(directoryPointer,PREFIX,matcher);
		
		
	
	}
    public void Destory() throws PTCKCMException {
    	try {
    	bufferedReader.close();
    	} catch (IOException ioe) {
    		throw new PTCKCMException("\nError: Cannot close file");
    
    	}
    }
    public String getHeader() {
    	return header+"\n\n\n";
    	 
    }
    public  int groupCount=0, tagCount=0;
    
    public String getTagHeader() {
    	return "gc: " + tagCount;
    }
	public PTCKCMObject(File root,  PTCKCMObject kObj) {
		fileKMP = new File(root, KMP);
		fileKonaWare = new File(root, StarShip);
		targetDirectory = kObj;
		
	}
	

	
	
	
  
  
	private Matcher compile(String regex, String targetString) {		
		    Pattern pattern = Pattern.compile(regex);
		    Matcher matcher = pattern.matcher(targetString);		    
		    if (matcher.find()) {
		    	return matcher;
		        
		    }
		    return null;
		      
	}
	


}
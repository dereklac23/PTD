package starship.util;
import starship.client.gui.*;
import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class KWLauncherFrame extends JFrame {
	MainPanelCreator puc=null;
	
	public static int WIDTH=800, HEIGHT=550;
	public KWLauncherFrame () {
    super("KonaWare.Installer.Java");
	puc=new MainPanelCreator();
	
    super.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    super.setSize(WIDTH,HEIGHT);
    
   

    JPanel pane =  (JPanel) getContentPane();
    pane.add(BorderLayout.CENTER, puc.getTabbedPane());
  
    super.setVisible(true);    
    super.addWindowListener(new WindowAdapter()
		  {
		      public void windowClosing(WindowEvent e)
		      {
 
		    	  puc.setStateClose();
		        
		      }
		  });
	}
}

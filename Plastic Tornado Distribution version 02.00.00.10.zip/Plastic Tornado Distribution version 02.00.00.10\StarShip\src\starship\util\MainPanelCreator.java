package starship.util;
import starship.atom.*;
import starship.client.gui.*;



import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.file.Path;

import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;

import starship.KWLauncher3;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/
import starship.atom.LocalContainer;


public class MainPanelCreator {
	 final JFileChooser fileChooser = new JFileChooser();
	 private JButton selectDirTomcat=null;
	 //PathUtil pathUtil=new PathUtil();
	 private  enum PANEL_TYPE {  LAYER0, LAYER1, lAYER2, LAYER3};
	 private PanelStruct panelArray [] = new PanelStruct[PANEL_TYPE.values().length];
	 private MenuLevel0 menuLayer0;
	 private MenuLevel1 menuLayer1;	 
	 private MenuLayer2 menuLayer2;
	 private MenuLevel3 menuLayer3;
	 private LocalContainer globalContainerL1 = null; 
	  
	public MainPanelCreator() {
		
		
		
	} 

	/** Returns an ImageIcon, or null if the path was invalid. */
    protected static ImageIcon createImageIcon(String path) {
        java.net.URL imgURL = KWLauncher3.class.getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }
    private int ClientRealmBrowsingWidth=400, ClientRealmBrowsingHeight=600;
	public JTabbedPane getTabbedPane() {
		JTabbedPane tabbedPane = new JTabbedPane();
		
		
		panelArray[PANEL_TYPE.LAYER0.ordinal()] = new PanelStruct("Layer 0", "Basement layer for local file  and working directory.", KeyEvent.VK_1);
		tabbedPane.addTab(panelArray[PANEL_TYPE.LAYER0.ordinal()].title,panelArray[PANEL_TYPE.LAYER0.ordinal()].comp);

		
		panelArray[PANEL_TYPE.LAYER1.ordinal()] = new PanelStruct("Layer 1", "Create core KWMessage to be uploaded.", KeyEvent.VK_2);
		tabbedPane.addTab(panelArray[PANEL_TYPE.LAYER1.ordinal()].title,panelArray[PANEL_TYPE.LAYER1.ordinal()].comp);

		
		panelArray[PANEL_TYPE.lAYER2.ordinal()] = new PanelStruct("Layer 2", "ICMP Packets to establish a heartbeat at the Kernel and System level", KeyEvent.VK_3);
		tabbedPane.addTab(panelArray[PANEL_TYPE.lAYER2.ordinal()].title,panelArray[PANEL_TYPE.lAYER2.ordinal()].comp);
		
		
		panelArray[PANEL_TYPE.LAYER3.ordinal()] = new PanelStruct("Layer 3", "Callback to receive KWMessage for rendering.", KeyEvent.VK_4);
		tabbedPane.addTab(panelArray[PANEL_TYPE.LAYER3.ordinal()].title,panelArray[PANEL_TYPE.LAYER3.ordinal()].comp);

		
		//Global Init
		LocalContainer localContainer = new LocalContainer();
		LocalContainer localContainerL0=		new LocalContainer(localContainer,LocalContainer.LEVEL_TYPE.LEVEL0);
		
				        
         
		JPanel panelLayer0 =(JPanel)panelArray[PANEL_TYPE.LAYER0.ordinal()].comp;
		panelLayer0.removeAll();		
		panelLayer0.add(BorderLayout.NORTH, menuLayer0 = new MenuLevel0(localContainerL0));
        
		

		JPanel panelLayer1 =(JPanel)panelArray[PANEL_TYPE.LAYER1.ordinal()].comp;
		panelLayer1.removeAll();		
		panelLayer1.add(BorderLayout.NORTH, menuLayer1 = new MenuLevel1(localContainerL0));
		
			
		JPanel panelLayer2 =(JPanel)panelArray[PANEL_TYPE.lAYER2.ordinal()].comp;
		panelLayer2.removeAll();
		panelLayer2.add(BorderLayout.NORTH, menuLayer2= new MenuLayer2(localContainerL0));
		
		
		JPanel panelLayer3 = (JPanel) panelArray[PANEL_TYPE.LAYER3.ordinal()].comp;
		panelLayer3.removeAll();
		menuLayer3=new MenuLevel3(ClientRealmBrowsingWidth,ClientRealmBrowsingHeight, localContainerL0);
		panelLayer3.add(BorderLayout.CENTER, menuLayer3);
		
		
         
		return tabbedPane;
	}
	
   public void setStateClose() {
      menuLayer3.setStateClose();
    
    }
	private JScrollPane getJTablePanel() {
		  
		  String[][] data = {
		            {"1", "C:\\USERS\\DEREK\\ECLIPSE-WORKSPACE", "12/22/2024"},
		            {"2", "E:\\DEV\\HELLOWORLD1", "12/23/2024"},
		            
		        };

		        // Column names
		        String[] columnNames = {"War file", "Directory", "Date"};

		        // Create JTable
		        JTable table = new JTable(data, columnNames);

		        // Add the table to a scroll pane
		        JScrollPane scrollPane = new JScrollPane(table);
		        return scrollPane;
		  
	  }
	 /*
	 public JPanel getTomcatPanel() {
		 
		    JPanel panel = new JPanel(); // the panel is not visible in output
	        selectDirTomcat= new JButton("Select $TOMCAT directory");
	        panel.add(selectDirTomcat);
	        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	        selectDirTomcat.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                // Show a message dialog when the button is clicked
	            	 int returnVal = fileChooser.showOpenDialog(panel);

	                 if (returnVal == JFileChooser.APPROVE_OPTION) {
	                     File file = fileChooser.getSelectedFile();
	                     //				System.out.println("file dire:"+file.getCanonicalPath());
						if (pathUtil.checkTomcatDirectory(file)) {
							selectDirTomcat.setEnabled(false);
							
						} else {
							System.out.println("$TOMCAT directory not verified");
						}
	                 } else {
	                 }
	            }
	        });

	        return panel;
	  }
	  */
}

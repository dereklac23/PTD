package konagui;

import java.awt.BorderLayout;
import java.awt.Dimension;


import javax.swing.JPanel;
import javax.swing.JTextArea;

import emailsender.html.PNotesHTMLOutput;

public class PNotesMenuHtml extends JPanel {
    public PNotesHTMLOutput editorHtml=null;
    private String htmlIndexPage=null;
    public String description=null;
    
	public PNotesMenuHtml(PNotesHTMLOutput _editorHtml, String _description) {
		super();
		add(BorderLayout.NORTH, _editorHtml);
		description=_description;
		editorHtml = _editorHtml;
		editorHtml.setContentType("text/html");
		editorHtml.setPreferredSize(new Dimension(500,550));
		editorHtml.attachHeader();		
		editorHtml.attachP(description);
		editorHtml.attachEnder();
		editorHtml.printPage();
		
		
	}  

}

package pttools;
import ptdatamodel.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class PTCKCMObject {
    public File directoryPointer=null;
    
    private final static String  PREFIX="Plastic Tornado Distribution version ",PROJECT_PREFIX="PLASTIC_TORNADO", 
    		KMP="KMP.war", StarShip ="StarShip.jar", PepMan ="PepMan.jar", MultiPlatform ="MultiPlatform.jar", 
    		DEV_ROOT="C:\\users\\derek\\eclipse-workspace\\dist\\lib";
    private File fileKMP, fileStarShip, filePepMan, fileMultiPlatform;
    
    public PTCKCMObject targetDirectory=null;
    public DirectoryObject directoryObject=null;
	
	public PTCKCMObject(DirectoryObject _do) {
	 	directoryObject =  _do;
	}
	private static String settingsFileHeadString="PTCommon.settings.xml";
	public Path resolve(String _strWorkingDirectory)  {
	  Path path  =Paths.get(_strWorkingDirectory);
	  try {
	   return path.resolve(settingsFileHeadString);
	  } catch (InvalidPathException ipe) {
		  return null;
	  }
	  
	}
	
	public Path resolve(File _workingDirectory)  {
		  Path path  =Paths.get(_workingDirectory.toURI()+File.pathSeparator+settingsFileHeadString);
		  try {
		   return path.resolve(settingsFileHeadString);
		  } catch (InvalidPathException ipe) {
			  return null;
		  }
		  
		}
	public boolean resolve(Path _path) {
		File _file = _path.toFile();
		return _file.isDirectory();
		
	}
    public boolean resolve(Path _root, String []_headStructure)  {
    	Path pathResolution=_root;
    	for (int i=0;i < _headStructure.length; i++) {
    		pathResolution=pathResolution.resolve(_headStructure[i]);
    		if (pathResolution ==null)  return false;
    			
    		}
    	
		return pathResolution.resolve(settingsFileHeadString) !=null;
	}
    
    public File resolveToFile(Path _root, String []_headStructure)  {
    	Path pathResolution=_root;
    	Path pathReturn=null;
    	if (_headStructure ==null) {
    		pathResolution = _root.resolve(settingsFileHeadString);
    		
    		return new File(pathResolution.toString());
    	} else {
    	for (int i=0;i < _headStructure.length; i++) {
    		pathResolution=pathResolution.resolve(_headStructure[i]);
    		
    			
    		}
    	}
    	
		pathReturn=pathResolution.resolve(settingsFileHeadString) ;
		return new File(pathReturn.toString());
		
	}
    
    public static Path resolveToPath(Path _root, String []_headStructure)  {
    	Path pathResolution=_root;
    	Path pathReturn=null;
    	if (_headStructure ==null) {
    		return _root.resolve(settingsFileHeadString);
    		
    		
    	} else {
    	for (int i=0;i < _headStructure.length; i++) {
    		pathResolution=pathResolution.resolve(_headStructure[i]);
    		
    			
    		}
    	}
    	
		return pathResolution;
		
		
	}
    
		
	public boolean checkDOMContentFile(Path _pathWorking) {
      Path p=	 _pathWorking.resolve(settingsFileHeadString);
      File f = p.toFile();
      return f.exists();
		 			
		
	}
	public String populate(Path _pathRoot, String []headerList,String _key) throws PTCKCMException {
		String strReturn=null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		Document  document=null;
		DocumentBuilder  builder=null;
		File  file=null;
		try {
		builder = factory.newDocumentBuilder();
		
		
		
		file = resolveToFile(_pathRoot, headerList);
		
		document=builder.parse(file);
		} catch (IOException ioe) {
			throw new PTCKCMException("Error in read for:"+file.toString());
			
		} catch (SAXException sax) {
			throw new PTCKCMException("Error parsing for:"+file.toString());
		} catch (ParserConfigurationException pce) {
			throw new PTCKCMException ("Parser reading error:"+file.toString());
		}
		
		NodeList nodeList = document.getElementsByTagName(_key);
		for (int i = 0; i < nodeList.getLength(); i++) {
		    Node node = nodeList.item(i);
		    if (node.getNodeType() == Node.ELEMENT_NODE) {
		        Element element = (Element) node;
		        //System.out.println("Employee ID: " + element.getAttribute("id"));
		        System.out.println("Printing Working directory: " + element.getElementsByTagName("WorkingDirectory").item(0).getTextContent());
		        strReturn =element.getElementsByTagName("WorkingDirectory").item(0).getTextContent();
		        
		        //System.out.println("Last Name: " + element.getElementsByTagName("lastName").item(0).getTextContent());
		    }
		}
		return strReturn;
		
	}
	public void deleteDOMContentFile(Path _pathContent) throws PTCKCMException {
		Path p=	 _pathContent.resolve(settingsFileHeadString);	    
		
		_pathContent.toFile().delete();//) throw new PTCKCMException("Error in file access");
		
	}
	
	public void createDOMContentFile(Path _pathContentWorkingDirectory, String []headerPath) throws PTCKCMException {
		DocumentBuilderFactory factory=null;
		DocumentBuilder builder=null;
		Document document=null;
		    try {
		    factory = DocumentBuilderFactory.newInstance();
	        builder = factory.newDocumentBuilder();

	        // Create a new Document
	        document = builder.newDocument();

	        // Create root element
	        Element root = document.createElement("Library");
	        document.appendChild(root);

	        // Create book elements and add text content
	        Element elementWorkingDirectory= document.createElement("WorkingDirectory");
	        elementWorkingDirectory.appendChild(document.createTextNode(_pathContentWorkingDirectory.toString()));
	        root.appendChild(elementWorkingDirectory);
	        
	        // Write to XML file
	        TransformerFactory transformerFactory = TransformerFactory.newInstance();
	        Transformer transformer = transformerFactory.newTransformer();
	        DOMSource source = new DOMSource(document);

	        // Specify your local file path
	        //Path pathElement = _pathContentWorkingDirectory.resolve(settingsFileHeadString);
	        File fileTarget = resolveToFile(_pathContentWorkingDirectory,headerPath );
	        StreamResult result = new StreamResult(fileTarget.toString());
	        transformer.transform(source, result);
		    } catch (ParserConfigurationException pce) {
		    		throw new PTCKCMException ("Parser configuration error");
		    } catch (TransformerException tfe) {
		    	    throw new PTCKCMException (tfe.toString());
		    }
		    
	        System.out.println("XML file created successfully!");
	}
    
    public PTCKCMObject(File root, String name) throws PTCKCMException {
		directoryPointer = new File(root, name);
		if (!directoryPointer.isDirectory()) {
			throw new PTCKCMException("\nroot has to be a directory");
		}
		if (name.endsWith(".tmp")) {
			return ;
			//ignore
		}
		Matcher matcher=compile(PREFIX+"(\\d)\\.(\\d)\\.(\\d\\d)\\.(\\d\\d)", name);
	
	    System.out.println("\ndone with allocating directory object");
	}
    
    DirectoryObject directoryObjectPointer=null;
    protected File root=null;
    protected String prefix = null;
    public PTCKCMObject(File _root, String _prefix, String _regex) throws PTCKCMException {
    	
          Pattern pattern=Pattern.compile(_prefix +  _regex);    	
          String list []= _root.list(new FileFilterSh(FileFilterSh.FILE_T.DIRECTORY));
          root=_root;
          prefix = _prefix;
          int runningID=0;
         for (int i=0; i < list.length; i++) {
        	 directoryObject = new DirectoryObject(_root,  pattern, list[i]);
        	 if (directoryObject.version!=null && directoryObject.compare(runningID)) {
        		 directoryObjectPointer=directoryObject ;
        		 runningID=directoryObject.getVersionInt();
        	 }
         }
         
    	
    }
    public void printVersionString() {
    	if (directoryPointer !=null) {
            System.out.println(root+File.separator+prefix+directoryObjectPointer.getVersionString(1));
            }
    }
	public PTCKCMObject(File root,  PTCKCMObject kObj) {
		fileKMP = new File(root, KMP);
		fileStarShip = new File(root, PROJECT_PREFIX+"-"+StarShip);
		filePepMan = new File(root, PROJECT_PREFIX+"-"+PepMan);
		fileMultiPlatform = new File(root, PROJECT_PREFIX+"-"+MultiPlatform);	
		targetDirectory = kObj;
		
	}
	

	
	
	public PTCKCMObject () {
		directoryObject = new DirectoryObject();
	}
	public void printDebugPeekString() {
		System.out.println("Peek string from PTCKCMObject");
		
	}
    public void performCopy() throws IOException {
    	System.out.println("\ndoing copy"+targetDirectory.directoryObject.getVersionString());
    	File targetKMP = new File(targetDirectory.directoryObject.docRelease, KMP);
    	File targetStarShip= new File(targetDirectory.directoryObject.docRelease, PROJECT_PREFIX+"-"+StarShip);    	
    	File targetPepMan= new File(targetDirectory.directoryObject.docRelease, PROJECT_PREFIX+"-"+PepMan);
    	File targetMultiPlatform= new File(targetDirectory.directoryObject.docRelease, PROJECT_PREFIX+"-"+MultiPlatform);    	
    	
    	Files.copy( 
    			Paths.get(fileStarShip.getCanonicalPath()),
    			Paths.get(targetStarShip.getCanonicalPath()), 
    			StandardCopyOption.REPLACE_EXISTING);
    	
    	Files.copy( 
    			Paths.get(filePepMan.getCanonicalPath()),
    			Paths.get(targetPepMan.getCanonicalPath()), 
    			StandardCopyOption.REPLACE_EXISTING);
    	
    	Files.copy( 
    			Paths.get(fileMultiPlatform.getCanonicalPath()),
    			Paths.get(targetMultiPlatform.getCanonicalPath()), 
    			StandardCopyOption.REPLACE_EXISTING);

    	
    	
    }
    public void performCopyWarBinaries() throws IOException {
    	File devRoot = new File(DEV_ROOT	);
    	File warSourceFile = new File(devRoot, KMP);
    	warSourceFile.isFile();
    	String warFileStr= warSourceFile.getCanonicalPath();
    	File targetKMPWarFile = new File(directoryObject.fileDirectoryTarget, KMP);
    	Files.copy(
    			Paths.get(warFileStr),
    			Paths.get(targetKMPWarFile.getCanonicalPath()),
    			StandardCopyOption.REPLACE_EXISTING);
    }
	private Matcher compile(String regex, String targetString) {		
		    Pattern pattern = Pattern.compile(regex);
		    Matcher matcher = pattern.matcher(targetString);		    
		    if (matcher.find()) {
		    	return matcher;
		        
		    }
		    return null;
		      
	}
	


}
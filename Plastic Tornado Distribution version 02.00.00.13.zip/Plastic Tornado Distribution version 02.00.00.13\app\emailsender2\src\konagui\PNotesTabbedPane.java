package konagui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

import emailsender.html.PNotesTEXTOutput;

public class PNotesTabbedPane extends Panel {
    public JPanel panel=null;
    private ArrayList<TabbedItem> panelList = new ArrayList<TabbedItem>();
    private ArrayList<HCustomListener> actionList = new ArrayList<>();
	private JPanel outputPanel=null;
	public JTabbedPane tabbedPanel=null;
	public PNotesMenuHtml htmlOutput=null;
	public PNotesMenuText textOutput=null;
	private int width=0, height=0;
	public PNotesTabbedPane(int _width, int _height) {		
		width = _width;
		height = _height;
	   	tabbedPanel = new JTabbedPane();
	}
	public void allocate(String _title, int _keyEvent,PNotesMenuHtml _hO) {	
		panelList.add(new TabbedItem(_title,_keyEvent, _hO));
	}
	public void allocate(String _title, int _keyEvent,PNotesMenuText _jA) {	
		panelList.add(new TabbedItem(_title,_keyEvent, _jA));
	}
	public void allocate(HCustomListener _hListener) {
		actionList.add(_hListener);
	}
	public int getTabbedIndexHtml() {
		return 1;
		
	}
	public int getTabbedIndexText() {
		return 2;
	}
    public void execute( ) {
    	
    }
	public void freeze(JPanel _panel) {
		for (int i=0; i < panelList.size(); i++) {
			TabbedItem ti= panelList.get(i);
			tabbedPanel.add(ti.title,ti.panel);
		}
		_panel.add(tabbedPanel);
		
	}
	protected class TabbedItem {
		protected String title =null, description =null;	
		private int keyEvent=0;
		public JPanel panel=null;
		
		public TabbedItem(String _title, int _keyEvent, PNotesMenuHtml _hO) {
			title = _title;

			keyEvent = _keyEvent;			
			panel = new JPanel(false);
		    panel.setLayout(new GridLayout(1, 1));
		    panel.add(_hO);
		    htmlOutput=_hO;
		    htmlOutput.setPreferredSize(new Dimension(width, height));
		    panel.setPreferredSize(new Dimension(width,height));
		    
		    		
	    }
		public TabbedItem(String _title, int _keyEvent, PNotesMenuText _tOutput) {
			title = _title;
			keyEvent = _keyEvent;
			textOutput = _tOutput;
			textOutput.editor.setText("allocated");
			panel = new JPanel(false);
		    panel.setLayout(new GridLayout(1, 1));
		    panel.add(_tOutput);		    
		    _tOutput.setPreferredSize(new Dimension(width, height));
		    panel.setPreferredSize(new Dimension(width,height));
		    
		    		
	    }  

		
	}
}

package mpdatamodel;

import java.nio.file.Path;

public class SettingsEntry {
	
	public String token=null;
    public Path path=null;
    public enum TYPE {WORKING, SAND_BOX, URI}
    public boolean active=false;
    
    public static int length=3;
    
    
	
	public SettingsEntry (String _tok) {
		token = _tok;
		path=null;
		active=false;
	}
	public void set(Path _p) {
		path = _p;
		active=true;
	}
	private String getActiveString() {
		if (active) {
			return "active";
		} return "---";
	}
	
	public String get(int _col) {
		switch (_col) {
		case 0: return token;
		case 1:  if (path !=null && path.getParent() !=null) {
			
			return path.getParent().toString();
			
		} else {
			
			return " ";
		}
		case 2: return getActiveString();
		}
	
	return "default";
	}
}

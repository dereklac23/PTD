package multiplatform;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.nio.file.Path;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTML.Attribute;
import javax.swing.text.html.HTML.Tag;

import org.w3c.dom.Element;

import emailsender.gui.Entry;
import emailsender.gui.ExpansionFramePNotes;
import konagui.PNotesMenuText;
import konagui.PNotesTabbedPane;
import emailsender.html.PNotesHTMLOutput;
import emailsender.html.PNotesTEXTOutput;
import emailsender.tools.PNotesKCMException;
import emailsender.tools.PNotesPathUtil;
import konagui.PNotesMenuHtml;
import ptgui.KonaTabbedPane;
import pttools.PTCKCMObject;
import mpdatamodel.SettingsEntry;
import mpdatamodel.MPSettingsListener;
import mpdatamodel.SettingsModel;





public class MultiPlatform extends JFrame {
  /**
	 * 
	 */

  private static final long serialVersionUID = 1L;
  private static MultiPlatform multiP=null;
  private int WIDTH=600, HEIGHT=600, OFFSET=20;
  private JPanel mainPanel=null;
  private PNotesTabbedPane tabbedPanel=null;
  private JPanel southPanel =null,  northPanel=null;
  private PNotesPathUtil pathUtil=null;
  public MultiPlatform() {
	  super("MultiPlatform");
	  JPanel panel = (JPanel) this.getContentPane();
	  panel.setLayout(new BorderLayout());
	  panel.add(BorderLayout.NORTH, northPanel = getNorthPanel());
	  panel.add(BorderLayout.CENTER,mainPanel =  getCenterPanel());
	  panel.add(BorderLayout.SOUTH, southPanel = getSouthPanelExpansion());	  
	  pathUtil = new PNotesPathUtil();
	  
	  this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	  
      mainPanel.setPreferredSize(new Dimension(WIDTH+OFFSET*3, HEIGHT/5*2+HEIGHT+OFFSET*2));      
      this.setSize(new Dimension(WIDTH+OFFSET*3, HEIGHT/5*2+HEIGHT+OFFSET*2));
      this.setVisible(true);
  }
  private PNotesHTMLOutput htmlOutputPlasticNotes=null, htmlOutputMusicReactant=null, htmlOutputSettings=null, htmlOutputCNM=null;
  private PNotesTEXTOutput textOutput=null;
  private PNotesMenuText  plasticMenuText=null;
  private JPanel getCenterPanel() {
	  JPanel panel = new JPanel();
	  
	  plasticMenuText = new PNotesMenuText(textOutput=new PNotesTEXTOutput());
	  PNotesMenuHtml menuHtmlPlasticNotes =null, menuHtmlMusicReactant=null, menuHtmlSettings=null, menuHtmlCNM=null;
	  tabbedPanel = new PNotesTabbedPane(WIDTH, HEIGHT-OFFSET);	  
	  
	  tabbedPanel.allocate("Settings",  KeyEvent.VK_1,
			  menuHtmlSettings= new PNotesMenuHtml(
					new PNotesHTMLOutput(WIDTH+OFFSET*2, HEIGHT), "Settings Html"));	  

	  tabbedPanel.allocate("PlasticNotes Html",  KeyEvent.VK_2,
			  menuHtmlPlasticNotes= new PNotesMenuHtml(
					new PNotesHTMLOutput(WIDTH+OFFSET*2, HEIGHT), "Plastic Notes Html"));	  
	  tabbedPanel.allocate("PlasticNotes Text",  KeyEvent.VK_3, plasticMenuText);
	  tabbedPanel.allocate("MusicReactant",  KeyEvent.VK_3, 
			  menuHtmlMusicReactant =
			  new PNotesMenuHtml(new PNotesHTMLOutput(WIDTH+OFFSET*2, HEIGHT), 
					  "Music Reactant to 'da beat! Boom! Boom! Bomm!"));
	  
	  tabbedPanel.allocate("CNM",  KeyEvent.VK_4, 
			  menuHtmlCNM=
			  new PNotesMenuHtml(new PNotesHTMLOutput(WIDTH+OFFSET*2, HEIGHT), 
					  "Consequential Media for the photogenic filming of the elite!"));


	  menuHtmlSettings.editorHtml.setContentType("text/html");
	  menuHtmlSettings.editorHtml.setEditable(false);
	  menuHtmlSettings.editorHtml.addHyperlinkListener(new HCustomListener(this));

	  menuHtmlPlasticNotes.editorHtml.setContentType("text/html");
	  menuHtmlPlasticNotes.editorHtml.setEditable(false);
	  menuHtmlPlasticNotes.editorHtml.addHyperlinkListener(new HCustomListener(this));
	  
	  menuHtmlCNM.editorHtml.setContentType("text/html");
	  menuHtmlCNM.editorHtml.setEditable(false);
	  menuHtmlCNM.editorHtml.addHyperlinkListener(new HCustomListener(this));

	  
	  tabbedPanel.freeze(panel);
	  htmlOutputSettings      = menuHtmlSettings.editorHtml;
	  htmlOutputPlasticNotes  = menuHtmlPlasticNotes.editorHtml;
	  htmlOutputMusicReactant = menuHtmlMusicReactant.editorHtml;
	  htmlOutputCNM           = menuHtmlCNM.editorHtml;
	  
	  
	  refreshPlasticNotesHtmlPage();
	  refreshMusicReactantHtmlPage();
	  refreshSettingsPage();
	  return panel;	  
  }
  private void performCopyPreset() {
	  String strPreset="""
@麥明詩 Louisa Mak
@magwe
@pat
@chriscuo
@brunomars
@usher
@kendrickl
@ladygaga
@taylorswift
@andysun
@Black Eyed Peas
@John Legend
@U2

	  		""";
	  if (strFBUrlLinkContent !=null) {
		  strPreset +=strFBUrlLinkContent;
	  }
	  pathUtil.copyToClipboard(strPreset);
	  
	  
  }
  private void performIterate() {
	  
  	try {
  	StringBuffer sbHtml = new StringBuffer(1028), sbText = new StringBuffer(1028);
  	String strText=null, strHtml =null;
  	int selectedIndex= tabbedPanel.tabbedPanel.getSelectedIndex();
  	if (selectedIndex == tabbedPanel.getTabbedIndexText()) {  		
  		sbText.append(expansionFrameText.provisionHeader()); 
  		Entry entry=null;
  		if (moduloPathUtil.bIterateFilter ) {
  		    entry=expansionFrameText.iterateFilter();  		
  		} else {  		
  			entry=expansionFrameText.iterate();
  		}  			
  			if (entry!=null) {
  			sbText.append(expansionFrameText.extract(entry.kcmObject,false));
  			} else {
  				sbText.append("End");
  			}
  		
  		
      	
      	if (strTwitterUrlLinkContent !=null) {
      		sbText.append("\n\n"+strTwitterUrlLinkContent);
      	} else if (expansionFrameText.getFacebookLink()!=null) {
      	sbText.append("\n\n"+expansionFrameText.getFacebookLink());
      	}
      	strText = sbText.toString();     
      	tabbedPanel.validate();      	
      	pathUtil.copyToClipboard(strText);      	
      	textOutput.setText(strText);
  	} else if (selectedIndex == tabbedPanel.getTabbedIndexHtml()) {
  		sbHtml.append(getPlasticNotesHtmlMainContent());
  		sbHtml.append(expansionFrameText.provisionHeader());
  		sbText.append(expansionFrameText.provisionHeader());
  		Entry entry=null;
  		if (moduloPathUtil !=null && moduloPathUtil.bIterateFilter ) {
  		    entry=expansionFrameText.iterateFilter();  		
  		} else {  		
  			entry=expansionFrameText.iterate();
  		}  			
  		if (entry!=null) {
  			String contentKCM =expansionFrameText.extract(entry.kcmObject,false); 
  			sbText.append(contentKCM);
  			sbHtml.append(contentKCM);
  		} else {
  				sbText.append("End");
  		}
  		if (strTwitterUrlLinkContent !=null) {
      		sbText.append("\n\n"+strTwitterUrlLinkContent);
      	} else if (expansionFrameText.getFacebookLink()!=null) {
      	sbText.append("\n\n"+expansionFrameText.getFacebookLink());
      	}
      	strHtml= sbHtml.toString();
      	strText =sbText.toString(); 
      	
      	tabbedPanel.validate();      	
      	pathUtil.copyToClipboard(strText);
      	textOutput.setText(strText);
      	htmlOutputPlasticNotes.setText(strHtml);

  	}
  	
  	
  	
  	} catch (PNotesKCMException kcm) {
  		System.err.println("\nError in kcm:"+kcm.toString());
  	}
  	
  }
  private String getSettingsContent() {
	  StringBuffer sb = new StringBuffer();
	  sb.append("<p>"+ "Settings</p>");
	  return sb.toString();
  }
  private String getPlasticNotesHtmlMainContent() {
	  StringBuffer sb = new StringBuffer();
	  sb.append("<p>"+"PaperNotes version 1.02</p>");
	  sb.append("<p><a href='http://refresh.jpg'>Refresh</a></p>");
	  for (SettingsEntry se: settingsModel.syncCollection) {
		   if (se.active && se.path !=null) {
			   sb.append("<p>"+se.path.toString()+"</p>");
					  
		   } else {
			   sb.append("<p>Inactive</p>");
		   }
	   }
	  
	  sb.append("<li><a href='http://provision'>Provision</a></li>");
	  sb.append("<li><a href='http://reset'>Reset</a></li>");
	  sb.append("<li><a href='http://iterate'>Iterate</a></li><br>");
	  sb.append("<li><a href='http://clipboard.copy.preset'>Clipboard copy preset</a></li>");
	  
	  if (pathUtil!=null && pathUtil.allFilesSync !=null) {
		  sb.append("<p>Size of path:"+pathUtil.allFilesSync.size()+"</p>");
	  }
	  return sb.toString();
	  
  }
  
  private String getMusicReactantHtmlMainContent() {
	  StringBuffer sb = new StringBuffer();
	  sb.append("<p>Status bar v1</p>");
	  return sb.toString();
	  
  }
  private void refreshSettingsPage() {
	  htmlOutputSettings.attachHeader();
	  htmlOutputSettings.attachRaw(getSettingsContent());
	  htmlOutputSettings.attachEnder();
	  htmlOutputSettings.printPage();
	  
  }
  private void refreshPlasticNotesHtmlPage() {
	  htmlOutputPlasticNotes.attachHeader();
	  htmlOutputPlasticNotes.attachRaw(getPlasticNotesHtmlMainContent());
	  htmlOutputPlasticNotes.attachEnder();
	  htmlOutputPlasticNotes.printPage();
  }
  private void refreshMusicReactantHtmlPage() {
	  htmlOutputMusicReactant.attachHeader();
	  htmlOutputMusicReactant.attachRaw(getMusicReactantHtmlMainContent());
	  htmlOutputMusicReactant.attachEnder();
	  htmlOutputMusicReactant.printPage();
  }
  private JButton btnExpansion=null;
  private JPanel getSouthPanel() {
	  JPanel panel = new JPanel();
	  panel.setLayout(new BorderLayout());
	  panel.add(btnExpansion=new JButton("Expansion frame"));
	  btnExpansion.addActionListener(new ExpansionListener(settingsModel));
	  return panel;
  }
  public SettingsModel settingsModel=null;
  private MPSettingsListener settingsListener=null;
  private JPanel getNorthPanel() {
	  MPPropertiesPage pp = null;
	  JPanel panel = new JPanel();
	  panel.setLayout(new BorderLayout());
	  settingsModel= new SettingsModel(panel);	  
	  panel.add(BorderLayout.CENTER,pp=new MPPropertiesPage(MPPropertiesPage.TYPE.SETTINGS ,
			  WIDTH, HEIGHT/5,
			  settingsModel));
	  settingsModel.fireTableDataChanged();	 
	  settingsListener= new MPSettingsListener(pp, null);
	  panel.add(BorderLayout.SOUTH, new FBURLPage());
	  return panel;	  
  }
  public static void main(String args[]) {
	  File  rootDev= new File("D:\\dev");
	    if (args.length==2 && args[0].equals("-peek") ) {
	    	PTCKCMObject kObject = new PTCKCMObject();
	    	kObject.printDebugPeekString();
	    } else {
	    SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
	    }
  } 
	private static void createAndShowGUI() {
		multiP= new MultiPlatform();
      
    }
	
	private ExpansionFramePNotes expansionFrameHtml=null;
	private ExpansionFramePNotes expansionFrameText=null;
	private JButton btnExpansionHtml =null, btnExpansionText=null;
	
	private JPanel getSouthPanelExpansion() {
    	expansionFrameHtml = new ExpansionFramePNotes(ExpansionFramePNotes.TYPE.HTML, WIDTH+OFFSET*4, HEIGHT);
    	expansionFrameText = new ExpansionFramePNotes(ExpansionFramePNotes.TYPE.TEXT, WIDTH+OFFSET*4, HEIGHT);
		JPanel panel = new JPanel();
		panel.add(btnExpansionHtml=new JButton(("Open Expansion for PlasticNotes (html format)")));
		btnExpansionHtml.addActionListener(  new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               expansionFrameHtml.setVisible(true);      
                      	
            	
            }
        });
		panel.add(btnExpansionText=new JButton(("Open Expansion for PlasticNotes (text format)")));
		btnExpansionText.addActionListener(  new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               expansionFrameText.setVisible(true);
            	
            }
        });

		return panel;		
	}
	private void performReset() {
		expansionFrameHtml.reset();
    	expansionFrameText.reset();
    	textOutput.setText("Reset successful");
   
    	//expansionFrameText. 
	}
	PNotesPathUtil moduloPathUtil= null;
	private String headerData[] = {"data","x"};
			
	public void perform(String _url) throws PNotesKCMException {
		
		File fileSave=null;
		
		if (_url.equals(("http://provision"))) {
			for (SettingsEntry se: settingsModel.syncCollection) {
				   if (se.active && se.path !=null) {
					   if (pathUtil!=null) {
					   Path pathData =  PTCKCMObject.resolveToPath(se.path, headerData);
					   pathUtil.processRecursive(pathData, htmlOutputPlasticNotes);
					   fileSave= new File("Output.html");
					   moduloPathUtil = new PNotesPathUtil(new File(pathData.toString(),"PlasticNotes.xml"));
					   expansionFrameHtml.setPathUtil(pathUtil,fileSave, moduloPathUtil);
					   expansionFrameText.setPathUtil(pathUtil,fileSave, moduloPathUtil);
					   expansionFrameHtml.populateTree();
					   expansionFrameText.populateTree();
					   
					   }
					   
					   
					   refreshPlasticNotesHtmlPage();
					   textOutput.append(expansionFrameHtml.provisionHeader());
				   } 
			   }
		} else if (_url.equals("http://reset")) {
			performReset();
		} else if (_url.equals("http://iterate")) {
			performIterate();
		} else if (_url.equals("http://clipboard.copy.preset")) {
			performCopyPreset();
		}
	}
	
	private class ExpansionListener implements ActionListener {
         AbstractTableModel atm=null;
		
		ExpansionListener(AbstractTableModel _atm) {
			atm=_atm;
		}
		@Override
		public void actionPerformed(ActionEvent e) {			
			atm.fireTableDataChanged();
		}
		
	}
	public class HCustomListener implements HyperlinkListener {
        private MultiPlatform multiPlatform=null;
		public HCustomListener(MultiPlatform _mp) {
			multiPlatform = _mp;
			
		}
		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			try {
				
			if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
			perform(e.getURL().toString());
			} 
			} catch (PNotesKCMException kcm) {
				System.out.println("\nError: "+kcm.toString());
			}
		//	 
	
	}
	}
	private JTextField tfFBUrlLink=null, tfTwitterUrlLink=null;
	private String strFBUrlLinkContent =null, strTwitterUrlLinkContent=null;
	private class FBSubmit implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			strFBUrlLinkContent = tfFBUrlLink.getText();
			
		}
		
	}
	private class TwitterSubmit implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			strTwitterUrlLinkContent = tfTwitterUrlLink.getText();
		}
		
		
	}
	public class FBURLPage extends JPanel {
		private JButton btnFBSubmit=null, btnTwitterSubmit=null;
		FBURLPage() {
			super.setLayout(new GridBagLayout());
			GridBagConstraints c = new GridBagConstraints();
			c.gridx=0;
			c.gridy=0;
			c.weightx=0.2;
			c.fill = GridBagConstraints.HORIZONTAL;
			add(new JLabel("FB Url content link:"),c);			
			c.gridx++;
			c.weightx=.6;
			add(tfFBUrlLink=new JTextField(20),c);
			c.gridx++;
			c.weightx=0.2;
			c.anchor=GridBagConstraints.PAGE_END;
			add(btnFBSubmit=new JButton("Submit FB"),c);
			btnFBSubmit.addActionListener(new FBSubmit());
			
			c.anchor=GridBagConstraints.PAGE_START;
			c.gridy=1;
			c.gridx=0;
			c.weightx=0.2;
			add(new JLabel("TwitterX content link:"),c);
			c.weightx=.6;
			c.gridx++;
			add(tfTwitterUrlLink = new JTextField(20),c);
			c.gridx++;
			c.weightx=.2;
			c.anchor= GridBagConstraints.PAGE_END;
			add(btnTwitterSubmit = new JButton("Submit Twitter"),c);
			btnTwitterSubmit.addActionListener(new TwitterSubmit());
			
			
			
		}
	}
}





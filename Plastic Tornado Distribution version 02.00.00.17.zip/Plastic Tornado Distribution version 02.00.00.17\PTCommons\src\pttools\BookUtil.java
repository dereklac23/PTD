package pttools;
import ptdatamodel.*;
import ptdatamodel.Entry.EntryType;
import ptgui.*;

import java.io.BufferedInputStream;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
//import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import ptgui.ButtonSelection;

//import konaware.server.atom.KWServerHashMapEntry;

//import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/

public class BookUtil {
	  private final static String TOMCAT="D:\\utility\\apache-tomcat-11.0.3"; 
	  public HashMap <String, PTCKCMObject> kwMapEntry = 
				new HashMap<String, PTCKCMObject>();
	  public Map<String, PTCKCMObject> eMap =  Collections.synchronizedMap(kwMapEntry);
	  
	  private String name=null;   
	  
	
	  private StringBuffer pageBuffer=new StringBuffer();
	  public JComboBox<ButtonSelection> comboPointer=null;
	  public  ArrayList<ButtonSelection> comboInitial=null;
	  public String pathName=null;
	  public File pathObject=null;
	  public Entry fileEntry=null, directoryEntry=null;
	  public MenuGTML menuGTML = null;
	  																		
	  
public void parse(Path _p, String _parseExpression, String _value, Entry _eRoot) throws PTCKCMException {
	
	
	
	try {
	     DocumentBuilderFactory builderFactory =
	             DocumentBuilderFactory.newInstance();
	     DocumentBuilder builder = null;

			 builder = builderFactory.newDocumentBuilder();
			 Document doc = builder.parse(new File(_p.toString()));
			 
			 XPathFactory xpathfactory = XPathFactory.newInstance();
			 XPath xpath = xpathfactory.newXPath();
			 XPathExpression expr = xpath.compile(_parseExpression);
			 Object result = expr.evaluate(doc, XPathConstants.NODESET);
			 NodeList nodes = (NodeList) result;
			 
		     Entry entryRoot = new Entry(EntryType.STRUCTURE, "Book");
             
					 for (int i = 0; i < nodes.getLength(); i++) {
				  	   //System.out.println("leng"+nodes.getLength());
					   System.out.println(nodes.item(i).getNodeName());		   
					   //System.out.println("value="+nodes.item(i).getNodeValue());
					   
					   Entry.linkFamily(entryRoot,  new Entry(EntryType.STRUCTURE, nodes.item(i).getNodeName()));		   
					   
					 }
		 
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new PTCKCMException("Error in parser");
		} catch (IOException ioe) {
			throw new PTCKCMException ("Error in IO");
		} catch (SAXException sax) {
			throw new PTCKCMException("Error in sax");
		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			throw new PTCKCMException ("Error in x path");

		}
	    
	
	
}
 public BookUtil( ) {
	 /*
	 InputStreamReader reader = new InputStreamReader(System.in);
 	try {
     DocumentBuilderFactory builderFactory =
             DocumentBuilderFactory.newInstance();
     DocumentBuilder builder = null;

		 builder = builderFactory.newDocumentBuilder();
		 Document doc = builder.parse(new File("resource/html/PAGE.001.xml"));
		 XPathFactory xpathfactory = XPathFactory.newInstance();
		 XPath xpath = xpathfactory.newXPath();
		 XPathExpression expr = xpath.compile("//listener/port/text()");
		 Object result = expr.evaluate(doc, XPathConstants.NODESET);
		 NodeList nodes = (NodeList) result;
		 

		 for (int i = 0; i < nodes.getLength(); i++) {
	  	   System.out.println("leng"+nodes.getLength());
		   System.out.println(nodes.item(i).getNodeName());		   
		   System.out.println("value="+nodes.item(i).getNodeValue());
		   
		 }
	 
	} catch (ParserConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException ioe) {
		System.err.println("ioe error"+ioe.getMessage());
	} catch (SAXException sax) {
		
	} catch (XPathExpressionException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    */
 
 }
 
 public BookUtil(PepMan.EntryType _type, String _entryName) {
	 typeEntry = _type;
	 nameEntry = _entryName;
	 pathObject = new File(".");
 }
 public BookUtil(PepMan.EntryType _type, String _entryName, File _root, MenuGTML _menuG) {
	 typeEntry = _type;
	 nameEntry = _entryName;
	 pathObject = _root;
	 
	 menuGTML = _menuG;
 }
 public BookUtil(PepMan.EntryType _type, String _entryName,  MenuGTML _menuG) {
	 typeEntry = _type;
	 nameEntry = _entryName;	 
	 menuGTML = _menuG;
 }

 
 PTCKCMObject directoryKCM= new PTCKCMObject();
 public MenuInterface menuInterface=null;
 
 public BookUtil(PepMan.EntryType _type, String _entryName,
         JComboBox<ButtonSelection> _comb, MenuInterface _menuI) {
comboPointer= _comb;
menuInterface= _menuI;
nameEntry = _entryName;
typeEntry = _type;
//pathObject = new File(".");
directoryEntry = new Entry(Entry.EntryType.DIRECTORY, new File("."));


	

}

 private PepMan.EntryType typeEntry=PepMan.EntryType.STAGING;
 private String nameEntry =null;
 
 public BookUtil (
		 PepMan.EntryType _type,
		 String _entryName,
		 MenuInterface _menuI) {
	  typeEntry = _type;
	  nameEntry = _entryName;
	  menuInterface = _menuI;
	  pathObject = new File(".");
 }
		 
 public BookUtil (
		 PepMan.EntryType _type, 
		 String _entryName,
		 File _target,
		 MenuInterface menuI) {
	 typeEntry=_type;
	 nameEntry = _entryName;
	 
	 
	 pathObject=_target;

	 File file[] = _target.listFiles(new FileFilterSh(FileFilterSh.FILE_T.RELEASE_NAMING));
	 PTCKCMObject  kObject=null;
	 for (int i=0; i < file.length; i++) {
		 try {
		 kObject = new PTCKCMObject(_target, file[i].getName());
		 //System.out.println("\nGot KCM Object"+ file[i].getName());
		 } catch (PTCKCMException kcm) {
			 System.out.println("\nkcm error"+kcm.description);
		 }
		 if (kObject !=null) {		   	 
		   eMap.put(kObject.directoryObject.getVersionString(), kObject);
		 }
		 
	 }
	 Set<String> keySet=eMap.keySet();
	
	 int runningVersionId=0;
	 for (Map.Entry<String, PTCKCMObject> entry : eMap.entrySet()) {
		 PTCKCMObject object = entry.getValue();
		 if (directoryKCM.directoryObject.compare(runningVersionId)) {
			 runningVersionId=directoryKCM.directoryObject.getVersionInt();
			 directoryKCM = object;
		 }
	 }	 
	 menuInterface = menuI;
	 
	
 }
 
		
	 
 
 public void setComboInitial(ArrayList <ButtonSelection> _comboInitialList) {
	 comboInitial = _comboInitialList;
 }


 private void processTxt(File f) throws FileNotFoundException, IOException  {
	 BufferedReader br= new BufferedReader(new FileReader(f));
	 String line = null;
	 
	 while ((line = br.readLine()) !=null) {
		 pageBuffer.append(line);
	 }
	
	 
	 
 }
 public void updateFileString(String _pathName) {
	 pathName = _pathName;
	 
 }
 public void updateFileObject(File _obj) {
	 pathObject = _obj;
 }
 public BookInfoUnit processBuffer(File _root, String _header , Path _p) throws PTCKCMException {
	 String line=null;
	 StringBuffer sb = new StringBuffer();
	 System.out.println("To path:"+_p.toAbsolutePath().toFile());
	 try {
		 FileReader fr = new FileReader(_p.toAbsolutePath().toFile());
	 BufferedReader br = new BufferedReader(fr);
     line=	 br.readLine();
     while ( (line = br.readLine()) !=null) {
    	 sb.append(line);    	 
     }
	 
	 } catch (FileNotFoundException fnoe) {
		 throw new PTCKCMException ("\nFile not found:");
		
	 }  catch (IOException ioe) {
		 throw new PTCKCMException ("\nIO Exception ");
	 }
	 return new BookInfoUnit(_root,  sb.toString());
	 
 }
 public PageInfoUnit processPage(File _root, Path _p) throws PTCKCMException {
	 PageInfoUnit piu  = new PageInfoUnit(_p);
	 BufferedReader bufferedReader=null;
      try {
	 bufferedReader= new BufferedReader(new FileReader(_p.toString()));
      } catch (FileNotFoundException fne) {
    	  throw new PTCKCMException ("\nFile not found:");
      }
   return piu;
	 
 }
 public HashMap<String,BookInfoUnit> processBookXml(File _root, Path _p) throws PTCKCMException {
	 HashMap<String,BookInfoUnit> biuList = new HashMap<String,BookInfoUnit>();	 
	 
	 BookInfoUnit biuEntry =null, bookRoot=null;
		try {
		     DocumentBuilderFactory builderFactory =
		             DocumentBuilderFactory.newInstance();
		     DocumentBuilder builder = null;

				 builder = builderFactory.newDocumentBuilder();
				 Document doc = builder.parse(new File(_p.toString()));
				 XPathFactory xpathfactory = XPathFactory.newInstance();
				 XPath xpath = xpathfactory.newXPath();
				 
				
				 bookRoot= new BookInfoUnit(_root,_p);
	
				 for (int i=0; i < bookRoot.listOfBooks.size(); i++) {
					 biuEntry =bookRoot.listOfBooks.get(i);				
					 if (biuEntry==null) {
						 return null;
					 }
					 Object result=null;					 
					 try {
						
					
						 
						XPathExpression expr = xpath.compile(biuEntry.getTag());
					 result = expr.evaluate(doc, XPathConstants.NODESET);
					 }catch (XPathExpressionException e) {
						
						
						}
					 NodeList nodes = (NodeList) result;					 
					 if (nodes !=null && nodes.getLength() > 0) {

							 biuEntry.value = nodes.item(0).getNodeValue();
							 String name = nodes.item(0).getNodeName();							 

							 biuList.put(biuEntry.getTag(), biuEntry);
						
						 
					 } else {
						 System.out.println(biuEntry.getTag()+"\n[failed]");
					 }

				 }
			 
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				throw new PTCKCMException("\nParser exception");
			} catch (IOException ioe) {
				throw new PTCKCMException ("\nIOException ");
			} catch (SAXException sax) {
				throw new PTCKCMException ("\nSax exception");
			} 
		 return biuList;
 }
 
 public ArrayList<ChapterInfoUnit> processChapterXml(File _root, Path _p) throws PTCKCMException {
	 ArrayList<ChapterInfoUnit> ciuList = new ArrayList<ChapterInfoUnit>();	 
	 
	 ChapterInfoUnit ciuEntry =null, chapterRoot=null;
		try {
		     DocumentBuilderFactory builderFactory =
		             DocumentBuilderFactory.newInstance();
		     DocumentBuilder builder = null;

				 builder = builderFactory.newDocumentBuilder();
				 Document doc = builder.parse(new File(_p.toString()));
				 XPathFactory xpathfactory = XPathFactory.newInstance();
				 XPath xpath = xpathfactory.newXPath();
				
				 chapterRoot= new ChapterInfoUnit(_root,_p);
	
				 for (int i=0; i < chapterRoot.listOfChapters.size(); i++) {
					 ciuEntry =chapterRoot.listOfChapters.get(i);				
					 if (ciuEntry==null) {
						 return null;
					 }
					 Object result=null;					 
					 try {
						
					
						 
					 XPathExpression expr = xpath.compile(ciuEntry.getTag());
					 result = expr.evaluate(doc, XPathConstants.NODESET);
					 }catch (XPathExpressionException e) {
						
						
						}
					 NodeList nodes = (NodeList) result;	
					 if (nodes !=null && nodes.getLength()==1 && i==0) {
						ciuEntry.chapterString= nodes.item(0).getNodeValue();
						ciuList.add(ciuEntry);
					 } else  if (nodes !=null && nodes.getLength() > 0) {
							 ciuEntry.headerString= nodes.item(0).getNodeValue();							
							 ciuList.add(ciuEntry);					
						 
					 } else {
						 System.out.println(ciuEntry.getTag()+"\n[failed]");
					 }

				 }
			 
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				throw new PTCKCMException("\nParser exception");
			} catch (IOException ioe) {
				throw new PTCKCMException ("\nIOException ");
			} catch (SAXException sax) {
				throw new PTCKCMException ("\nSax exception");
			} 
		 return ciuList;
 }

 
 private static Node createUser(Document doc, String id, String firstName,
         String lastName, String occupation) {

     Element user = doc.createElement("user");

     user.setAttribute("id", id);
     user.appendChild(createUserElement(doc, "firstname", firstName));
     user.appendChild(createUserElement(doc, "lastname", lastName));
     user.appendChild(createUserElement(doc, "occupation", occupation));

     return user;
 }

 private static Node createUserElement(Document doc, String name,
         String value) {

     Element node = doc.createElement(name);
     node.appendChild(doc.createTextNode(value));

     return node;
 }
 
public void setEntryName(String _newValue) {
	nameEntry = _newValue;
}
 public String setEntryName() {
	return nameEntry;
 }
 public String getCategory() {
	if (typeEntry == PepMan.EntryType.CLASSPATH) {
		return "CLASSPATH";
	} if (directoryKCM.directoryPointer==null) {
		return "Folder";
	}	else {
		return "Folder";
	}
 }
 public void setAttributeFile(File _file) {	 
	 pathObject = _file;
 }
 
 public void setAttributeString(String _value) {
	 directoryKCM= new PTCKCMObject(new DirectoryObject(new File(_value)));	 
	 
	 
 }
  
 
 
 public Entry getFileEntry () {
	 String targetFolderName =null;
	 if (fileEntry !=null) {
		 return fileEntry;
	 } else if (directoryEntry !=null) {
		 return directoryEntry;
	 } else return null;
	 
 }
 public   String getAttributeString() {
	 
	 
	 String targetFolderName =null;
	 if (directoryKCM !=null && directoryKCM.directoryObject !=null && directoryKCM.directoryObject.root !=null) {
		 System.out.println("getting directory root pointer:");
		 return  directoryKCM.directoryObject.root.toString();
	 } else 	 if (directoryKCM !=null && directoryKCM.directoryPointer !=null) {
		 System.out.println("\ngettingh attribute pointer");
		 return directoryKCM.directoryPointer.toString();
		 
	 } 
	 switch (typeEntry) { 
	 case PepMan.EntryType.STAGING:
		 return "<Staging>";
	 case PepMan.EntryType.TARGET:
			 return "<Target>";
	 case PepMan.EntryType.CLASSPATH:
		 if (pathName !=null) {
			 return pathName;
		 } else		 return "<Classpath>";				 
	 case PepMan.EntryType.DISTRIBUTE:
		 return "<Distribute>"; 
	 }
	 return null;
 }
 
 public String getDate() {
	 if (directoryKCM.directoryPointer ==null) {
		 return null;
		 	 
	 }
	 return new Date(directoryKCM.directoryPointer.lastModified()).toString();
	 
 }
 
 public FileObject getResourceFolderFiles(ClassLoader loader,FileObject fObj) throws PTCKCMException {
     FileObject fileObject=new FileObject();
	 try {
	 for (int i=0; i < fObj.fileList.size(); i++) {
		File f = fObj.fileList.get(i);
		String folder=f.toString();
		URL url = loader.getResource(folder);
		String path = url.getPath();		
		fileObject.setFileHeadString(path);	   
        fileObject.addBuffer(path);
	 }
	 return fileObject;
     
    
     } catch (NoClassDefFoundError ne) {
    	 System.err.println("\nClasspath needs to be set using -cp");
    	 throw new PTCKCMException("\nError: Classpath not set");
     }
    
 }
 public FileObject getResourceFolderFilesRoot(ClassLoader loader, FileObject _foList) {	 
	 _foList.fileRoot.listFiles(new FileFilterSh(FileFilterSh.FILE_T.DIRECTORY));
	 return _foList;
 }
 
 
 
 public boolean getResourceFolderRoot(String _folder) throws PTCKCMException {
	    ClassLoader loader = Thread.currentThread().getContextClassLoader();
	    FileObject fobj = new FileObject(_folder);
	    FileObject resourceFolderFile = getResourceFolderFilesRoot(loader,fobj);
	    return resourceFolderFile.bHasContent();
			//	 resourceFolderFile.processGTMLContent();
 }

private String getString(Path _p) throws IOException {
	StringBuffer sb= new StringBuffer();    
	FileReader fr = new FileReader(_p.toString());
	BufferedReader br = new BufferedReader(fr);
	String line=null;	
	while ( (line= br.readLine()) !=null) {
		sb.append(line);
		System.out.println("\nReadline line"+ line);
		
	}
	return sb.toString();
}
		

	
	

private void deciper(Path _p) throws IOException  {	
	for (int i=0; i < _p.getNameCount(); i++) {
		System.out.println("\nname count:"+ i+":"+_p.toString());
		System.out.println("\nparent "+ _p.getParent());
		System.out.println("\n");
		
	}
	//printFile(_p);
}

private final static String headerGTML = "gtml";



}


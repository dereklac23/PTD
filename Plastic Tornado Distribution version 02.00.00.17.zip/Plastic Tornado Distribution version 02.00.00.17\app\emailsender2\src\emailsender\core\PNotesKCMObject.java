package emailsender.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import emailsender.gui.Entry;
import emailsender.gui.Entry.EntryType;
import emailsender.tools.PNotesKCMException;

public class PNotesKCMObject implements Comparable <PNotesKCMObject>{
    public File directoryPointer=null;
    
    private final static String  PREFIX="(BASIC|CORE|HEADER)", KMP="KMP.war", StarShip ="StarShip.jar", 
    		DEV_ROOT="c:\\users\\derek\\eclipse-workspace\\dist\\lib";
    private File fileKMP, fileKonaWare;
    private String header=null;
    public Entry entryFacebook=null;
    public PNotesKCMObject targetDirectory=null;
    public DirectoryObject directoryObject=null;
	public BufferedReader bufferedReader = null;
	private String fileName=null;
	public String body=null;
	//public StringBuffer stringBuffer= new StringBuffer();
    public ArrayList<Entry> entryList  = new ArrayList<Entry>();
	public PNotesKCMObject(DirectoryObject _do) {
	 	directoryObject =  _do;
	}  
    public boolean bCoreType() {
    	return directoryObject.bCoreType();
    }
    private void addEntryTag(String _line)  throws PNotesKCMException {
    	if (directoryObject.getPrefix().equals("BASIC")) {
			entryList.add(new Entry(EntryType.BASIC, _line, directoryObject));
			} else if (directoryObject.getPrefix().equals("CORE")) {				
				entryList.add(new Entry(EntryType.CORE, _line, directoryObject));
			}
    	
    }
    public StringBuffer bodyBuffer =null;
    private void addEntryPlain(String _line) {
    	
    	bodyBuffer.append(_line);

    	
    }
    public boolean bDirectory=false;
    public int totalCount=0;
    
    
    public PNotesKCMObject(Path _path, int _runningCount) throws PNotesKCMException {
    	File file= _path.toFile();
    	
		Matcher matcher[] =new Matcher[4];
		fileName = file.getName();
		matcher [0] = compile("BASIC\\.(\\d+)\\.txt", file.getName());
		matcher [1] = compile("CORE\\.(\\d+)\\.txt", file.getName());
		matcher [2] = compile("HEADER\\.(\\d+)\\.txt", file.getName());
		matcher [3] = compile("facebooklist.(\\d+)\\.txt", file.getName());
		int i=0;
        while (directoryObject ==null && i < matcher.length) {
		if (matcher[i] !=null) {		
			
			directoryObject  = new DirectoryObject(file,PREFIX,matcher[i]);	
		}		
		
		i++;
        }
        if (directoryObject !=null) {
        directoryObject.matcher = matcher[i-1];
        
        } else {
        	throw new PNotesKCMException("Not of type BASIC, CORE, or HEADER for:"+ file.getName());
        }

		bodyBuffer = new StringBuffer();
		System.out.println(bodyBuffer);
		

		try {
	    	bufferedReader= new BufferedReader(new FileReader(file));
	    	
	    	if (directoryObject.isHeader()) {

				String line2=null;
				while ((line2=bufferedReader.readLine()) !=null) {
					
					if (line2.contains("@")) {
					addEntryTag(line2);
					tagCount++;
					} else {
					addEntryPlain(line2);	
					}
					
				}
				bufferedReader.close();
				bufferedReader=null;				
              
                
			}
			if (directoryObject.getPrefix().startsWith("HEADER")) {
				
				entryList.add(new Entry(EntryType.TWITTER_LINK, bodyBuffer));
			}

	    	
	    	} catch (IOException ioe) {
	    	  throw new PNotesKCMException ("\nError: File not found"+ _path.toFile().toString());
	    	}
		totalCount = _runningCount+tagCount;
	
	}
    public static Path resolveToPath(Path _root, String []_headStructure)  {
    	Path pathResolution=_root;
    	
    	if (_headStructure ==null) {
    		return _root.resolve(".");
    		
    		
    	} else {
    	for (int i=0;i < _headStructure.length; i++) {
    		pathResolution=pathResolution.resolve(_headStructure[i]);
    		
    			
    		}
    	}
    	
		return pathResolution;
		
		
	}
    public boolean bIsTag() {
    	return totalCount > 0;
    }

    
    public PNotesKCMObject(File root, String name) throws PNotesKCMException {
    	
		directoryPointer = new File(root, name);
		if (root.isDirectory()) {
			bDirectory=true;
			return;
		}
		
		Matcher matcher=compile(PREFIX+"\\.(\\d\\d\\d)\\.txt", name);
		directoryObject  = new DirectoryObject(directoryPointer,PREFIX,matcher);
		
		
		try {
	    	bufferedReader= new BufferedReader(new FileReader(directoryPointer));
	    	
	    	if (directoryObject.isHeader()) {
				StringBuffer headerBuffer = new StringBuffer();
				String line2=null;
				while ((line2=bufferedReader.readLine()) !=null) {
					headerBuffer.append(line2);
					
				}
				bufferedReader.close();
				bufferedReader=null;
                header=headerBuffer.toString();                
				
				
			}
	    	
	    	} catch (IOException ioe) {
	    	  throw new PNotesKCMException ("\nError: File not found"+ name);	
	    	}
	
	}
    public void Destory() throws PNotesKCMException {
    	try {
    	bufferedReader.close();
    	} catch (IOException ioe) {
    		throw new PNotesKCMException("\nError: Cannot close file");
    
    	}
    }
    public String getHeader() {
    	return header+"\n\n\n";
    	 
    }
    public  int groupCount=0, tagCount=0;
    
    public String getTagHeader() {
    	return "gc: " + tagCount;
    }
	public PNotesKCMObject(File root,  PNotesKCMObject kObj) {
		fileKMP = new File(root, KMP);
		fileKonaWare = new File(root, StarShip);
		targetDirectory = kObj;
		
	}
	

	
	
	public PNotesKCMObject () {
		directoryObject = new DirectoryObject();
	}
	
  
  
	private Matcher compile(String regex, String targetString) {		
		    Pattern pattern = Pattern.compile(regex);
		    Matcher matcher = pattern.matcher(targetString);		    
		    if (matcher.find()) {
		    	return matcher;
		        
		    }
		    return null;
		      
	}
	public int compare(PNotesKCMObject _o1, PNotesKCMObject _o2) {
		return _o1.directoryObject.fileDirectoryTarget.getName().compareTo(
		_o2.directoryObject.fileDirectoryTarget.getName());
		
	}
	public int compareTo(PNotesKCMObject o) {
		// TODO Auto-generated method stub
        if (o.directoryObject==null || o.directoryObject.fileDirectoryTarget ==null) {
        	return 0;
        }

		return fileName.compareTo(o.directoryObject.fileDirectoryTarget.getName());
	}
	


}
package emailsender.gui;

import java.awt.Point;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeExpansionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;

import emailsender.html.PNotesHTMLOutput;
import emailsender.html.PNotesTEXTOutput;
import emailsender.tools.PNotesKCMException;

public class EntryAdapter implements TreeSelectionListener, TreeExpansionListener {
   private PNotesHTMLOutput htmlOutput=null;
   private PNotesTEXTOutput textOutput=null;
   private JScrollPane scrollPane =null;
   private JScrollBar scrollBar=null;
   
   public Entry entryFacebook=null, entryTwitter=null;
	public EntryAdapter(PNotesHTMLOutput _htmlO) {
		htmlOutput = _htmlO;
	}
	public EntryAdapter(PNotesHTMLOutput _htmlO, JScrollPane _sPane) {
		htmlOutput = _htmlO;
		scrollPane = _sPane;
		scrollBar = scrollPane.getVerticalScrollBar();
	}

	public EntryAdapter(PNotesTEXTOutput _textO) {
		textOutput= _textO;
	}
	
	@Override
	public void valueChanged(TreeSelectionEvent e) {
		// TODO Auto-generated method stub
		  Entry entryChild=null;
          TreePath p = (TreePath)e.getPath();          
          Entry entry = (Entry)p.getLastPathComponent();
          if (entry.children !=null && entry.children.size() > 0) {
        	  entryChild = entry.children.get(0);
          }
        
           
          if (htmlOutput !=null) {
        	  try {
        	 	  entry.print(htmlOutput, entryChild);
        	 	  
        	  } catch (PNotesKCMException kcm) {
        		  System.err.println("JTree click print error:"+ kcm.toString());
        	  }
        	  
        	  
          } else if (textOutput !=null) {
        	  try {
        	  if ( entry.type == Entry.EntryType.GROUP && entryChild!=null) {
        		 

        	 
        	   if (entryChild.type == Entry.EntryType.GROUP) {
        		   
           	    String text=textOutput.extractFullReport(entry);
        	    textOutput.setText("Full report:"+text);
        	   } else if (entryChild.type == Entry.EntryType.BASIC ) {        		   
        	    String text=textOutput.extractBodyGroup(entry);        	   
                textOutput.setText("Group report:"+text);        	 
        	   }
        	   
        	 } else if (entry.type == Entry.EntryType.CORE && entry.children !=null && entryChild !=null 
        		         &&  entryChild.type == Entry.EntryType.TAG) {
        		   String text = textOutput.extractBodyGroup(entry);
                   textOutput.setText("Core:"+text);
        	     }  else if (entry.type == Entry.EntryType.TWITTER_LINK) {
            	  if (entry.bufferBody !=null && entry.bufferBody.length() > 20) {
		            textOutput.setText(entry.bufferBody.toString().substring(0, 20));
            	  }
	       } else if (entry.type == Entry.EntryType.TAG) {	    	   
	    	   
	    	   //textOutput.setText(entry.getName()+ textOutput.extractModuloInfo(entry));
	       }
        	  } catch (PNotesKCMException kcm) {
        		  System.err.println("Text report error:"+ kcm.toString());
        	  }
     }
        
	}
	
	
	
	

	@Override
	public void treeExpanded(TreeExpansionEvent event) {
		// TODO Auto-generated method stub
	
	}

	@Override
	public void treeCollapsed(TreeExpansionEvent event) {
		// TODO Auto-generated method stub
		System.out.println("\nTree collpase");
		
	}

}
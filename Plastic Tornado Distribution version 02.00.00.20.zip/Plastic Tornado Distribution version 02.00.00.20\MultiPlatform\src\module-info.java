module MultiPlatform {
        requires java.desktop;
 
        
        requires PTCommons;
        /*requires PepMan;*/
        
        requires java.xml;
        requires jdk.xml.dom;
		requires EmailSender;
		

}
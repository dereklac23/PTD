package multiplatform;

public class MPObject {
    protected String objectString="MPOJbect String";
	public MPObject() {
		
	}
	public String issueString() {
		return objectString;
	}
}

package multiplatform;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import mpdatamodel.SettingsEntry;
import mpdatamodel.SettingsModel;
import pttools.BookInfoUnit;
import pttools.BookUtil;
import ptdatamodel.FileEntry;
import pttools.LocalContainer;
import pttools.LocalInfoUtil;
import ptdatamodel.*;



public class MPPropertiesPage  extends JPanel {
	private static int WIDTH=600, HEIGHT=150;
	
	public SettingsModel tableModelSettings=null;
	//public BookPageModel tableModelBook=null;
	public JTable jTable;
	
	public ArrayList<SettingsEntry> pathList = new ArrayList<SettingsEntry>();
	public List<SettingsEntry> pathCollection=  Collections.synchronizedList(new ArrayList(pathList));
	
	
	
	public int indexPathList=0;
    public enum TYPE {SETTINGS, GTML, EMAIL_SENDER};
    public TYPE type=TYPE.SETTINGS;
    public AbstractTableModel abstractModel=null;
    public MPPropertiesPage(TYPE _t, int _w, int _h, AbstractTableModel _atm) {
    	WIDTH=_w;
    	HEIGHT=_h;
        type = _t;
       if (_t == TYPE.EMAIL_SENDER || _t == TYPE.SETTINGS) {
        	abstractModel= _atm;
        	jTable = new JTable(abstractModel);
        	
        } 
		JScrollPane scrollPane = new JScrollPane(
                jTable,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.getHorizontalScrollBar().setPreferredSize(new Dimension(	WIDTH+1600, 15));
		add(scrollPane);
		scrollPane.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		jTable.setPreferredScrollableViewportSize(new Dimension(WIDTH, HEIGHT));	
	    super.setPreferredSize(new Dimension(WIDTH, HEIGHT+50));

    }
    
    public MPPropertiesPage(TYPE _t) {
        type = _t;
        if (_t == TYPE.SETTINGS) {
             tableModelSettings=new SettingsModel(pathCollection);
        jTable  = new JTable(tableModelSettings);
        } else if (_t == TYPE.GTML){
        	
        }
    	
		JScrollPane scrollPane = new JScrollPane(
				
                jTable,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.getHorizontalScrollBar().setPreferredSize(new Dimension(	WIDTH+1600, 15));
		add(scrollPane);
		scrollPane.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		jTable.setPreferredScrollableViewportSize(new Dimension(WIDTH, HEIGHT));		

	    super.setPreferredSize(new Dimension(WIDTH, HEIGHT+50));
    }
    
    public void setLocalInfo(int _index) {
    	indexPathList = _index;
    }
    public void addLocalInfoUtil(SettingsEntry _lfo) {
    	pathCollection.add(_lfo);
    	
    }
    	
    }

	

	



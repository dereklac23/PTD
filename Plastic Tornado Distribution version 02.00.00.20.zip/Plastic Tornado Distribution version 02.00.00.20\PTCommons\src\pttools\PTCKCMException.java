package pttools;

public class PTCKCMException extends Exception {
    public String description=null;
	public PTCKCMException(String des) {
		description = des;
	}
	public String getString() {
		return description;
	}
	
}

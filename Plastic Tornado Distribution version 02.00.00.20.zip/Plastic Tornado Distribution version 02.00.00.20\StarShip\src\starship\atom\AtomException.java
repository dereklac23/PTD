package starship.atom;

import javax.swing.JTextArea;

public class AtomException extends Exception {
    private String errorMessage=null;
    private JTextArea jta=null;
    
	public AtomException (String _errormessage) {
		errorMessage = _errormessage;
	}
	
	public void print(JTextArea jta) {
		jta.append("\n"+errorMessage);
	}
}

package wepiano;
import java.util.Vector;

import javax.swing.ComboBoxModel;
import javax.swing.event.ListDataListener;

class MyTableModel implements ComboBoxModel<MidiStructure> {
		private MidiStructure itemPointer=null;
		Vector<MidiStructure> vectorList=null;
		public MyTableModel(Vector <MidiStructure> vec) {
			vectorList = vec;
		}

		@Override
		public int getSize() {
			// TODO Auto-generated method stub
			return vectorList.size();
		}

		@Override
		public MidiStructure getElementAt(int index) {
			
			// TODO Auto-generated method stub
			System.out.println("\n==selected index get element:"+index);
			MidiStructure midiS=vectorList.elementAt(index);
			return midiS;
		}

		@Override
		public void addListDataListener(ListDataListener l) {
			// TODO Auto-generated method stub
			 System.out.println("list listneer");
			
		}

		@Override
		public void removeListDataListener(ListDataListener l) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void setSelectedItem(Object anItem) {
			System.out.println("\n==set selected");
			// TODO Auto-generated method stub
			//System.out.println("\nSelected index"+ combo.getSelectedIndex());
			//itemPointer = (MidiStructure)anItem;
			//if (itemPointer !=null) {
			//System.out.println("\nselected"+itemPointer.getInfo());
			//}
			
		}

		@Override
		public Object getSelectedItem() {
			// TODO Auto-generated method stub
			
			MidiStructure midi = itemPointer;
			if (midi ==null) {
				System.err.println("\nselect item is null");
			}
			System.out.println("\n@@selected item");
			
//			return vector.get(combo.getSelectedIndex());
			return null;
			
		}
	
	
	   
	    
	    
	}

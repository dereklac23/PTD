package releasetool.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import releasetool.LocalContainer;
import releasetool.LocalInfoUtil;
import releasetool.PepMan;

public class ControlFrame extends JFrame {
    JPanel panelFrame=null;
    JTextArea taOutput=null;
    ArrayList<LocalInfoUtil>pathUtilList = null;
    private PropertiesPage propertiesPage=null;
    private CenterPanel centerPanel=null;
    private SouthPanel southPanel =null;
	private enum SP_TYPE {FIRE_TABLE, EXPAND_TREE};
	private SP_TYPE typeSP=SP_TYPE.FIRE_TABLE;
    public EntryTree eTree = null;
    
    
    private JTextField jtDirectory = new JTextField(35);
	private JButton btnSet= new JButton("Set");
	
	public ControlFrame(String _title, LocalContainer _lc) { 
			
			
		super(_title);
		pathUtilList = _lc.menuSettings.propertiesPage.pathList;
		
		setLayout(new BorderLayout());
		
		panelFrame= (JPanel) super.getContentPane();
		add(BorderLayout.NORTH,propertiesPage = new PropertiesPage());
		add(BorderLayout.CENTER,centerPanel = new CenterPanel());
		add(BorderLayout.SOUTH,southPanel = new SouthPanel());
		propertiesPage.setLocalInfo(pathUtilList);
		super.setSize(PepMan.WIDTH, PepMan.HEIGHT/2);				
		super.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		pack();		
	
		
	}
	
	private class CenterPanel extends JPanel  implements ActionListener{


		private final static int WIDTH_WEST=150; 
		private JPanel westPanel =null;
		private JButton buttonList[]  = new JButton[SP_TYPE.values().length];
		  
		CenterPanel() {
			super();
			setLayout(new BorderLayout());
			add(BorderLayout.CENTER, eTree= new EntryTree(getEntryTree()));
			
			
			add(BorderLayout.WEST, westPanel = new JPanel());
			
			
			
			
			westPanel.setAlignmentX(JPanel.LEFT_ALIGNMENT);
			westPanel.add(buttonList[SP_TYPE.FIRE_TABLE.ordinal()]= new
			                         JButton("Fire table update"));
			westPanel.add(buttonList[SP_TYPE.EXPAND_TREE.ordinal()]= new
					JButton("Expand tree"));
			westPanel.setPreferredSize(new Dimension(WIDTH_WEST,PepMan.HEIGHT/2));
			
			buttonList[SP_TYPE.FIRE_TABLE.ordinal()].addActionListener(this);

			
			for (int i=0; i < buttonList.length; i++) {
				buttonList[i].setSize(new Dimension(100,50));
			}
			
			
			eTree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
			DefaultMutableTreeNode root = new DefaultMutableTreeNode("Entry");		
			pathUtilList.forEach(entry->root.add(new DefaultMutableTreeNode(entry.getEntryName())));
			eTree.addTreeSelectionListener(new TreeSelectionListener() {
			    public void valueChanged(TreeSelectionEvent e) {
			        DefaultMutableTreeNode node = (DefaultMutableTreeNode)
			                           eTree.getLastSelectedPathComponent();

			    
			        if (node == null) return;
			        LocalInfoUtil liu = (LocalInfoUtil)node.getUserObject();
			        jtDirectory.setText(liu.getAttributeString());
			        

			   
			    }
			});
			
	        //add the child nodes to the root node
	        eTree.setPreferredSize(new Dimension(100, PepMan.HEIGHT/2));
	        add(eTree);
	         

			
		}
		
		public Entry getEntryTree() {
			Entry mRoot = new Entry(Entry.EntryType.STRING,"Entry");
			Entry kids[] = new Entry[2];
			Entry eRoot = new Entry(Entry.EntryType.STRING,"CLASSPATH");
			Entry fRoot = new Entry(Entry.EntryType.STRING,"Folder");
			
			kids[0]= eRoot;
			kids[1]= fRoot;
			
			Entry.linkFamily(mRoot, kids);
			
			for (int i=0; i < pathUtilList.size();i++) {
				LocalInfoUtil infoUtil = pathUtilList.get(i);
				
	//			Entry.addEntry(infoUtil.getFileEntry());
						
			}
			return eRoot;
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			propertiesPage.jTable.firePropertyChange(TOOL_TIP_TEXT_KEY, rootPaneCheckingEnabled, rootPaneCheckingEnabled);
			//eTree.pro
			
		}
		
	}
	
	private class SouthPanel extends JPanel implements ActionListener  {
		
		SouthPanel() {
			super();
			setLayout(new FlowLayout());
			add(new JLabel("Directory:"));
			add(jtDirectory);
			add(btnSet);
			btnSet.addActionListener(this);
		}
	//btnSet.a

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			LocalInfoUtil liu=null;
			for (int i=0; i < pathUtilList.size(); i++) {
			liu=pathUtilList.get(i);
			liu.setEntryName("newer name");
			}
			
			propertiesPage.tableModel.fireTableDataChanged();
			//propertiesPage.jTable.
		}
		
	}
	
public class EntryTree extends JTree {
    EntryModel model;
 
    public EntryTree( Entry _entryNode) {
        super(new EntryModel(_entryNode));
        getSelectionModel().setSelectionMode(
                TreeSelectionModel.SINGLE_TREE_SELECTION);
        //DefaultTreeCellRenderer renderer = new DefaultTreeCellRenderer();
        Icon personIcon = null;
        //renderer.setLeafIcon(personIcon);
        //renderer.setClosedIcon(personIcon);
        //renderer.setOpenIcon(personIcon);
        setCellRenderer(new CustomTreeRenderer());
    }
     
    
    /**
     * Get the selected item in the tree, and call showAncestor with this
     * item on the model.
     */
    public void showAncestor(boolean b) {
        Object newRoot = null;
        TreePath path = getSelectionModel().getSelectionPath();
        if (path != null) {
            newRoot = path.getLastPathComponent();
        }
       ((EntryModel)getModel()).showAncestor(b, newRoot);
    }

   }



}
package releasetool.gui;
import java.awt.Component;

import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

public class CustomTreeRenderer extends  DefaultTreeCellRenderer {


	public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        // Call the superclass method to get the default renderer component
		System.out.println("\nTree cell render");
	
        Component component = super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);

        // Customize the appearance of the node
        if (leaf) {
            
        } else if (expanded) {
            
        } else {
            
        }

        return component;
    }
}
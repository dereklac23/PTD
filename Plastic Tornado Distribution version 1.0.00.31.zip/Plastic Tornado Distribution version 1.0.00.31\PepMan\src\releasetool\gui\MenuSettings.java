package releasetool.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import releasetool.LocalContainer;
import releasetool.LocalInfoUtil;
import releasetool.PepMan;



public class MenuSettings extends JPanel implements MenuInterface{
	  	
	  private String htmlIndexPage=null;
	  private LocalContainer localContainer=null;
	  ArrayList <ButtonSelection> btnList = null;
	  public PropertiesPage propertiesPage=null;

      private JButton btnSet= new JButton("Open up Configuration");
      
      private SouthPanelSetting southPanel=null;
      private ArrayList<LocalInfoUtil> pathUtilList = null;
      HTMLOutput editor2= null;
      private JFrame mainFrame=null;
      private JLabel lbNodeSelected=null;
      private JTextField tfSelectedNode=null;
      public ControlFrame controlFrame = null;
      public MenuSettings (ArrayList <ButtonSelection> _listSetting, JFrame _mainFrame) {
    		 
    setLayout(new BorderLayout());
    add(BorderLayout.NORTH,propertiesPage=new PropertiesPage());
        propertiesPage.setVisible(true);
        pathUtilList = propertiesPage.pathList;
	    editor2= new HTMLOutput();
	    editor2.setSize(new Dimension(PepMan.WIDTH-PepMan.OFFSET,PepMan.HEIGHT-PepMan.OFFSET*16));
	    editor2.setContentType("text/html");
	    editor2.attachHeader();		
	    editor2.attachP("This is a settings page.");
	    editor2.attachP("Configure the local directory for stage directory to be copied to $Plastic Tornado Distribution.");
	    editor2.attachP("Type: Folder");
	    editor2.attachP("Configure the directory for loading issuing ClassLoader#getResourceStream for packaged jar resource.");
	    editor2.attachP("Type: Jar bundled resource");
	    editor2.attachP("Configure the directory for loading issuing ClassLoader#getResourceFolder sandbox local resource.");
	    editor2.attachP("Type: Folder:");
		editor2.attachEnder();
		editor2.printPage();
	    add(BorderLayout.CENTER, editor2);
	    add(BorderLayout.SOUTH,southPanel = new SouthPanelSetting());

	    
	
	
	 
 }
	public class HCustomListener implements HyperlinkListener {

		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			
			// TODO Auto-generated method stub
			
		}
	
	}
	
	private class SouthPanelSetting extends JPanel implements ActionListener  {
		
		SouthPanelSetting() {
			super();
			setLayout(new FlowLayout());
			add(new JLabel("Selected Node:"));
			add(tfSelectedNode= new JTextField(30));
			tfSelectedNode.setEditable(false);
			add(btnSet);
			btnSet.addActionListener(this);
		}


		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
          //pullSelectedIndex();
			/*
			if (liuPointer==null) {
				return;
			}
			*/
			/*
			File selectedFile=null;
			 JFileChooser chooser = new JFileChooser();
			 chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		        chooser.setCurrentDirectory(new File("."));
		        chooser.setMultiSelectionEnabled(true);
		        int option = chooser.showOpenDialog(mainFrame);

		        if (option == JFileChooser.APPROVE_OPTION) 
		            selectedFile = chooser.getSelectedFile();
		      */  
                //liuPointer.setAttributeFile(selectedFile);
			 /*
					editor2.attachHeader();
				editor2.attachP("Node Entry: " + liuPointer.getEntryName());
				editor2.attachP("Category:" + liuPointer.getCategory());
				editor2.attachP("File directory:" + liuPointer.getFileEntry().getName());
				editor2.attachP("Date"+ liuPointer.getDate());				
				editor2.attachEnder();
				editor2.printPage();				
				editor2.repaint();
				*/
			//	super.validate();
			//
			controlFrame.setVisible(true);
			propertiesPage.tableModel.fireTableDataChanged();
			

			
            			

		}
		
	}
	private LocalInfoUtil liuPointer=null;
	public void pullSelectedIndex() {
		int iSelected = propertiesPage.jTable.getSelectedRow();
		if (iSelected >=0 && iSelected < pathUtilList.size()) {
			
			LocalInfoUtil  liu = (LocalInfoUtil)pathUtilList.get(iSelected);
			liuPointer = liu;
			tfSelectedNode.setText(liu.getEntryName());
			editor2.attachHeader();
			editor2.attachP("Entry:" + liu.getEntryName());
			editor2.attachP("Category:" + liu.getCategory());
			if (liu.getFileString() !=null) {
				editor2.attachP("File attribute:" + liu.getFileEntry().getName());
			}
			editor2.attachP("Date"+ liu.getDate());
			editor2.attachEnder();
			editor2.printPage();				
			editor2.repaint();
			super.validate();
			liuPointer = liu;
			//controlFrame.setVisible(true);
			//controlFrame.setVisible(true);
			/*
			if (liu.getCategory().equals("CLASSPATH")) {
				btnSet.setEnabled(false);
			} else {
				btnSet.setEnabled(true);
			} */
			
			propertiesPage.tableModel.fireTableDataChanged();	
		} else {
			
		}
		


	}

}

package releasetool.gui;



import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import releasetool.LocalContainer;
import releasetool.LocalInfoUtil;


public class PropertiesPage  extends JPanel {
	private static int WIDTH=600, HEIGHT=150;
	
	public SettingPageModel tableModel=null;
	public JTable jTable;

	public ArrayList<LocalInfoUtil> pathList =null;

    public PropertiesPage() {
        
        tableModel=new SettingPageModel();
    	jTable  = new JTable(tableModel);
		JScrollPane scrollPane = new JScrollPane(
                jTable,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		
		
		scrollPane.getHorizontalScrollBar().setPreferredSize(new Dimension(	WIDTH+1600, 15));
				
		add(scrollPane);
		scrollPane.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		jTable.setPreferredScrollableViewportSize(new Dimension(WIDTH, HEIGHT));
		
		jTable.setDefaultRenderer(JLabel.class, new SettingsRenderer());
		jTable.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		
		
		Enumeration e = jTable.getColumnModel().getColumns();
	    
	    pathList = new ArrayList<LocalInfoUtil>();
	    
	    jTable.getModel().addTableModelListener(new ComboListener());
	    
	   
	    super.setPreferredSize(new Dimension(WIDTH, HEIGHT+50));
    }
    public void setLocalInfo(ArrayList<LocalInfoUtil> _pathList) {
    	synchronized (jTable) {
    		pathList = _pathList;
    	}
    }
    public void addLocalInfoUtil(LocalInfoUtil _lfo) {
    	pathList.add(_lfo);
    	
    }
	
    public void updateData(String _entryName, String _category, String _data) {
    	for (int i = 0; i < pathList.size(); i++ ) {
    		LocalInfoUtil localInfo =(LocalInfoUtil)pathList.get(i);	
    		if (localInfo.getEntryName().equals("CLASSPATH") && 
    				localInfo.getCategory().equals(_category)) {
    			localInfo.updateFileString(_data);
    			
    		}
    	}
    	
    	

    	
    }
	class SettingPageModel extends AbstractTableModel {
	    private String[] columnNames = {"Entry", "Category", "File Attributes", "Date", "Annotations"};
	    

	    public int getColumnCount() {
	        return columnNames.length;
	    }

	    public int getRowCount() {
	        return pathList.size();
	    }

	    public String getColumnName(int col) {
	        return columnNames[col];
	    }

	    public Object getValueAt(int row, int col) {
	    	synchronized (jTable) {
	    		
	    	}
	    	LocalInfoUtil pUtil = pathList.get(row);
	    	switch (col) {
	    	case 0: return pUtil.getEntryName();
	    	case 1: return pUtil.getCategory();
	    	case 2: return pUtil.getAttributeString();	    	
	    	case 3: return pUtil.getDate().toString();
	    	}
	    	
	        return null;
	    }

	   
	    /*
	     * Don't need to implement this method unless your table's
	     * editable.
	     */
	    public boolean isCellEditable(int row, int col) {
	    
	        return (col ==2);
	        
	    }

	    public void setValueAt(Object value, int row, int column) {
	        
	        fireTableCellUpdated(row, column);
	    }
	}

	class SettingsRenderer extends JLabel implements TableCellRenderer {
		 
	    public SettingsRenderer()
	    {
	        super.setOpaque(true);
	    }
	     
	    @Override
	    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
	        boolean hasFocus, int row, int column)
	    {
	    	System.out.println("cell rendcerer");
	    	if (isSelected) {
	    		System.out.println("is selcted");
	    	}
	        String label= (String) value;
	        setText(value.toString()+"33");
	        if(label == "X Pos") {
	            super.setBackground(Color.GREEN);
	        }  else {
	        	super.setBackground(Color.PINK);
	        }
	        
	         
	        return this;
	    }
	     
	}
	
	public LocalInfoUtil getInfo(String _entryName, String _categoryName) {
		
		for (int i=0; i < pathList.size(); i++) {
			LocalInfoUtil localInfo = pathList.get(i);
			if (localInfo.getEntryName().equals(_entryName) && localInfo.getCategory().equals(_categoryName)) {
				return localInfo;
			}
		}
		return null;
		
	}
	
	private class CustomSelectionModel implements TableModelListener {

		@Override
		public void tableChanged(TableModelEvent e) {
			// TODO Auto-generated method stub
			
		}
		
	}
}

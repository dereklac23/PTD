package releasetool;

import javax.swing.JComboBox;
import javax.swing.JFrame;

import releasetool.gui.ButtonSelection;
import releasetool.gui.ControlFrame;
import releasetool.gui.MenuSettings;



public class LocalContainer {
	private JComboBox jCombo=null;
    public LocalInfoUtil pathSet[]= null;
    public JComboBox<ButtonSelection> comboPointerGTML=null;
    public ControlFrame controlFrame=null;
    
    
    public MenuSettings menuSettings=null;
  

	public LocalContainer(LocalInfoUtil _path[], MenuSettings _menu) {			
		pathSet = _path;
		
		controlFrame = new ControlFrame("Configuration", this);
		menuSettings= _menu;
		menuSettings.controlFrame= controlFrame;
		controlFrame.propertiesPage = menuSettings.propertiesPage;
		
		
		
	}
	
}

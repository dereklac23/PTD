package releasetool.gui;
import releasetool.*;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

import releasetool.PepMan;

public class ComboRenderer extends JLabel
                           implements ListCellRenderer {
        
        private PepMan releaseTool=null;
        private ArrayList<ButtonSelection> comboInitial= null;
        public ComboRenderer(PepMan rT, ArrayList<ButtonSelection> _combI) {
            setOpaque(true);
            setHorizontalAlignment(CENTER);
            setVerticalAlignment(CENTER);
            releaseTool = rT;
            comboInitial= _combI;
        }
        
 
        /*
         * This method finds the image and text corresponding
         * to the selected value and returns the label, set up
         * to display the text and image.
         */
        public Component getListCellRendererComponent(
                                           JList list,
                                           Object value,
                                           int index,
                                           boolean isSelected,
                                           boolean cellHasFocus) {
         
        	
        	ButtonSelection bSelect = (ButtonSelection)value;
        	releaseTool.selectPointer=bSelect;
        	setText(bSelect.getLabel());
 
            if (isSelected) {
                setBackground(list.getSelectionBackground());
            	//setBackground(Color.pink);
                setForeground(list.getSelectionForeground());
            } else {
                setBackground(list.getBackground());
                setForeground(list.getForeground());
            }
           
            if (bSelect !=null) {
            //setText("selected");
            //setText(bSelect.getLabel());
            }
 
            return this;
        }
 
     

		
    }
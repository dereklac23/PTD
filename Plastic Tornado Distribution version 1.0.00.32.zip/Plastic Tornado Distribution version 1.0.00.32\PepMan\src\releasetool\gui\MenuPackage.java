package releasetool.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.event.*;

import releasetool.PepMan;
import releasetool.PepMan.PANEL_TYPE;

import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class MenuPackage extends JPanel implements MenuInterface {
	  ArrayList <ButtonSelection> btnList = null;
	  private HTMLOutput editor2;
 	public MenuPackage(PanelStruct panelS, JComboBox<ButtonSelection> _comboPointer, ArrayList<ButtonSelection> btnPackageList) {
		btnList = btnPackageList;
		add(BorderLayout.NORTH, editor2= new HTMLOutput());
		
		editor2.setContentType("text/html");
		
		editor2.addHyperlinkListener(new HCustomListener());
		editor2.setPreferredSize(new Dimension(PepMan.WIDTH-PepMan.OFFSET,PepMan.HEIGHT-PepMan.OFFSET));
        editor2.attachHeader();
		
		editor2.attachP("Welcome to the Distribution page!");		
		editor2.attachP("This is also the page to load up GTML as bundled jar to the Public Realm." );
		
		editor2.attachEnder();
		editor2.printPage();
			
		}
		//editorHtml.removeh
		
		
	
	
	public class HCustomListener implements HyperlinkListener {

		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			System.out.println("Event entered");
			// TODO Auto-generated method stub
			
		}
	
	}


	

}

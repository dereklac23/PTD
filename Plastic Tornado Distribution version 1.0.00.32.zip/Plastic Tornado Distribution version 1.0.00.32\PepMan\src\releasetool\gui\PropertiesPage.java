package releasetool.gui;



import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;


import releasetool.LocalContainer;
import releasetool.LocalInfoUtil;


public class PropertiesPage  extends JPanel {
	private static int WIDTH=600, HEIGHT=150;
	
	public SettingPageModel tableModel=null;
	public JTable jTable;
	public ArrayList<LocalInfoUtil> pathList = new ArrayList<LocalInfoUtil>();
	public List<LocalInfoUtil> pathCollection=  Collections.synchronizedList(new ArrayList(pathList));
	public int indexPathList=0;

    public PropertiesPage() {
        
        tableModel=new SettingPageModel(pathCollection);
    	jTable  = new JTable(tableModel);
		JScrollPane scrollPane = new JScrollPane(
                jTable,
				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		
		
		scrollPane.getHorizontalScrollBar().setPreferredSize(new Dimension(	WIDTH+1600, 15));
				
		add(scrollPane);
		scrollPane.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		jTable.setPreferredScrollableViewportSize(new Dimension(WIDTH, HEIGHT));
		
		jTable.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		
		
		Enumeration e = jTable.getColumnModel().getColumns();
	    

	    
	    //jTable.getModel().addTableModelListener(new ComboListener());
	    
	   
	    super.setPreferredSize(new Dimension(WIDTH, HEIGHT+50));
    }
    
    public void setLocalInfo(int _index) {
    	indexPathList = _index;
    }
    public void addLocalInfoUtil(LocalInfoUtil _lfo) {
    	pathCollection.add(_lfo);
    	
    }
	/*
    public void updateData(String _entryName, String _category, String _data) {
    	for (int i = 0; i < pathList.size(); i++ ) {
    		LocalInfoUtil localInfo =(LocalInfoUtil)pathList.get(i);	
    		if (localInfo.getEntryName().equals("CLASSPATH") && 
    				localInfo.getCategory().equals(_category)) {
    			localInfo.updateFileString(_data);
    			
    		}
    	}
    	
    	
*/
    	
    }
	class SettingPageModel extends AbstractTableModel {
	    private String[] columnNames = {"Entry", "Category", "File Attributes", "Date", "Annotations"};
	    private List<LocalInfoUtil> pathPageCollection=null;
       public SettingPageModel(List<LocalInfoUtil>_liu) {
    	   pathPageCollection=_liu;
       }
	    public int getColumnCount() {
	        return columnNames.length;
	    }

	    public int getRowCount() {
	        return  pathPageCollection.size();
	    }

	    public String getColumnName(int col) {
	        return columnNames[col];
	    }

	    public Object getValueAt(int row, int col) {
    	LocalInfoUtil pUtil = pathPageCollection.get(row);
	    	
	    	switch (col) {
	    	case 0: return pUtil.getEntryName();
	    	case 1: return pUtil.getCategory();
	    	case 2: 
	    		Entry e =pUtil.getFileEntry(); 
	    		if (e ==null && pUtil.getCategory().equals("Folder")) {
	    			return "<FILE>";    					
	    					
	    		} else if (e == null && pUtil.getCategory().equals("CLASSPATH")) {
	    			return "<PATH.ENTRY>";
	    		} else {
	    			return e.toString();
	    		}
	    	case 3:
	    		if (pUtil.getCategory().equals("CLASSPATH")) {
	    			return null;
	    		} else if (pUtil.getDate() ==null) {
	    			return null;
	    		}else    		
	    		return pUtil.getDate().toString();
	    		}
	    	
	    	
	        return null;
	    }

	   
	    /*
	     * Don't need to implement this method unless your table's
	     * editable.
	     */
	    public boolean isCellEditable(int row, int col) {
	    
	        return (col ==2);
	        
	    }

	    public void setValueAt(Object value, int row, int column) {
	        
	        fireTableCellUpdated(row, column);
	    }
	}

	class SettingsRenderer extends JLabel implements TableCellRenderer {
		 
	    public SettingsRenderer()
	    {
	        super.setOpaque(true);
	    }
	     
	    @Override
	    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
	        boolean hasFocus, int row, int column)
	    {
	    	System.out.println("\n@@@^^cell rendcerer");
	    	if (isSelected) {
	    		System.out.println("is selcted");
	    	}
	        String label= (String) value;
	        setText(value.toString()+"33");
	        if(label == "X Pos") {
	            super.setBackground(Color.GREEN);
	        }  else {
	        	super.setBackground(Color.PINK);
	        }
	        
	         
	        return this;
	    }
	}     
	
	

	
	class CustomSelectionModel implements TableModelListener {

		@Override
	public void tableChanged(TableModelEvent e) {

			
			// TODO Auto-generated method stub
			
		}
		
	}
	



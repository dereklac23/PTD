package releasetool.gui;

import java.util.ArrayList;

import releasetool.PepMan;
import releasetool.PepMan.PANEL_TYPE;

public interface ComboSelection {
    public static PanelStruct panelStruct[]= new PanelStruct [PepMan.PANEL_TYPE.values().length];
    
    
    
    
    
    public abstract void addButtonSelection(PepMan.PANEL_TYPE _type, String _label, String _description);



		
	
}

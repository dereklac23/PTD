package releasetool.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import releasetool.BookInfoUnit;
import releasetool.BookUtil;
import releasetool.ChapterInfoUnit;
import releasetool.GeneralUnit;
import releasetool.LocalInfoUtil;
import releasetool.PageInfoUnit;
import releasetool.PepMan;
import releasetool.gui.MenuPackage.HCustomListener;

public class MenuGTML extends JPanel implements MenuInterface , ActionListener{
	private ArrayList<ButtonSelection> btnList = new ArrayList<ButtonSelection>();
	public HTMLOutput editorMain=null;
	private JComboBox<ButtonSelection> comboPointer=null;
	private JButton btnBook = null;
	  public PopupFrame controlFrame=null;
	  public PropertiesPage propertiesPage=null;
	  public List<LocalInfoUtil> pathCollection=  null;

	
	public MenuGTML(PanelStruct panelS, JComboBox<ButtonSelection> _comboPointer, ArrayList<ButtonSelection> btnPackageList) {
		btnList = btnPackageList;
		btnBook = new JButton("Open Book Rendering Dialog");
		comboPointer  = _comboPointer;
		setLayout(new BorderLayout());
		add(BorderLayout.NORTH, propertiesPage = new PropertiesPage(PropertiesPage.TYPE.GTML));		
		add(BorderLayout.CENTER, editorMain= new HTMLOutput());
		add(BorderLayout.SOUTH, btnBook);
		btnBook.addActionListener(this);
		
		editorMain.setContentType("text/html");
		
		editorMain.addHyperlinkListener(new HCustomListener());
		editorMain.setPreferredSize(new Dimension(PepMan.WIDTH-PepMan.OFFSET,PepMan.HEIGHT/2-PepMan.OFFSET));
		editorMain.attachHeader();
		
		editorMain.attachP("Welcome to the GTML page!");
		editorMain.attachP("Create your books, chapters, and pages using GTML.");
		editorMain.attachP("Your imagination starts at the 'gtml' directory as a bundled jar files and or local sandboxed files." );
		
		editorMain.attachEnder();
		editorMain.printPage(); 
			
		}
		//editorHtml.removeh
	
	
	private String getTag(String _tag, String _value) {
		StringBuffer sb = new StringBuffer();
		sb.append("<p>");
		sb.append("<" + _tag + ">");
		sb.append("<"+_value+">");
		sb.append("</p>");
		
		return sb.toString();
		
	}
	private String getTagRaw(String _tag, String _value) {
		StringBuffer sb = new StringBuffer();
		
		sb.append("<" + _tag + ">");
		sb.append("<"+_value+">");
		
		
		return sb.toString();
		
	}
	
	public void renderEntry(ChapterInfoUnit _cu) {
		if (_cu==null) {
			return;
		}
		StringBuffer sb = new StringBuffer();
		if (_cu.root!=null) {
		sb.append(getTag("root",_cu.root.getParent()));
		}
	
		if (_cu.header !=null) {
		sb.append(getTag("header",_cu.header));
		}
		if (_cu.body!=null) {
			sb.append(getTag("body",_cu.body));
			}
		
		editorMain.attachRaw(sb.toString());
		
	}
	

	public void renderEntry(PageInfoUnit _pu) {
		if (_pu==null) {
			return;
		}
		StringBuffer sb = new StringBuffer();
		if (_pu.root!=null) {
		sb.append(getTag("root",_pu.root.getParent()));
		}
	
		if (_pu.header !=null) {
		sb.append(getTag("header",_pu.header));
		}
		if (_pu.body!=null) {
			sb.append(getTag("body",_pu.body));
			}
		
		editorMain.attachRaw(sb.toString());
		
	}

	public void renderEntry(BookInfoUnit _bu) {
		if (_bu==null) {
			return;
		}
		StringBuffer sb = new StringBuffer();
		if (_bu.root!=null) {
		sb.append(getTag("root",_bu.root.getParent()));
		}
	
		if (_bu.header !=null) {
		sb.append(getTag("header",_bu.header));
		}
		if (_bu.body!=null) {
			sb.append(getTag("body",_bu.body));
			}
		
		editorMain.attachRaw(sb.toString());
		
	}
		
		
		
		
	
		
	
		
	public void resetCombo() {
		comboPointer.removeAllItems();
		btnList.forEach(btnS->comboPointer.addItem(btnS));
	}
	
	public class HCustomListener implements HyperlinkListener {

		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			
			// TODO Auto-generated method stub
			
		}
	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		controlFrame.setVisible(true);
	}
	@Override
	public PopupFrame allocate(PopupFrame _control) {
		// TODO Auto-generated method stub
		controlFrame = _control;
		controlFrame.propertiesPage = propertiesPage;
		return _control;
	}
	public void updatePointer(List<BookInfoUnit> allBooksSync) {
		synchronized (propertiesPage) {
		propertiesPage.bookCollection.clear();
		
		for (int i=0; i < allBooksSync.size();i++) {
			propertiesPage.bookCollection.add(allBooksSync.get(i));			
		}
		}
		propertiesPage.tableModelBook.fireTableDataChanged();
		//propertiesPage.fire
	}
}

	




package releasetool.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import releasetool.PepMan;
import releasetool.gui.MenuPackage.HCustomListener;

public class MenuHelp extends JPanel implements MenuInterface {
	private HTMLOutput editor2=null;
	private ArrayList<ButtonSelection> btnList = new ArrayList<ButtonSelection>();
	public MenuHelp(PanelStruct panelS, JComboBox<ButtonSelection> _comboPointer, ArrayList<ButtonSelection> btnPackageList) {
		btnList = btnPackageList;
		add(BorderLayout.NORTH, editor2= new HTMLOutput());
		
		String workingDirectory = System.getProperty("user.dir");
		editor2.setContentType("text/html");		
		editor2.addHyperlinkListener(new HCustomListener());
		editor2.setPreferredSize(new Dimension(PepMan.WIDTH-PepMan.OFFSET,PepMan.HEIGHT-PepMan.OFFSET));
		editor2.attachHeader();
		
		editor2.attachP("GTML load page.");
		editor2.attachP("The 'gtml' directory package   is destinated to be in the working directory--"+workingDirectory+".");
		
		
		editor2.attachEnder();
		editor2.printPage();
			
		}
		//editorHtml.removeh
		
		
	
	
	public class HCustomListener implements HyperlinkListener {

		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			System.out.println("Event entered");
			// TODO Auto-generated method stub
			
		}
	
	}




	@Override
	public PopupFrame allocate(PopupFrame _control) {
		// TODO Auto-generated method stub
		return null;
	}
}

	




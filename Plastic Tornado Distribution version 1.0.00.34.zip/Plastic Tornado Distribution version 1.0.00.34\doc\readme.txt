There are two ways to launch the client (called KonaWare Client) and dynamic web service called KMP.

The installation instructions are located in $KCMD/doc/release.

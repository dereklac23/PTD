package releasetool.gui;

public interface MenuInterface {
	//public HTMLOutput editor=new HTMLOutput();

	//public abstract void printBody(String _body);
	  public abstract PopupFrameSettings allocate(PopupFrameSettings _control);
	  public abstract PopupFrameGtml allocate(PopupFrameGtml _control);
}

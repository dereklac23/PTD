package releasetool.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import releasetool.LocalContainer;
import releasetool.LocalInfoUtil;
import releasetool.PepMan;



public class MenuSettings extends JPanel implements MenuInterface {
	  	
	  private String htmlIndexPage=null;
	  private LocalContainer localContainer=null;
	  ArrayList <ButtonSelection> btnList = null;


      private JButton btnSet= new JButton("Open up Configuration");
      
      private SouthPanelSetting southPanel=null;
      //private ArrayList<LocalInfoUtil> pathUtilList = null;
      public List<LocalInfoUtil> pathCollection=  null;
      private 
      HTMLOutput editor2= null;
      private JFrame mainFrame=null;
      private JLabel lbNodeSelected=null;
      private JTextField tfSelectedNode=null;
      
      public PopupFrameSettings controlFrame=null;
      public PropertiesPage propertiesPage=null;
      
      public MenuSettings (ArrayList <ButtonSelection> _listSetting, JFrame _mainFrame) {
    		 
    	  
    	 //Important!!! controlFrame is set as a reference pointer in PathExec.doExec routine
    	 //its resource is allocated in LocalInfoUtil using the allocate method and not a constructor.
    setLayout(new BorderLayout());
    add(BorderLayout.NORTH,propertiesPage=new PropertiesPage(PropertiesPage.TYPE.SETTINGS));
        pathCollection = propertiesPage.pathCollection;
        propertiesPage.setVisible(true);
	    editor2= new HTMLOutput();
	    editor2.setSize(new Dimension(PepMan.WIDTH-PepMan.OFFSET,PepMan.HEIGHT-PepMan.OFFSET*16));
	    editor2.setContentType("text/html");
	    editor2.attachHeader();		
	    editor2.attachP("This is a settings page.");
	    editor2.attachP("Configure the local directory for stage directory to be copied to $Plastic Tornado Distribution.");
	    editor2.attachP("Type: Folder");
	    editor2.attachP("Configure the directory for loading issuing ClassLoader#getResourceStream for packaged jar resource.");
	    editor2.attachP("Type: Jar bundled resource");
	    editor2.attachP("Configure the directory for loading issuing ClassLoader#getResourceFolder sandbox local resource.");
	    editor2.attachP("Type: Folder:");
		editor2.attachEnder();
		editor2.printPage();
	    add(BorderLayout.CENTER, editor2);
	    add(BorderLayout.SOUTH,southPanel = new SouthPanelSetting());

	    
	
	
	 
 }
	public class HCustomListener implements HyperlinkListener {

		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			
			// TODO Auto-generated method stub
			
		}
	
	}
	
	private class SouthPanelSetting extends JPanel implements ActionListener  {
		
		SouthPanelSetting() {
			super();
			setLayout(new FlowLayout());
			add(new JLabel("Selected Node:"));
			add(tfSelectedNode= new JTextField(30));
			tfSelectedNode.setEditable(false);
			add(btnSet);
			btnSet.addActionListener(this);
		}


		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			propertiesPage.tableModelSettings.fireTableDataChanged();
			controlFrame.setVisible(true);
			

			
            			

		}
		
	}
	private LocalInfoUtil liuPointer=null;
	public void pullSelectedIndex() {
		int iSelected = propertiesPage.jTable.getSelectedRow();
		System.out.println("size:"+pathCollection.size());
		if (iSelected >=0 && iSelected < pathCollection.size()) {
			
			LocalInfoUtil  liu = (LocalInfoUtil)pathCollection.get(iSelected);
			
			tfSelectedNode.setText(liu.getEntryName());
			editor2.attachHeader();
			editor2.attachP("Entry:" + liu.getEntryName());
			editor2.attachP("Category:" + liu.getCategory());
			if (liu.getFileEntry() !=null) {
				editor2.attachP("Path entry:" + liu.getFileEntry().toString());
			}
			if (liu.getDate() !=null) {
			editor2.attachP("Date:"+ liu.getDate());
			}
			editor2.attachEnder();
			editor2.printPage();				
			editor2.repaint();
			super.validate();
			liuPointer = liu;
			controlFrame.setLIUPointer(liu);
			
			//controlFrame.setVisible(true);
			propertiesPage.tableModelSettings.fireTableDataChanged();	
		} else {
			
		}
		


	}
	

	public PopupFrameSettings allocate(PopupFrameSettings _control) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public PopupFrameGtml allocate(PopupFrameGtml _control) {
		// TODO Auto-generated method stub
		return null;
	}


}

package releasetool.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import releasetool.BookInfoUnit;
import releasetool.ChapterInfoUnit;
import releasetool.GeneralUnit;
import releasetool.LocalContainer;
import releasetool.LocalInfoUtil;
import releasetool.PageInfoUnit;
import releasetool.PepMan;

public class PopupFrameGtml extends JFrame {
    JPanel panelFrame=null;
    JTextArea taOutput=null;
    int pathUtilIndex= 0;
    //private PropertiesPage propertiesPage=null;
    //private Collections<PathUtil>
    private CenterPanel centerPanel=null;
    private SouthPanel southPanel =null;
	private enum SP_TYPE {FIRE_TABLE, EXPAND_TREE};
	private SP_TYPE typeSP=SP_TYPE.FIRE_TABLE;
    public EntryTree eTree = null;
	public  Entry mRoot=null;
	EntryModel model;
    
    public enum TYPE {SETTINGS,BOOK};
    public TYPE type= TYPE.SETTINGS;
    
    private JTextField jtDirectory = new JTextField(35);
	private JButton btnSet= new JButton("Set");
	public PropertiesPage propertiesPage=null;
	public PopupFrameGtml(String _title, LocalContainer _lc) {
		super(_title);
		
		setLayout(new BorderLayout());
		panelFrame= (JPanel) super.getContentPane();
		add(BorderLayout.CENTER,centerPanel = new CenterPanel());
		add(BorderLayout.SOUTH,southPanel = new SouthPanel(this));
		super.setSize(PepMan.WIDTH, PepMan.HEIGHT/2);				
		super.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		pack();		
	
		
	}
	
	private String getNullHandler(String _nullCase, Entry _e) {
		if (_e ==null) {
			return _nullCase;
		} else if (_e.getName()==null) {
			return _nullCase;
		} else return _e.getName(); 		
	}
	private LocalInfoUtil liuPointer=null;
	public void setLIUPointer(LocalInfoUtil _liu) {

		liuPointer = _liu;
		EntryModel eModel= (EntryModel)eTree.getModel();
		
		Entry entryRoot =(Entry)eTree.getModel().getRoot();
	 	entryRoot.children.removeAllElements();	 	
	 	entryRoot.children.add(new Entry(Entry.EntryType.STRING, _liu.getEntryName()));
		entryRoot.children.add(new Entry(Entry.EntryType.STRING,   getNullHandler("<File>", _liu.getFileEntry())));
		if (_liu.getDate() !=null) {
			entryRoot.children.add(new Entry(Entry.EntryType.STRING, _liu.getDate()));
		}
	 	Entry fileEntry = _liu.getFileEntry();
	 	if (fileEntry !=null && fileEntry.getName()!=null) {
		 	mRoot.children.add(new Entry(Entry.EntryType.FILE, fileEntry.getName()));
		 	} else {
	 		mRoot.children.add(new Entry(Entry.EntryType.STRING, "<File String>"));
	 		
	 	}
	 	mRoot.children.add(new Entry(Entry.EntryType.STRING, _liu.getDate()));	
	 	eModel.fireTreeStructureChanged(entryRoot);
	 	
	}
	  ArrayList<BookInfoUnit> allBooks = new ArrayList<BookInfoUnit>();
      List<BookInfoUnit> allBooksSync = Collections.synchronizedList(new ArrayList(allBooks));
      
      ArrayList<PageInfoUnit> allPages= new ArrayList<PageInfoUnit>();
      List<PageInfoUnit> allPagesSync = Collections.synchronizedList(new ArrayList(allPages));
      
      ArrayList<ChapterInfoUnit> allChapters= new ArrayList<ChapterInfoUnit>();
      List<ChapterInfoUnit> allChaptersSync = Collections.synchronizedList(new ArrayList(allChapters));
    
    public  void populateTree(List<BookInfoUnit>_allBooksSync) {
	    EntryModel eModel= (EntryModel)eTree.getModel();
		
		Entry entryRoot =(Entry)eTree.getModel().getRoot();
	 	entryRoot.children.removeAllElements();	 	
	 	for (int i=0; i < allBooksSync.size();i++) {
	 		
	 	BookInfoUnit biu = _allBooksSync.get(i);
	 	if (biu.getValue() !=null) {
	 	entryRoot.children.add(new Entry(Entry.EntryType.STRING, biu.getValue()));
	 	}
	 	}
		//entryRoot.children.add(new Entry(Entry.EntryType.STRING, _value2));
		eModel.fireTreeStructureChanged(entryRoot);
    }
	public void updatePointer(List<BookInfoUnit>_allBooksSync, List<ChapterInfoUnit> _allChaptersSync,List<PageInfoUnit>_allPagesSync  ) {
		
        		 
		populateListBooks(_allBooksSync, allBooksSync);
		populateListChapters(_allChaptersSync, allChaptersSync);
		populateListPages(_allPagesSync, allPagesSync);
		populateTree(allBooksSync);
		//model.fireTreeStructureChanged(entryRoot);
		//propertiesPage.tableModelSettings.fireTableDataChanged();
	}
	
	
	private void populateListBooks(List<BookInfoUnit> _source, List<BookInfoUnit> _target) {
		_target.clear();
		for (int i=0; i < _source.size(); i++) {
			_target.add(_source.get(i));
		}
	}
	
	private void populateListChapters(List<ChapterInfoUnit> _source, List<ChapterInfoUnit> _target) {
		_target.clear();
		for (int i=0; i < _source.size(); i++) {
			_target.add(_source.get(i));
		}
	}
	private void populateListPages(List<PageInfoUnit> _source, List<PageInfoUnit> _target) {
		_target.clear();
		for (int i=0; i < _source.size(); i++) {
			_target.add(_source.get(i));
		}
	}
	private class CenterPanel extends JPanel  implements ActionListener{


		private final static int WIDTH_WEST=150; 
		private JPanel westPanel =null;
		private JButton buttonList[]  = new JButton[SP_TYPE.values().length];
		  
		CenterPanel() {
			super();
			setLayout(new BorderLayout());
			add(BorderLayout.CENTER, eTree= new EntryTree(getEntryTree()));
			add(BorderLayout.WEST, westPanel = new JPanel());
			westPanel.setAlignmentX(JPanel.LEFT_ALIGNMENT);
			westPanel.add(buttonList[SP_TYPE.FIRE_TABLE.ordinal()]= new
			                         JButton("Refresh"));
			westPanel.setPreferredSize(new Dimension(WIDTH_WEST,PepMan.HEIGHT/2));
			buttonList[SP_TYPE.FIRE_TABLE.ordinal()].addActionListener(this);
			for (int i=0; i < buttonList.length-1; i++) {
				buttonList[i].setSize(new Dimension(100,50));
			}			
	        eTree.setPreferredSize(new Dimension(100, PepMan.HEIGHT/2));
	        add(eTree);
			
		}
		
	

		public Entry getEntryTree() {
			mRoot = new Entry(Entry.EntryType.STRING,"Entry-->");
			Entry kids[] = new Entry[2];
			Entry  eRoot=new Entry(Entry.EntryType.STRING,"Book:");
			Entry fRoot = new Entry(Entry.EntryType.STRING,"Folder");
			
			kids[0]= eRoot;
			kids[1]= fRoot;
			
			Entry.linkFamily(mRoot, kids);
			pathUtilIndex=0;
			
			return eRoot;
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			TreeModel tModel = eTree.getModel();
			Entry entryRoot =(Entry)eTree.getModel().getRoot();
			//populateTree("Value 1", "Value 2");
			
			
		}
		
	}
	
	private class SouthPanel extends JPanel implements ActionListener  {
		JFrame parent=null;
		SouthPanel(JFrame _parent) {
			super();
			parent = _parent;
			setLayout(new FlowLayout());
			add(new JLabel("Directory:"));
			add(jtDirectory);
			add(btnSet);
			btnSet.addActionListener(this);
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			if (liuPointer ==null) {
				return;
			}
			synchronized (liuPointer) {
			File selectedFile=null;
			 JFileChooser chooser = new JFileChooser();
			 chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		        chooser.setCurrentDirectory(new File("."));
		        chooser.setMultiSelectionEnabled(true);
		        int option = chooser.showOpenDialog(this);
		        if (option == JFileChooser.APPROVE_OPTION) { 
		        	selectedFile = chooser.getSelectedFile();
		        }
		        if (selectedFile !=null) {
		       
		        liuPointer.setAttributeFile(selectedFile);
		        parent.setVisible(false);
		        EntryModel eModel= (EntryModel)eTree.getModel();
		        eModel.fireTreeStructureChanged(mRoot);
		        if (type == TYPE.SETTINGS) {
		        	propertiesPage.tableModelSettings.fireTableDataChanged();
		        } else if (type == TYPE.BOOK) {
		            propertiesPage.tableModelBook.fireTableDataChanged();
		        }
		        }
		        //propertiesPage.fir
			};
			
		}
		
	}
	
public class EntryTree extends JTree {
    
 
    public EntryTree( Entry _entryNode) {
        super(model=new EntryModel(_entryNode));
        getSelectionModel().setSelectionMode(
                TreeSelectionModel.SINGLE_TREE_SELECTION);
        
        Icon personIcon = null;
        //renderer.setLeafIcon(personIcon);
        //renderer.setClosedIcon(personIcon);
        //renderer.setOpenIcon(personIcon);
        setCellRenderer(new CustomTreeRenderer());
    }
     
    
    /**
     * Get the selected item in the tree, and call showAncestor with this
     * item on the model.
     */
    public void showAncestor(boolean b) {
        Object newRoot = null;
        TreePath path = getSelectionModel().getSelectionPath();
        if (path != null) {
            newRoot = path.getLastPathComponent();
        }
       ((EntryModel)getModel()).showAncestor(b, newRoot);
    }

   }



}
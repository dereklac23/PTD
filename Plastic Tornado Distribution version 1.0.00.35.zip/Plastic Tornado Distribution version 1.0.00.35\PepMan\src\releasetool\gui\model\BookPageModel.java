package releasetool.gui.model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import releasetool.BookInfoUnit;
import releasetool.BookUtil;
import releasetool.LocalInfoUtil;
import releasetool.gui.Entry;

public class BookPageModel extends AbstractTableModel {
    private String[] columnNames = {"Book", "Author First Name","Author Last Name", "Publish date", "Category", "Volume", "Series"};
    private List<BookInfoUnit> bookPageCollection=null;
   public BookPageModel(List<BookInfoUnit>_liu) {
	   bookPageCollection=_liu;
   }
    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
    	
        return  bookPageCollection.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Object getValueAt(int row, int col) {
    	
    	BookInfoUnit bUtil = bookPageCollection.get(row);
//    	System.out.println("\nRetrieving values"+bUtil);
    	if (bUtil ==null) {
    	 return null;   	
        } else return bUtil.getValue();
    }
   
    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {	    
        return (col ==2);	        
    }

    public void setValueAt(Object value, int row, int column) {	        
        fireTableCellUpdated(row, column);
    }
}




package releasetool.gui.model;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import releasetool.LocalInfoUtil;
import releasetool.gui.Entry;

public class SettingPageModel extends AbstractTableModel {
    private String[] columnNames = {"Entry", "Category", "File Attributes", "Date", "Annotations"};
    private List<LocalInfoUtil> pathPageCollection=null;
   public SettingPageModel(List<LocalInfoUtil>_liu) {
	   pathPageCollection=_liu;
   }
    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return  pathPageCollection.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Object getValueAt(int row, int col) {
	LocalInfoUtil pUtil = pathPageCollection.get(row);	    	
    	switch (col) {
    	case 0: return pUtil.getEntryName();
    	case 1: return pUtil.getCategory();
    	case 2: 
    		Entry e =pUtil.getFileEntry(); 
    		if (e ==null && pUtil.getCategory().equals("Folder")) {
    			return "<FILE>";    						    					
    		} else if (e == null && pUtil.getCategory().equals("CLASSPATH")) {
    			return "<PATH.ENTRY>";
    		} else {
    			return e.toString();
    		}
    	case 3:
    		if (pUtil.getCategory().equals("CLASSPATH")) {
    			return null;
    		} else if (pUtil.getDate() ==null) {
    			return null;
    		}else    		
    		return pUtil.getDate().toString();
    		}
    	
    	
        return null;
    }

   
    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {	    
        return (col ==2);	        
    }

    public void setValueAt(Object value, int row, int column) {	        
        fireTableCellUpdated(row, column);
    }
}




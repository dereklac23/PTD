package releasetool;

import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;



public class BookInfoUnit implements GeneralUnit {
	
	public File root=null;
	
	public Path path=null;
	public String body=null;
	
	public String authorFirstName, authorLastName, publishDate, category, bookTitle, tagLine, volume, series;
	public enum TYPE {
		AUTHOR_FIRST_NAME, 
		AUTHOR_LAST_NAME, 
		PUBLISH_DATE, 
		CREATION_DATE, 
		CATEGORY, 
		BOOK_TITLE, 
		TAG_LINE, 
		VOLUME, 
		SERIES};
	private final static String prefix ="/Book";
	public String []TYPE_STRING= {
			"/Author/@FirstName", 
			"/Author/@LastName",
			"/Publish/@Date", 
			"/Creation/@Date", 
			"/Category/@Name", 
			"/Title/@Value", 
			"/Tagline/@Value", 
			"/Volume/@Value", 
			"/Series/@Value"};
	private int ordinalValue=0;
	public BookInfoUnit infoUnit[] = new BookInfoUnit[TYPE.values().length];
	public ArrayList<BookInfoUnit> listOfBooks = new ArrayList<BookInfoUnit>();
	
	
	public String nameTag = null;
	public String value=null;
	public int ordinalPointer=0;
	public HashMap<String, BookInfoUnit> bookMap = new HashMap<String, BookInfoUnit>();
	public BookInfoUnit(String _nameTag) {
		nameTag = _nameTag;
	}
	public BookInfoUnit(File _root,Path _p) {
		root=_root;

		path = _p;
		load();
	}
	
	
	public BookInfoUnit(File _root, String _body) {
        
		root=_root;
		body = _body;		
		
	}
	
		
	
	public BookInfoUnit(int _ordinal) {
		
		ordinalPointer = _ordinal;
	  //infoUnit[_ordinal] = new BookInfoUnit(TYPE_STRING[_ordinal]);	  
	  
	}
	public String getTag() {
		//System.out.println("\nTag of ordinar"+ ordinalPointer);
		return prefix+TYPE_STRING[ordinalPointer];
	}
	public String getValue() {
		//System.out.println("\nGetting value:"+ ordinalPointer +":"+TYPE_STRING[ordinalPointer]);
		
		BookInfoUnit biu= bookMap.get(TYPE_STRING[ordinalPointer]);
		if (biu ==null) {
			return null;
		} else if (biu.getValue()==null){
			return null;
		} else {
			
			return biu.getValue();
		}
	}
	
   public void add(BookInfoUnit _biu) {
	   bookMap.put(_biu.getTag(), _biu);
   }
	
   public String getEntry (int _index) {
	   System.out.println("\nget entry"+ _index +":"+ listOfBooks.size());
	   if (_index < listOfBooks.size()) {
		   return listOfBooks.get(_index).getValue();   
	   }
	   return null;
	   
   }
   
	private void load() {
		for (int i=0; i < TYPE.values().length; i++) {
			//System.out.println("\nadding units for parsing");
			listOfBooks.add(new BookInfoUnit(i));
		}
	}

	
}

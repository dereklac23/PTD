package releasetool;

import javax.swing.JComboBox;
import javax.swing.JFrame;

import releasetool.gui.ButtonSelection;
import releasetool.gui.PopupFrameSettings;
import releasetool.gui.PopupFrameGtml;
import releasetool.gui.MenuGTML;
import releasetool.gui.MenuInterface;
import releasetool.gui.MenuSettings;



public class LocalContainer {
	private JComboBox jCombo=null;
    public LocalInfoUtil pathSet[]= null;
    public JComboBox<ButtonSelection> comboPointerGTML=null;
    public PopupFrameSettings controlFrameSettings=null;
    
    
    public MenuSettings menuSettings=null;
    public MenuGTML menuGTML=null;
  

    private PopupFrameSettings allocateSettings(String _title, MenuInterface _menu) {
    	//The properties page is allocated into MenuSetting's constructor.
    	PopupFrameSettings controlFrame = null;
    		controlFrame =new PopupFrameSettings(PopupFrameSettings.TYPE.SETTINGS,"Configuration:"+_title, this);
    	   MenuSettings menuSettingsArgument = (MenuSettings)_menu;
    	  controlFrame.propertiesPage= menuSettingsArgument.propertiesPage;
    return controlFrame;	
    }
    
    private PopupFrameGtml allocateGtml(String _title, MenuGTML _menu) {
    		
    		PopupFrameGtml controlFrame =new PopupFrameGtml("Book Rendering:"+_title, this);
    		System.out.println("\nbook rendeiring");
    		MenuGTML menuGTMLArgument = (MenuGTML)_menu;
    		
				
		return controlFrame;
    }
	public LocalContainer(LocalInfoUtil _path[], MenuSettings _menuSettings, MenuGTML _menuGTML) {			
		pathSet = _path;
		//_menu.controlFrame= controlFrame;
		menuSettings = _menuSettings;
		menuSettings= (MenuSettings)_menuSettings;
		
		menuSettings.controlFrame=allocateSettings("Settings",_menuSettings);
		//menuSettings.pathCollection = menuSettings.controlFrame.propertiesPage.pathCollection;		
				
		menuGTML =_menuGTML;		
		//menuGTML.propertiesPage=menuSettings.controlFrame.propertiesPage; 
		menuGTML.popupGtml=allocateGtml("Books Rendering",_menuGTML);
		
		
				
		
	
	}
	
}

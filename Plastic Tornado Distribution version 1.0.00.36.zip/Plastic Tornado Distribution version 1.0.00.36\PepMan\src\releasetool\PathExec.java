package releasetool;

import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import releasetool.PepMan.PANEL_TYPE;
import releasetool.gui.ButtonSelection;
import releasetool.gui.ButtonSelection.BSTypeDistribution;
import releasetool.gui.PopupFrameSettings;
import releasetool.gui.HTMLOutput;
import releasetool.gui.MenuGTML;
import releasetool.gui.MenuSettings;


public class PathExec implements SeafloorExec {
    
	private LocalInfoUtil pathSet[]=null;
    private LocalContainer localContainer;
    private MenuGTML menuGTML =null;
	public PathExec(LocalContainer _lc) {
		localContainer = _lc;
			System.out.println("\npath exec");
	}
	public PathExec() {
		super();
									
	}
    private JPanel controlPanel = null;
	@Override
	public void doExecute(SeafloorExec.ATTR _attr, LocalInfoUtil _infoUtil) {
		
		ArrayList<LocalInfoUtil> pathList =localContainer.menuSettings.propertiesPage.pathList;
		if (_attr == SeafloorExec.ATTR.ENODE_ENTRY) {
			System.out.println("Provisioning control frame");
			synchronized (localContainer) {
			MenuSettings menuSettings = localContainer.menuSettings;			
				
			menuSettings.pullSelectedIndex();
			}
		   
			
			
		    
		    
			} 
		}
		  
		 
	
		
	
	@Override
	public void doExecute(LocalContainer _lc, LEVEL _level, TYPE _type, ATTR _attr) {
		// TODO Auto-generated method stub
		
	}


	   private void printBodyGreeting(HTMLOutput _hOutput) {
			  
		    _hOutput.attachP("<p>Resource loaded successfully:<p>");
		    _hOutput.attachRaw("<table><thead><tr><th>Type</th></tr></thead>");
		    _hOutput.attachRaw("<tbody>");
		    _hOutput.attachRaw("<tr><td>Resource loaded from Working Directory with root being 'gtml':");
		    _hOutput.attachURL("gtml", "'gtml' from Working Directory");
		    
		    _hOutput.addHyperlinkListener(new HCustomListener());
		    _hOutput.attachRaw("</td></tr>");
		    _hOutput.attachRaw("<tr><td>Load resource stream from Classpath.</td></tr>");
		    _hOutput.attachRaw("<tr><td>Load from Classpath.</td></tr>");
		    _hOutput.attachRaw("<tr><td>Currently the active head of the bundled jar file is 'gtml'");
		    _hOutput.attachRaw("</table>");
		    
		
		    if (pathSet !=null && pathSet[2] !=null) {
		    	  
		    MenuGTML menuG=(MenuGTML)pathSet[2].menuInterface;		    
		    localContainer.comboPointerGTML.removeAllItems();  
		    
		    localContainer.comboPointerGTML.addItem(new ButtonSelection(ButtonSelection.BSTypeDistribution.LOAD_GTML,
		    		ButtonSelection.BSTypeSettings.CLASSPATH,"Load gtml from local harddisk with -CLASSPATH Option"));
		    localContainer.comboPointerGTML.revalidate();
		    }
		    		
	   }
	   
	   
	   
		@Override
		public void doExecute( ATTR _attr, ButtonSelection.BSTypeSettings _bSettings) throws KCMException {
			// TODO Auto-generated method stub
		
			
		}
		


	public class HCustomListener implements HyperlinkListener {

		@Override
		public void hyperlinkUpdate(HyperlinkEvent e) {
			
			// TODO Auto-generated method stub
			
		}
	
	}



	@Override
	public void doExecute(BSTypeDistribution _typeD, LocalInfoUtil _liu) {
		// TODO Auto-generated method stub
		if (_typeD == BSTypeDistribution.LOAD_GTML) {
			Entry entry = _liu.getFileEntry();
			
			String entryName = _liu.getEntryName();	
			System.out.println("\n local container"+localContainer.pathSet[4].getEntryName());
			try {
			if (entryName.equals(localContainer.pathSet[2].getEntryName())) {
				
			

			 localContainer.pathSet[2].loadGTML();
				
				return;
			} else 	if (entryName.equals(localContainer.pathSet[3].getEntryName())) {
				System.out.println("\nLoading gtml for gtml");
				localContainer.pathSet[3].loadGTML();
				
			} 
			} catch (KCMException kcm) {
				
				localContainer.menuGTML.editorMain.attachHeader();
				localContainer.menuGTML.editorMain.attachP("Error in loading gtml in working directory. Please copy a sample in $(Plastic Tornado Distribution)/doc directory");
				localContainer.menuGTML.editorMain.attachEnder();
				localContainer.menuGTML.editorMain.printPage();
				
			}
		} 
	}
}




	
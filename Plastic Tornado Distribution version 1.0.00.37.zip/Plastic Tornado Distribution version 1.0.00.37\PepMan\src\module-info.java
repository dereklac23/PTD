/**
 * 
 */
/**
 * 
 */
module ReleaseTool {
	requires java.desktop;
}
package releasetool.gui.datamodel;


import java.util.List;

import javax.swing.table.AbstractTableModel;

import releasetool.BookInfoUnit;
import releasetool.BookUtil;
import releasetool.Entry;
import releasetool.FileEntry;
import releasetool.LocalInfoUtil;
/*
 * 	private final static String prefix ="/Book";
	public String []TYPE_STRING= {
			"/Author/@FirstName", 
			"/Author/@LastName",
			"/Publish/@Date", 
			"/Creation/@Date", 
			"/Category/@Name", 
			"/Title/@Value", 
			"/Tagline/@Value", 
			"/Volume/@Value", 
			"/Series/@Value"};
	private int ordinalValue=0;
 */
public class BookPageModel extends AbstractTableModel {
    private String[] columnNames = {
    		
    		"Author First Name",
    		"Author Last Name", 
    		"Publish date",
    		"Creation date",
    		"Category",
    		"Title",
    		"Tagline",    		
    		"Volume", 
    		"Series"};
    private List<FileEntry> bookPageCollection=null;
   public BookPageModel(List<FileEntry>_liu) {
	   bookPageCollection=_liu;
   }
    public int getColumnCount() {
        return columnNames.length;
    }
 
    public int getRowCount() {
    	
        return  bookPageCollection.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Object getValueAt(int row, int col) {
    	
    	FileEntry fEntry= bookPageCollection.get(row);

    	if (fEntry==null) {
    	 return null;   	
        } else return fEntry.getEntry(col);
    }
   
    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {	    
        return (col ==2);	        
    }

    public void setValueAt(Object value, int row, int column) {	        
        fireTableCellUpdated(row, column);
    }
}




package releasetool;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileEntry {
    private Path path=null;
    private String fileName=null;	
    private final static String ALPANUMERIC_Group = "([a-zA-Z0-9]+)";
    private final static String NUMERIC_Group = "([0-9]+)";
    public final  static String BOOK=
    		"(BOOK|Book)\\."+
            ALPANUMERIC_Group+"\\."+
            NUMERIC_Group+
        "\\.xml";
    public final  static String CHAPTER=
            "(CHAPTER|Chapter)\\."+
            ALPANUMERIC_Group+"\\."+
            NUMERIC_Group+
        "\\.html";


    public final  static String PAGE=
    		"(PAGE|Page)\\."+
            ALPANUMERIC_Group+"\\."+
            NUMERIC_Group+
            "\\.html";
   

    
     

    public String type = null;
    public List<BookInfoUnit> attributeList=null;
    public PageInfoUnit piu = null;
    public void setAttributes(List<BookInfoUnit> _attList) {
    	synchronized (this) {
    	attributeList=_attList;
    	}
    }
    public String tagString[] = new String[2];

    protected Matcher matcher=null;
    public boolean bMatched=false;
    
    protected FileEntry() {
    	tagString = new String[tagString.length];
    	
    }
    public String getName() {
    	return tagString[0];
    }
    public StringBuffer body = new StringBuffer(5024);
    int  ordinalPointer=0;
    protected boolean compile(String _regex, String _fileName) throws KCMException {
    	Pattern  pattern = Pattern.compile(_regex); 
		 matcher = pattern.matcher(fileName);	
		if (matcher.groupCount() == 0) {
			
           throw new KCMException("Error: internal compile regex does not match.");
			
		}
		ordinalPointer=0;
		while (matcher.find()) {
			tagString[ordinalPointer] = matcher.group();		 
			//body.append(tagString[ordinalPointer]);
			bMatched=true;
			ordinalPointer++;
		
        } 
		return ordinalPointer > 0;
    }
        
	public FileEntry(Path _p) throws KCMException {
		new FileEntry();
		//typeString = _type;
		Pattern  pattern=null;
		path=_p;
		fileName=path.getFileName().toString();
		if (compile(BOOK, fileName)) {
			type = BOOK;
	//		BookUtil bu = new BookUtil();
			
		} else if (compile (CHAPTER, fileName)) {
			type = CHAPTER;
		} else if (compile(PAGE, fileName)) {
			type = PAGE;
			try {
			BufferedReader br = new BufferedReader(new FileReader(_p.toString()));
			String line=null;
			while ((line =br.readLine())!=null) {
				body.append(line);
			}
			br.close();
			
			} catch (FileNotFoundException fne) {
				throw new KCMException ("Error: file not found");
			} catch (IOException ioe) {
				throw new KCMException ("Error: Cannot read into buffer");
			}
			
		}
		
	}
	private final static String returnGeneralError = "<p>Error: The file naming convention for Book has to be (BOOK|Book).UNIQUE-ID.([0-9])+"
			+ "\\.xml. </p>"+		
  "<p>For example: 'BOOK.OralHistory.0001.xml.'</p>" +
  "<p>The file naming convention for Chapter has to be (CHAPTER|Chapter).UNIQUE-ID.([0-9])+"
	+ "\\.xml. </p>"+
"<p>For example: 'CHAPTER.OralHistory.0001.xml.The unique identify UNIQUE-ID has to match of ones of CHAPTER.</p>"+
"<p>The file naming convention for Page has to be (PAGE|Page).UNIQUE-ID.([0-9])+"
+ ".xml. </p>"+
"<p>For example: 'PAGE.OralHistory.0001.xml'. The unique identify UNIQUE-ID has to match of ones of BOOK.</p>";
	
			
	public String getEntry(int _index) {
		
		if (attributeList !=null && _index < (attributeList.size())) {
			//System.out.println("\nnew index"+ newIndex1+":"+_index+":"+biuList.size());
			synchronized (this) {
		   BookInfoUnit biu1 = attributeList.get(_index);
			return attributeList.get(_index).value;
			}
		} else {
			return "";
		}
		
		
	}
	public String getString() {
		if (bMatched) return body.toString();
		else if (type !=null &&type.equals(BOOK) && (fileName.contains("Book") || fileName.contains("BOOK"))) {
			return "Error for:<" + fileName
					+ ">. The file naming convention for Book has to be (BOOK|Book)_UNIQUE-ID_([0-9])+"
					+ "_\\.xml. "+
		  "For example: 'BOOK_OralHistory_0001.xml.'";
				
		}else if (type != null && type.equals(CHAPTER) && (fileName.contains("Chapter") || fileName.contains("CHAPTER"))) {
			return "Error for: <" + fileName +">.The file naming convention for Chapter has to be (CHAPTER|Chapter)_UNIQUE-ID_([0-9])+"
					+ "_\\.html. "+
		  "For example: 'CHAPTER_OralHistory_0001.xml.'. The unique identify UNIQUE-ID has to match of ones of CHAPTER.";
		}else if (type!=null && type.equals(PAGE) && (fileName.contains("Page") ||  fileName.contains("PAGE"))) {
			return "Error for:<" + fileName +".>The file naming convention for Page has to be (PAGE|Page)_UNIQUE-ID_([0-9])+"
					+ "_\\.html. "+
		  "For example: 'PAGE_OralHistory_0001.html'. The unique identify UNIQUE-ID has to match of ones of BOOK.";
		}
		return "Error for: <"+fileName+">"+ returnGeneralError;
	}
}

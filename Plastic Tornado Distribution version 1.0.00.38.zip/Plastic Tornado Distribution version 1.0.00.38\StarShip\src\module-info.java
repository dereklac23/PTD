/**
 * 
 */
/**
 * 
 */
module starship5 {
	requires java.desktop;
}
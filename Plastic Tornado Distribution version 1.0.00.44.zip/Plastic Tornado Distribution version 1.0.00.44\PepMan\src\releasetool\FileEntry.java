package releasetool;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileEntry {
    private Path path=null;
    private String fileName=null;	
    private final static String ALPANUMERIC_Group = "([a-zA-Z0-9]+)";
    private final static String NUMERIC_Group = "([0-9]+)";
    
    public final  static String BOOK=
    		"(BOOK|Book)\\."+
            ALPANUMERIC_Group+"\\."+
            NUMERIC_Group+
        "\\.xml";
        
    /*
    public final  static String BOOK=
    		"(BOOK|Book)\\.([a-zA-Z0-9]+).";
            
      */  
    public final  static String CHAPTER=
            "(CHAPTER|Chapter)\\."+
            ALPANUMERIC_Group+"\\."+
            NUMERIC_Group+
        "\\.xml";


    public final  static String PAGE=
    		"(PAGE|Page)\\."+
            ALPANUMERIC_Group+"\\."+
            NUMERIC_Group+
            "\\.html";
   

    
     

    public String type = null;
    public List<BookInfoUnit> attributeBookList=null;
    public List<ChapterInfoUnit>attributeChapterList=null;
    public PageInfoUnit piu = null;
    public void setBookAttributes(List<BookInfoUnit> _attList) {
    	synchronized (this) {
    	attributeBookList=_attList;
    	}
    }
    public void setChapterAttributes(List<ChapterInfoUnit> _attList) {
    	synchronized (this) {
    	attributeChapterList=_attList;
    	}
    }

    public String tagString[] = new String[2];

    protected Matcher matcher=null;
    public boolean bMatched=false;
    
    protected FileEntry() {
    	tagString = new String[tagString.length];
    	
    }
   
    public String getTagSplit(int _index) {
    	if (_index >= tagStringSplitList.length) {
    		return "";
    	}
    	else if (tagStringSplitList[_index] !=null) {
    		return tagStringSplitList[_index];
    	} else return "";
    }
    private String extractSplit(String _target) {
    	
    	String returnSplit[] =_target.split("\\.");
    	if (returnSplit.length >= 1) {    	
    		return returnSplit[0];
    	}
    	return _target;
    }
    private String [] extractSplitList(String _target) {
    	
          return _target.split("\\.");

    }
   
    public String getName() {
       if (tagString[1]!=null) {
    		return tagString[1];
    	} else if (tagString[0]!=null) {
    		//return extractSplit(tagString[0]);
    		return tagStringSplitList[0];
    	}
    	return "Content:";
    }
    public StringBuffer body = new StringBuffer(5024);
    public int  ordinalPointer=0;
    public String tagStringSplitList[]=null;
    protected boolean compile(String _regex, String _fileName) throws KCMException {
    	Pattern  pattern = Pattern.compile(_regex); 
		 matcher = pattern.matcher(fileName);	
		if (matcher.groupCount() == 0) {
			
           throw new KCMException("Error: internal compile regex does not match.");
			
		}
		ordinalPointer=0;
		matcher.reset();
		
		//extractGroup()
		while (matcher.find()) {
			tagString[ordinalPointer] = matcher.group(ordinalPointer);
			bMatched=true;
			ordinalPointer++;
		
        } 

		if (tagString[0] !=null) {

		//tagStringSplit = extractSplit(tagString[0]);
		tagStringSplitList = extractSplitList(tagString[0]);
		}
				
		return ordinalPointer > 0;
    }
    
   
    private String extractGroup(int _index, Matcher _targetMatcher) {
    	return  _targetMatcher.group(_index);
    	
    }
        
	public FileEntry(Path _p) throws KCMException {
		new FileEntry();
		//typeString = _type;
		Pattern  pattern=null;
		path=_p;
		fileName=path.getFileName().toString();
		if (compile(BOOK, fileName)) {
			type = BOOK;
		} else if (compile (CHAPTER, fileName)) {
			type = CHAPTER;
		} else if (compile(PAGE, fileName)) {
			type = PAGE;
			try {
			BufferedReader br = new BufferedReader(new FileReader(_p.toString()));
			String line=null;
			while ((line =br.readLine())!=null) {
				body.append(line);
			}
			br.close();
			
			} catch (FileNotFoundException fne) {
				throw new KCMException ("Error: file not found");
			} catch (IOException ioe) {
				throw new KCMException ("Error: Cannot read into buffer");
			}
			
		}
		
	}
	private final static String returnGeneralError = "<p>Error: The file naming convention for Book has to be (BOOK|Book).UNIQUE-ID.([0-9])+"
			+ "\\.xml. </p>"+		
  "<p>For example: 'BOOK.OralHistory.0001.xml.'</p>" +
  "<p>The file naming convention for Chapter has to be (CHAPTER|Chapter).UNIQUE-ID.([0-9])+"
	+ "\\.xml. </p>"+
"<p>For example: 'CHAPTER.OralHistory.0001.xml.The unique identify UNIQUE-ID has to match of ones of CHAPTER.</p>"+
"<p>The file naming convention for Page has to be (PAGE|Page).UNIQUE-ID.([0-9])+"
+ ".xml. </p>"+
"<p>For example: 'PAGE.OralHistory.0001.xml'. The unique identify UNIQUE-ID has to match of ones of BOOK.</p>";
	
	

	public String getPageEntry() {
		if (piu !=null && piu.body !=null) {
		return piu.body.toString();
		} else {
			return null;
		}
	}
	public String getBookEntry(int _index) {	
//		System.out.println("\nGetting book entry with index at:"+_index);
		if (attributeBookList !=null && _index < (attributeBookList.size())) {
			synchronized (this) {
		   BookInfoUnit biu1 = attributeBookList.get(_index);
			return attributeBookList.get(_index).value;
			}
		} else {
			return null;
		}
		
	}
	public String getHeadTag(int _hIndex) {
		switch (_hIndex) {
		case 1: return "<h1>";
		case 2: return "<h2>";
		case 3: return "<h3>";
		case 4: return "<h4>";
		case 5: return "<h5>";
		case 6: return "<h6>";
			
		}
		return "<h1>";
	}
	public String getTailTag(int _hIndex) {
		switch (_hIndex) {
		case 1: return "</h1>";
		case 2: return "</h2>";
		case 3: return "</h3>";
		case 4: return "</h4>";
		case 5: return "</h5>";
		case 6: return "</h6>";
			
		}
		return "</h1>";
	}
	public String getChapterEntry(int _index) {

		if (attributeChapterList ==null) {
		return null;				
		}
		if (attributeChapterList.size () > 1 && _index ==0) {
			return attributeChapterList.get(0).chapterString;
		}
        synchronized (this) {
        	for (int i=0; i < attributeChapterList.size();i++) {
        		System.out.println("\nget chapter entry"+i);
	    	   ChapterInfoUnit ciu1 = attributeChapterList.get(i);
	    	   if (ciu1.headerString !=null) {	    		   
	    		   return getHeadTag(i+1)+ciu1.headerString+ getTailTag(i+1);
	    	   }
			
			} //for
		} //sync 
        return null;
		
	}
	public String getString() {
		if (bMatched) return body.toString();
		else if (type !=null &&type.equals(BOOK) && (fileName.contains("Book") || fileName.contains("BOOK"))) {
			return "Error for:<" + fileName
					+ ">. The file naming convention for Book has to be (BOOK|Book)_UNIQUE-ID_([0-9])+"
					+ "_\\.xml. "+
		  "For example: 'BOOK_OralHistory_0001.xml.'";
				
		}else if (type != null && type.equals(CHAPTER) && (fileName.contains("Chapter") || fileName.contains("CHAPTER"))) {
			return "Error for: <" + fileName +">.The file naming convention for Chapter has to be (CHAPTER|Chapter)_UNIQUE-ID_([0-9])+"
					+ "_\\.html. "+
		  "For example: 'CHAPTER_OralHistory_0001.xml.'. The unique identify UNIQUE-ID has to match of ones of CHAPTER.";
		}else if (type!=null && type.equals(PAGE) && (fileName.contains("Page") ||  fileName.contains("PAGE"))) {
			return "Error for:<" + fileName +".>The file naming convention for Page has to be (PAGE|Page)_UNIQUE-ID_([0-9])+"
					+ "_\\.html. "+
		  "For example: 'PAGE_OralHistory_0001.html'. The unique identify UNIQUE-ID has to match of ones of BOOK.";
		}
		return "Error for: <"+fileName+">"+ returnGeneralError;
	}
}

package releasetool.gui.datamodel;


import java.util.List;

import javax.swing.table.AbstractTableModel;

import releasetool.BookInfoUnit;
import releasetool.BookUtil;
import releasetool.Entry;
import releasetool.FileEntry;
import releasetool.LocalInfoUtil;
public class BookPageModel extends AbstractTableModel {
    private String[] columnNames = {
    		
    		"Author First Name",
    		"Author Last Name", 
    		"Publish date",
    		"Creation date",
    		"Category",
    		"Title",
    		"Tagline",    		
    		"Volume", 
    		"Series"};
    private List<FileEntry> bookPageCollection=null, chapterCollection=null, pageCollection=null;
   public BookPageModel(List<FileEntry>_book, List<FileEntry> _chapter, List<FileEntry> _page) {
	   bookPageCollection=_book;
	   chapterCollection = _chapter;
	   pageCollection= _page;
   }
    public int getColumnCount() {
        return columnNames.length;
    }
 
    public int getRowCount() {
    	
        return  bookPageCollection.size() ;
        //+ chapterCollection.size() + pageCollection.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Object getValueAt(int row, int col) {
        int index = row;
     	if (bookPageCollection.size() > 0 && row < bookPageCollection.size() ) {
        	FileEntry fEntry= bookPageCollection.get(row);
        	if (fEntry==null) {
        	 return null;   	
            } else return fEntry.getBookEntry(col);
    	} 

    	index -= bookPageCollection.size();
    	
    	if (chapterCollection.size() > 0 && index < chapterCollection.size()) {
    	
        	FileEntry fEntry= chapterCollection.get(row);
        	if (fEntry==null) {
        	 return null;   	
            } else return fEntry.getChapterEntry(1);
    	} 
    	
    	index -= chapterCollection.size();
    	if (pageCollection.size() > 0 && index < pageCollection.size()) {
        	FileEntry fEntry= pageCollection.get(row);
        	if (fEntry==null) {
        	 return null;   	
            } else return fEntry.getPageEntry();
    	} 

    	
    	
    	return " ";
    }
   
    /*
     * Don't need to implement this method unless your table's
     * editable.
     */
    public boolean isCellEditable(int row, int col) {	    
        return (col ==2);	        
    }

    public void setValueAt(Object value, int row, int column) {	        
        fireTableCellUpdated(row, column);
    }
}




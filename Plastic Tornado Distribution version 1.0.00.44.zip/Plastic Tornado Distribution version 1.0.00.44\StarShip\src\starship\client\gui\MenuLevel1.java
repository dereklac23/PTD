package starship.client.gui;
import starship.atom.*;
import starship.util.*;
import java.awt.GridBagConstraints;
import java.awt.BorderLayout;
import java.awt.GridBagLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.HashMap;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class MenuLevel1 extends JPanel {
    
	private JComboBox comboBox=null;

	private static final String CONTEXT_NAME="KMP", SERVLET_NAME="KMPGateway";
	private String strUrl = "http://localhost:4200";
	public static final char URL_DIV='/';
	public JTextField jtfUrl=null, jtfServlet  =null, jtfContext=null;
	String cItem [] = {"Get", "Post","File-Upload"};
	public LocalContainer localContainerL1=null;   
	
	
	public MenuLevel1(LocalContainer _localContainerL0)  {
		super(); 
		 
		add(BorderLayout.NORTH, getUrlPanel());
		add(BorderLayout.CENTER, getPanelMain());
		
		
		//So far _localContainerL1 does not do anything. Eventually there will be ICMP layer.
		
		localContainerL1 = new LocalContainer(_localContainerL0,LocalContainer.LEVEL_TYPE.LEVEL1);
		localContainerL1.tfHostName = jtfUrl;
		localContainerL1.tfContextName = jtfContext;
		localContainerL1.tfServletName = jtfServlet;
		
		localContainerL1.taTextArea =jtaOutput;
		
		
		
		StateOperation so = new StateOperation(localContainerL1);
		System.out.println("\nInstalling GUIS");
        so.execute(StateOperation.SERVICE_LEVEL.COMMUNICATION,StateOperation.SERVICE_EXECUTION.INSTALL_GUI_SETS);
				  
		
		
	}

	
	
	private JPanel getUrlPanel() {
		JPanel jPanel  = new JPanel();
		
		comboBox = new JComboBox (cItem);
		jtfUrl= new JTextField(25);
		jPanel.setLayout(new FlowLayout());
		jPanel.add(comboBox);
		jPanel.add(jtfUrl);
		jPanel.add(new JLabel("/"));
		jPanel.add(jtfContext = new JTextField(5));
		jtfContext.setText(CONTEXT_NAME);
		jPanel.add(new JLabel("/"));
		jPanel.add(jtfServlet = new JTextField(5));
		jtfServlet.setText(SERVLET_NAME);
		jtfUrl.setText(strUrl);
		jPanel.add(jBTNPost = new JButton("Ping"));
		
		
		return jPanel;
	}
	private JButton jBTNPost = null;
	private JTextArea jtaOutput=null;
	public JPanel getPanelMain() {
			
			JPanel jPanel = new JPanel();
			
			//jPanel.add(getUrlPanel(),BorderLayout.SOUTH );
			jPanel.add(jtaOutput = new JTextArea(20,50), BorderLayout.CENTER);
			
		
			
			jBTNPost.addActionListener(new ActionListener() {
		            public void actionPerformed(ActionEvent e) {
		            	
		            	if (cItem[comboBox.getSelectedIndex()].equals("Get")) {
		            		doURIGet();
		            	} else if (cItem[comboBox.getSelectedIndex()].equals("Post")) {
		            		
		            	    doURIPost();
		            		
		            	} else if (cItem[comboBox.getSelectedIndex()].equals("File-Upload")) {
		            		//doFileUploadPost();
		            	}
		            	
		            }
			 }
			 );
		
			return jPanel;
	}
	 private void doURIPost() {
		//try {
		 try {
			KWMessageWrapper kmw  = new KWMessageWrapper(
					jtfUrl.getText(), 
					jtfContext.getText(),
					jtfServlet.getText());
				
			kmw.doPost2();
		
			
		 } catch (StateOperationException soe) {
			 System.out.println("\nsoe"+soe.toString());
		 }
		   
		
		
			
		
				
		
				
	 }
	 
	 private String getUrl() {
		 return jtfUrl.getText()+URL_DIV + jtfContext.getText() + URL_DIV + jtfServlet.getText();
	 }
	 private void doURIGet() {
		 URI uri;
		try {
			KWMessageWrapper kmw  = new KWMessageWrapper(
					jtfUrl.getText(), jtfContext.getText(), jtfServlet.getText());
			
				 
			kmw.doGet();
				
			 
			 jtaOutput.append("\nGet request completed [1]:\n"+kmw.DescribeEachItem());
			 //jtaOutput.append(kwm.DescribeString());
		} catch (StateOperationException soe) {
			jtaOutput.append(soe.toString());
		}
		 
		 
	 }
	   private void doURIConnection2() {
		  URI uri;
		try {
			  uri = new URI(jtfUrl.getText());
			  URL url = uri.toURL();
			  
			  
			  HttpURLConnection con = (HttpURLConnection)url.openConnection(); 
			  con.setRequestMethod("POST");
			  con.setDoOutput(true);
			  PrintWriter pw= new PrintWriter(con.getOutputStream());
			  
			  pw.write("POST /KMP2/KMP HTTP/1.1");
			  pw.write("Host: http://localhost:8080");
			  pw.write("Content-Type: application/x-www-form-urlencoded");
			  pw.write("Content-Length: 27");
			  pw.write("field1=value1&field2=value2");
			  pw.close();
			  
			  
			  BufferedReader in = new BufferedReader(new 
					  InputStreamReader(con.getInputStream()));
				String line =in.readLine();
			  System.out.println(line);
			 
			  
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException ioe) {
		System.out.println(ioe.toString());	
		}
		  
			
		
	 }
}

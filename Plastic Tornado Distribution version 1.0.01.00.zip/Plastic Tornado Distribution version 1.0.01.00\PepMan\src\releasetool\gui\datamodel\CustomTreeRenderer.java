package releasetool.gui.datamodel;
import java.awt.Component;

import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

import releasetool.Entry;
import releasetool.FileEntry;
import releasetool.gui.HTMLOutput;

public class CustomTreeRenderer extends  DefaultTreeCellRenderer {
	private HTMLOutput htmlOutput=null;

	public CustomTreeRenderer(HTMLOutput _hOutput) {
		htmlOutput=_hOutput;
	}
    
    
	public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        // Call the superclass method to get the default renderer component
		
	
        Component component = super.getTreeCellRendererComponent(tree, value, selected, expanded, leaf, row, hasFocus);
        Entry entry = (Entry)value;
        

        // Customize the appearance of the node
        if (selected) {
        	if (entry ==null) {
        		//System.out.println("\nTree cell render leaf null");
        	} else  if (entry.type == Entry.EntryType.BOOK && entry.fileEntry!=null){
        		synchronized(htmlOutput) {
        		htmlOutput.attachHeader();
        		
        		htmlOutput.attachRaw(entry.fileEntry.body.toString());
        		htmlOutput.attachEnder();
        		htmlOutput.printPage();
        		}
        		
        	} else if (entry.type == Entry.EntryType.CHAPTER && entry.fileEntry!=null) {
        		synchronized(htmlOutput) {
        		
            		htmlOutput.attachHeader();
            		htmlOutput.attachRaw(entry.fileEntry.getChapterEntry(1));
            		htmlOutput.attachEnder();
            		htmlOutput.printPage();
            		}
        		
        	} else if (entry.type == Entry.EntryType.ATTRIBUTE_FILE && entry.subType == Entry.EntrySubType.ITERATION) {
        		htmlOutput.attachHeader();
        		htmlOutput.attachRaw("Iteration number:"+entry.valueInt);
        		htmlOutput.attachEnder();
        		htmlOutput.printPage();
        	} else if (entry.type == Entry.EntryType.PAGE && entry.fileEntry!=null) {
        		htmlOutput.attachHeader();
        		htmlOutput.attachRaw(entry.fileEntry.body.toString());
        		htmlOutput.attachEnder();
        		htmlOutput.printPage();
        	}
        	
        
        } else if (expanded) {
            
        } else {
            
        }

        return component;
    }
}
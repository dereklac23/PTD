package releasetool;
import releasetool.gui.*;

import java.io.BufferedInputStream;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
//import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JTextArea;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

//import konaware.server.atom.KWServerHashMapEntry;

//import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
/*
Core KonaWare Messaging Code Release
Martin Gronberg (architect of Netscape and founder of KonaWare  https://www.linkedin.com/in/martin-gronberg-294191/)
Wesley Chang (VP of Engineer of KonaWare https://www.linkedin.com/in/wesley-cheng-946751/)
Any Hall (Customer Service and Consulting of KonaWare https://www.linkedin.com/in/andy-hall-0999101/  )
Jim DiSanto (CEO of KonaWare https://www.linkedin.com/in/jim-disanto-60a1039/)

Worthy of a mention: My cutesy fiancé IU. For being cute, you are the brand Ambassador of Gucci. The whole world rests on your shoulder as the President of Koreas has been impeached in December 27, 2024.
The entire Democratic Party of the United States. The U.S. Constitution rests on your hand. Do not like take that lightly. Take it to the next level.

Nothing lasts forever. Be humble.
-IU (Real name: Lee Ji-eun)

“If you can dream it, you can believe it.”
-Ken Jeong

“Extend the consciousness of humanity”
-Elon Musk
*/

public class LocalInfoUtil {
	  private final static String TOMCAT="D:\\utility\\apache-tomcat-11.0.3"; 
	  public HashMap <String, KCMObject> kwMapEntry = 
				new HashMap<String, KCMObject>();
	  public Map<String, KCMObject> eMap =  Collections.synchronizedMap(kwMapEntry);
	  
	  private String name=null;   
	  
	
	  private StringBuffer pageBuffer=new StringBuffer();
	  public JComboBox<ButtonSelection> comboPointer=null;
	  public  ArrayList<ButtonSelection> comboInitial=null;
	  public String pathName=null;
	  public File pathObject=null;
	  public Entry fileEntry=null, directoryEntry=null;
	  public MenuGTML menuGTML = null;
	  																		
	  

 public LocalInfoUtil( ) {
	
    
 
 }
 
 public LocalInfoUtil(PepMan.EntryType _type, String _entryName) {
	 typeEntry = _type;
	 nameEntry = _entryName;
	 pathObject = new File(".");
 }
 public LocalInfoUtil(PepMan.EntryType _type, String _entryName, File _root, MenuGTML _menuG) {
	 typeEntry = _type;
	 nameEntry = _entryName;
	 pathObject = _root;
	 System.out.println("\nHooking up:"+ nameEntry);
	 
	 menuGTML = _menuG;
 }
 public LocalInfoUtil(PepMan.EntryType _type, String _entryName,  MenuGTML _menuG) {
	 typeEntry = _type;
	 nameEntry = _entryName;	 
	 menuGTML = _menuG;
 }

 
 KCMObject directoryKCM= new KCMObject();
 public MenuInterface menuInterface=null;
 
 public LocalInfoUtil(PepMan.EntryType _type, String _entryName,
         JComboBox<ButtonSelection> _comb, MenuInterface _menuI) {
comboPointer= _comb;
menuInterface= _menuI;
nameEntry = _entryName;
typeEntry = _type;
directoryEntry = new Entry(Entry.EntryType.DIRECTORY, new File("."));


	

}

 private PepMan.EntryType typeEntry=PepMan.EntryType.STAGING;
 private String nameEntry =null;
 
 public LocalInfoUtil (
		 PepMan.EntryType _type,
		 String _entryName,
		 MenuInterface _menuI) {
	  typeEntry = _type;
	  nameEntry = _entryName;
	  menuInterface = _menuI;
	  pathObject = new File(".");
 }
		 
 public LocalInfoUtil (
		 PepMan.EntryType _type, 
		 String _entryName,
		 File _target,
		 MenuInterface menuI) {
	 typeEntry=_type;
	 nameEntry = _entryName;
	 
	 
	 pathObject=_target;

	 File file[] = _target.listFiles(new FileFilterSh(FileFilterSh.FILE_T.RELEASE_NAMING));
	 if (file ==null) {
		 return ;
	 }
	 else if (file.length ==0) {
		 return;
	 }

	 KCMObject  kObject=null;
	 for (int i=0; i < file.length; i++) {
		 try {
		 kObject = new KCMObject(_target, file[i].getName());
		 
		 } catch (KCMException kcm) {
			 System.out.println("\nkcm error"+kcm.description);
		 }
		 if (kObject !=null && kObject.directoryObject !=null) {		   	 
		    eMap.put(kObject.directoryObject.getVersionString(), kObject);
		 }
		 
	 }
	 Set<String> keySet=eMap.keySet();
	 int runningVersionId=0;
	
	 for (Map.Entry<String, KCMObject> entry : eMap.entrySet()) {
		 KCMObject object = entry.getValue();
		 if (object.directoryObject.compare(runningVersionId)) {
			 directoryKCM = object;
			 runningVersionId = directoryKCM.directoryObject.getVersionInt();
		 } else {

		 }
	 }	 
	 menuInterface = menuI;
	 System.out.println("\n@@@final "+directoryKCM.directoryObject.getVersionString());
	 System.out.println("\n@@@final "+directoryKCM.directoryObject.getVersionInt());
	
 }
 
		
	 
 
 public void setComboInitial(ArrayList <ButtonSelection> _comboInitialList) {
	 comboInitial = _comboInitialList;
 }


 private void processTxt(File f) throws FileNotFoundException, IOException  {
	 BufferedReader br= new BufferedReader(new FileReader(f));
	 String line = null;
	 
	 while ((line = br.readLine()) !=null) {
		 pageBuffer.append(line);
	 }
	
	 
	 
 }
 public void updateFileString(String _pathName) {
	 pathName = _pathName;
	 
 }
 public void updateFileObject(File _obj) {
	 pathObject = _obj;
	 
 }

	 public void performCopy() throws IOException {
		KCMObject kcmDevTarget = new KCMObject(new File("d:\\dev"), directoryKCM);
		kcmDevTarget.performCopy();
	 }
	 
	 
	 public void performCopyWar2Tomcat() throws KCMException {
		 try {
		 DirectoryObject directoryTomcat= new DirectoryObject(new File("D:\\utility\\apache-tomcat-11.0.3\\webapps"));
		 KCMObject kcmDevTarget = new KCMObject(directoryTomcat); String DEV_ROOT="D:\\dev";
		kcmDevTarget.performCopyWarBinaries();
		 } catch (IOException ioe) {
			 throw new KCMException (ioe.toString());
		 }
		 
	 }

	 
 
     public void createWrite() throws ParserConfigurationException,
		            TransformerException {

		        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		        DocumentBuilder builder = factory.newDocumentBuilder();
		        Document doc = builder.newDocument();

		        Element root = doc.createElementNS("zetcode.com", "users");
		        doc.appendChild(root);

		        root.appendChild(createUser(doc, "1", "Robert", "Brown", "programmer"));
		        root.appendChild(createUser(doc, "2", "Pamela", "Kyle", "writer"));
		        root.appendChild(createUser(doc, "3", "Peter", "Smith", "teacher"));

		        TransformerFactory transformerFactory = TransformerFactory.newInstance();
		        Transformer transf = transformerFactory.newTransformer();

		        transf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		        transf.setOutputProperty(OutputKeys.INDENT, "yes");
		        transf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

		        DOMSource source = new DOMSource(doc);

		        File myFile = new File("d:\\dev\\gnoo1\\users.xml");

		        StreamResult console = new StreamResult(System.out);
		        StreamResult file = new StreamResult(myFile);

		        transf.transform(source, console);
		        transf.transform(source, file);
		    }
 private static Node createUser(Document doc, String id, String firstName,
         String lastName, String occupation) {

     Element user = doc.createElement("user");

     user.setAttribute("id", id);
     user.appendChild(createUserElement(doc, "firstname", firstName));
     user.appendChild(createUserElement(doc, "lastname", lastName));
     user.appendChild(createUserElement(doc, "occupation", occupation));

     return user;
 }

 private static Node createUserElement(Document doc, String name,
         String value) {

     Element node = doc.createElement(name);
     node.appendChild(doc.createTextNode(value));

     return node;
 }
 public boolean checkTomcatDirectory(File _file) {
	 File binFile =  new File(_file,"bin");
	 File listFile [] =binFile.listFiles(new FileFilterSh());
	 return listFile !=null && listFile.length > 5;
			 
	
 }
 
 
public void setEntryName(String _newValue) {
	nameEntry = _newValue;
}
 public String getEntryName() {
	 if (nameEntry==null) {
		 return "<>";	 
	 }
	 return nameEntry;	 
	 
	 
 }
 
 public String setEntryName() {
	return nameEntry;
 }
 public String getCategory() {
	if (typeEntry == PepMan.EntryType.CLASSPATH) {
		return "CLASSPATH";
	} if (directoryKCM.directoryPointer==null) {
		return "Folder";
	}	else {
		return "Folder";
	}
 }
 public void setAttributeFile(File _file) {
	 
	 pathObject = _file;

 }
 public void setAttributeString(String _value) {
	 directoryKCM= new KCMObject(new DirectoryObject(new File(_value))); 
	 
	 
 }
  
 
 
 public Entry getFileEntry () {
	 String targetFolderName =null;
	 if (fileEntry !=null) {
		 return fileEntry;
	 } else if (directoryEntry !=null) {
		 return directoryEntry;
	 } else return null;
	 
 }
 public   String getAttributeString() {
	 
	 
	 String targetFolderName =null;
	 if (directoryKCM !=null && directoryKCM.directoryObject !=null && directoryKCM.directoryObject.root !=null) {
		 System.out.println("getting directory root pointer:");
		 return  directoryKCM.directoryObject.root.toString();
	 } else 	 if (directoryKCM !=null && directoryKCM.directoryPointer !=null) {
		 System.out.println("\ngettingh attribute pointer");
		 return directoryKCM.directoryPointer.toString();
		 
	 } 
	 switch (typeEntry) { 
	 case PepMan.EntryType.STAGING:
		 return "<Staging>";
	 case PepMan.EntryType.TARGET:
			 return "<Target>";
	 case PepMan.EntryType.CLASSPATH:
		 if (pathName !=null) {
			 return pathName;
		 } else		 return "<Classpath>";				 
	 case PepMan.EntryType.DISTRIBUTE:
		 return "<Distribute>"; 
	 }
	 return null;
 }
 
 public String getDate() {
	 if (directoryKCM.directoryPointer ==null) {
		 return null;
		 	 
	 }
	 return new Date(directoryKCM.directoryPointer.lastModified()).toString();
	 
 }
 
 public FileObject getResourceFolderFiles(ClassLoader loader,FileObject fObj) throws KCMException {
     FileObject fileObject=new FileObject();
	 try {
	 for (int i=0; i < fObj.fileList.size(); i++) {
		File f = fObj.fileList.get(i);
		String folder=f.toString();
		URL url = loader.getResource(folder);
		String path = url.getPath();		
		fileObject.setFileHeadString(path);	   
        fileObject.addBuffer(path);
	 }
	 return fileObject;
     
    
     } catch (NoClassDefFoundError ne) {
    	 System.err.println("\nClasspath needs to be set using -cp");
    	 throw new KCMException("\nError: Classpath not set");
     }
    
 }
 public FileObject getResourceFolderFilesRoot(ClassLoader loader, FileObject _foList) {	 
	 _foList.fileRoot.listFiles(new FileFilterSh(FileFilterSh.FILE_T.DIRECTORY));
	 return _foList;
 }
 
 
 
 public boolean getResourceFolderRoot(String _folder) throws KCMException {
	    ClassLoader loader = Thread.currentThread().getContextClassLoader();
	    FileObject fobj = new FileObject(_folder);
	    FileObject resourceFolderFile = getResourceFolderFilesRoot(loader,fobj);
	    return resourceFolderFile.bHasContent();
			//	 resourceFolderFile.processGTMLContent();
 }

private String getString(Path _p) throws IOException {
	StringBuffer sb= new StringBuffer();    
	FileReader fr = new FileReader(_p.toString());
	BufferedReader br = new BufferedReader(fr);
	String line=null;	
	while ( (line= br.readLine()) !=null) {
		sb.append(line);
		System.out.println("\nReadline line"+ line);
		
	}
	return sb.toString();
}



private void loadBuffer(Path _p) throws KCMException  {
	try {
	StringBuffer sb= new StringBuffer();    
	FileReader fr = new FileReader(_p.toString());
	BufferedReader br = new BufferedReader(fr);
	String line=null;	
	while ( (line= br.readLine()) !=null) {
		sb.append(line);
		System.out.println("\nReadline line"+ line);		
	}
	} catch (IOException ioe) {
		throw new KCMException ("\nIOException ");
	}
}
			
			
			
	
	
	


/*
if (gu instanceof BookInfoUnit) {
aBIU=(BookInfoUnit)gu;
allBooksSync.add(aBIU);
*/
public void loadGTML() throws KCMException  {
	try {
	if (pathObject !=null) {
	   //BookUtil bookUtil = new BookUtil();
	   
       File gtmlDir = new File(pathObject, "gtml");
       Path rootPath = Paths.get(gtmlDir.getCanonicalPath());
       ArrayList<Path> allFiles = new ArrayList<Path>();
       List<Path> allFilesSync = Collections.synchronizedList(new ArrayList(allFiles));       
       ListFilesRecurse listFiles = new ListFilesRecurse(rootPath, allFiles);     
       System.out.println("\nDone listing files");
       menuGTML.editorMain.attachHeader();       
       menuGTML.editorMain.attachP("Package Director(ies) of 'gtml'");
       menuGTML.editorMain.attachEnder();
       menuGTML.editorMain.printPage();      
       menuGTML.updatePointer(gtmlDir,allFiles);
    	   
       }
	} catch (IOException ioe) {
		throw new KCMException("\nError: cannot load files recursively from 'gtml'");
	} 

}


}


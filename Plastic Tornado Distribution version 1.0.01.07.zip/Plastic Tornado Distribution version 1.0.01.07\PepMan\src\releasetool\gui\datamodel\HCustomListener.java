package releasetool.gui.datamodel;

import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

public class HCustomListener implements HyperlinkListener {

	@Override
	public void hyperlinkUpdate(HyperlinkEvent e) {
		System.out.println("\ncustom listener");
		// TODO Auto-generated method stub
		
	}


}